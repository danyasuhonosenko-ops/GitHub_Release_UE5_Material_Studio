# -*- coding: utf-8 -*-
"""
Principled BSDF Material Builder & Local PBR Map Scanner for Blender (3.6 - 5.1+)
===================================================================================
Zero external dependencies (pure `bpy` + Python stdlib). Builds physically
accurate Cycles / EEVEE Principled BSDF node trees with proper sRGB vs Non-Color
handling, AO Multiply, DirectX -> OpenGL Green-Channel flip, Glossiness Invert,
UV / Box projection, Bump fallback, and Displacement.
"""

import os
import re
import tempfile
from typing import Any, Dict, List, Optional, Tuple

import bpy

from .core import comfy_to_corona

SUPPORTED_IMAGE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tga", ".tif", ".tiff", ".exr", ".hdr"
}

LOCAL_BLENDER_SLOT_ORDER = (
    "albedo",
    "ao",
    "roughness",
    "metallic",
    "normal",
    "height",
    "opacity",
)


def _set_colorspace_safe(img: "bpy.types.Image", is_color: bool) -> None:
    candidates = ("sRGB", "sRGB IEC61966-2.1", "Utility - sRGB - Texture") if is_color else ("Non-Color", "Raw", "Linear")
    for cs_name in candidates:
        try:
            img.colorspace_settings.name = cs_name
            return
        except Exception:
            continue


def _get_input_socket(node: "bpy.types.Node", names: Tuple[str, ...]) -> Optional["bpy.types.NodeSocket"]:
    for name in names:
        sock = node.inputs.get(name)
        if sock is not None:
            return sock
    return None


def _set_input_value(node: "bpy.types.Node", names: Tuple[str, ...], value: Any) -> bool:
    sock = _get_input_socket(node, names)
    if sock is None:
        return False
    try:
        sock.default_value = value
        return True
    except Exception:
        return False


def _find_mix_rgba_sockets(mix_node: "bpy.types.Node") -> Tuple[Optional["bpy.types.NodeSocket"], Optional["bpy.types.NodeSocket"], Optional["bpy.types.NodeSocket"], Optional["bpy.types.NodeSocket"]]:
    """Safely picks RGBA A/B/Factor/Result sockets on ShaderNodeMix (Blender 3.4 - 5.1+)."""
    fac_sock = None
    in_a = None
    in_b = None
    out_res = None
    for sock in mix_node.inputs:
        if sock.name == "Factor" and sock.type == "VALUE" and fac_sock is None:
            fac_sock = sock
        elif sock.type == "RGBA":
            if sock.name == "A" and in_a is None:
                in_a = sock
            elif sock.name == "B" and in_b is None:
                in_b = sock
    for sock in mix_node.outputs:
        if sock.type == "RGBA" and out_res is None:
            out_res = sock
    return fac_sock, in_a, in_b, out_res


def _load_texture_image(filepath: str, is_color: bool) -> Optional["bpy.types.Image"]:
    norm_path = os.path.abspath(os.path.normpath(str(filepath or "").strip()))
    if not norm_path or not os.path.isfile(norm_path):
        return None
    img = bpy.data.images.load(norm_path, check_existing=True)
    _set_colorspace_safe(img, is_color=is_color)
    return img


def classify_blender_pbr_filename(file_path: str) -> Tuple[str, Dict[str, Any]]:
    """
    Classifies a local PBR map into a Blender slot:
      albedo | ao | roughness | metallic | normal | height | opacity
    Blender uses OpenGL (+Y) normals natively, so explicit DX (`_normaldx`, `_dx`,
    `_directx`) maps set `flip_normal_green = True`.
    """
    stem = os.path.splitext(os.path.basename(str(file_path or "")))[0]
    split_camel = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", stem)
    tokens = [t.lower() for t in re.split(r"[^a-zA-Z0-9]+", split_camel) if t]
    if not tokens:
        return ("", {})
    tok_set = set(tokens)
    joined = "_".join(tokens)

    preview_words = {"preview", "thumb", "thumbnail", "sphere", "ball", "shaderball", "render", "contact", "readme"}
    if tok_set & preview_words:
        return ("", {})

    # 0. Ambient Occlusion (Blender Principled BSDF multiplies AO onto Base Color)
    if (
        (tok_set & {"ao", "ambientocclusion", "occlusion", "occ", "cav"})
        or ("ambient_occlusion" in joined)
        or ("ambientocclusion" in joined)
    ):
        return ("ao", {"priority": 2})

    # 1. Normal map (GL priority=2 > DX priority=1 in Blender; DX needs G-flip)
    if (tok_set & {"normaldx", "normalgl", "normalmap", "normal", "nrm", "nor", "norm", "nrml", "bumpnormal"}) or (
        "normal" in joined
    ):
        has_gl = (
            ("normalgl" in tok_set)
            or ("opengl" in tok_set)
            or ("gl" in tok_set and "dx" not in tok_set and "directx" not in tok_set)
        )
        has_dx = (
            ("normaldx" in tok_set)
            or ("directx" in tok_set)
            or ("dx" in tok_set and not has_gl)
        )
        conv = "dx" if has_dx else ("gl" if has_gl else "unknown")
        return ("normal", {"flip_normal_green": bool(has_dx), "normal_convention": conv, "priority": 2 if not has_dx else 1})

    slot_k, info = comfy_to_corona.classify_pbr_texture_filename(file_path)
    if slot_k == "normal":
        return ("normal", {"flip_normal_green": False, "normal_convention": "unknown", "priority": info.get("priority", 1)})
    return (slot_k, info)


def scan_blender_pbr_maps(
    file_paths: List[str],
    expand_single_siblings: bool = True,
) -> Tuple[Dict[str, str], Dict[str, Any], str]:
    """
    Classifies local texture paths into Blender PBR slots (`albedo`, `ao`, `roughness`,
    `metallic`, `normal`, `height`, `opacity`), expanding a single picked map into
    sibling maps in the same folder when matching.
    """
    valid_inputs: List[str] = []
    for p in file_paths or []:
        sp = os.path.normpath(str(p or "").strip())
        if sp and os.path.isfile(sp) and os.path.splitext(sp)[1].lower() in comfy_to_corona.LOCAL_PBR_EXTENSIONS:
            if sp not in valid_inputs:
                valid_inputs.append(sp)

    candidates = list(valid_inputs)
    fallback_dir = os.path.dirname(valid_inputs[0]) if valid_inputs else ""

    if expand_single_siblings and len(valid_inputs) == 1:
        single_path = valid_inputs[0]
        parent_dir = os.path.dirname(single_path)
        ref_stem = comfy_to_corona.extract_local_material_stem({"albedo": single_path}).lower()
        try:
            dir_textures = sorted(
                os.path.join(parent_dir, fn)
                for fn in os.listdir(parent_dir)
                if os.path.splitext(fn)[1].lower() in comfy_to_corona.LOCAL_PBR_EXTENSIONS
                and os.path.isfile(os.path.join(parent_dir, fn))
            )
        except Exception:
            dir_textures = []

        if len(dir_textures) <= 24:
            matched = []
            for fp in dir_textures:
                cand_stem = comfy_to_corona.extract_local_material_stem({"albedo": fp}).lower()
                if not ref_stem or cand_stem == ref_stem or ref_stem in cand_stem or cand_stem in ref_stem:
                    matched.append(fp)
            if len(matched) > 1:
                candidates = matched
            elif len(dir_textures) <= 12:
                candidates = dir_textures

    best_per_slot: Dict[str, Tuple[Tuple[int, int, str], str, Dict[str, Any]]] = {}
    for fp in candidates:
        slot_k, info = classify_blender_pbr_filename(fp)
        if not slot_k:
            continue
        ext_low = os.path.splitext(fp)[1].lower()
        score = (int(info.get("priority", 1)), comfy_to_corona._LOCAL_PBR_EXT_RANK.get(ext_low, 0), fp.lower())
        prev = best_per_slot.get(slot_k)
        if prev is None or score > prev[0]:
            best_per_slot[slot_k] = (score, fp, info)

    slot_map = {k: v[1] for k, v in best_per_slot.items()}
    hints: Dict[str, Any] = {
        "flip_normal_green": False,
        "normal_convention": "unknown",
        "is_glossiness": False,
        "detected_category": "auto",
    }
    if "normal" in best_per_slot:
        hints["flip_normal_green"] = bool(best_per_slot["normal"][2].get("flip_normal_green", False))
        hints["normal_convention"] = str(best_per_slot["normal"][2].get("normal_convention", "unknown"))
    if "roughness" in best_per_slot:
        hints["is_glossiness"] = bool(best_per_slot["roughness"][2].get("is_glossiness", False))

    suggested_name = comfy_to_corona.extract_local_material_stem(slot_map, fallback_dir=fallback_dir)
    if suggested_name and suggested_name != "LocalPBR":
        hints["detected_category"] = comfy_to_corona.detect_material_category(suggested_name.replace("_", " "))
    return (slot_map, hints, suggested_name)


_MIXED_METAL_CUES = (
    "rust", "oxid", "patina", "paint", "dirt", "moss", "worn", "scuff",
    "corrod", "corten", "tarnish", "mill scale", "damaged", "peeling",
    "ржав", "окис", "патин", "краск", "гряз", "потерт", "царап",
)

_CLEARCOAT_CUES = (
    "varnish", "lacquer", "lacquered", "glazed", "epoxy", "wet", "clearcoat",
    "car paint", "enamel", "resin", "лак", "глазур", "эпоксид", "мокр", "эмал",
)


def _has_prompt_cues(prompt_text: str, cues: Tuple[str, ...]) -> bool:
    low = str(prompt_text or "").lower()
    return any(c in low for c in cues)


def _apply_category_defaults(
    bsdf: "bpy.types.Node",
    category: str,
    has_metallic_map: bool,
    source_prompt: str = "",
    custom_ior: Optional[float] = None,
    custom_clearcoat: Optional[float] = None,
    custom_metalness: Optional[int] = None,
) -> None:
    cat = str(category or "stone").strip().lower()
    ior = float(custom_ior) if custom_ior is not None else 1.50
    want_coat = _has_prompt_cues(source_prompt, _CLEARCOAT_CUES)
    if custom_clearcoat is not None:
        coat = float(custom_clearcoat)
    elif want_coat:
        coat = 0.25 if cat in ("wood", "stone", "tile") else 0.35
    else:
        coat = 0.0
    sheen = 0.0
    sheen_rough = 0.5
    metal_val = float(custom_metalness) if custom_metalness is not None else 0.0
    transmission = 0.0
    anisotropy = 0.0
    anisotropy_rot = 0.0
    emission_strength = 0.0

    if cat == "wood":
        ior = float(custom_ior) if custom_ior is not None else 1.52
    elif cat in ("stone", "tile"):
        ior = float(custom_ior) if custom_ior is not None else 1.55
    elif cat in ("concrete", "brick"):
        ior = float(custom_ior) if custom_ior is not None else 1.50
    elif cat == "fabric":
        ior = float(custom_ior) if custom_ior is not None else 1.35
        sheen = 0.35
        sheen_rough = 0.55
    elif cat == "metal":
        if not has_metallic_map:
            metal_val = 1.0
        if _has_prompt_cues(source_prompt, ("mirror", "polished", "chrome")) and not _has_prompt_cues(source_prompt, ("brushed", "machined", "браш")):
            anisotropy = 0.0
        elif _has_prompt_cues(source_prompt, ("brushed", "machined", "браш", "шлиф")):
            anisotropy = 0.45
            if not _has_prompt_cues(source_prompt, ("horizontal", "горизонтал")):
                anisotropy_rot = 0.25
        else:
            anisotropy = 0.25
    elif cat == "mirror":
        if not has_metallic_map:
            metal_val = 1.0
    elif cat == "glass":
        ior = float(custom_ior) if custom_ior is not None else 1.52
        transmission = 1.0
    elif cat == "light":
        emission_strength = 5.0

    _set_input_value(bsdf, ("IOR",), ior)
    if coat > 0.0:
        _set_input_value(bsdf, ("Coat Weight", "Clearcoat"), coat)
        _set_input_value(bsdf, ("Coat Roughness", "Clearcoat Roughness"), 0.12)
    if sheen > 0.0:
        _set_input_value(bsdf, ("Sheen Weight", "Sheen"), sheen)
        _set_input_value(bsdf, ("Sheen Roughness",), sheen_rough)
    if (not has_metallic_map) and metal_val > 0.0:
        _set_input_value(bsdf, ("Metallic",), metal_val)
    if anisotropy > 0.0:
        _set_input_value(bsdf, ("Anisotropic",), anisotropy)
        if anisotropy_rot > 0.0:
            _set_input_value(bsdf, ("Anisotropic Rotation",), anisotropy_rot)
    if transmission > 0.0:
        _set_input_value(bsdf, ("Transmission Weight", "Transmission"), transmission)
    if emission_strength > 0.0:
        _set_input_value(bsdf, ("Emission Strength",), emission_strength)


def _set_material_displacement_method(mat: "bpy.types.Material", enable_displacement: bool, has_normal: bool = True) -> None:
    if enable_displacement:
        target = "DISPLACEMENT" if has_normal else "BOTH"
    else:
        target = "BUMP"
    if hasattr(mat, "displacement_method"):
        try:
            mat.displacement_method = target
            return
        except Exception:
            pass
    cycles_cfg = getattr(mat, "cycles", None)
    if cycles_cfg is not None and hasattr(cycles_cfg, "displacement_method"):
        try:
            cycles_cfg.displacement_method = target
        except Exception:
            pass


def build_pbr_material(
    material_name: str,
    tex_paths: Dict[str, str],
    category: str = "stone",
    tiling_uv: float = 0.5,
    box_projection: bool = False,
    box_blend: float = 0.2,
    normal_strength: float = 1.0,
    flip_normal_green: bool = False,
    is_glossiness_map: bool = False,
    enable_displacement: bool = False,
    displacement_scale: float = 0.02,
    displacement_midlevel: float = 0.5,
    apply_to_selection: bool = True,
    custom_ior: Optional[float] = None,
    custom_clearcoat: Optional[float] = None,
    custom_metalness: Optional[int] = None,
    source_prompt: str = "",
    force_metallic_map: bool = False,
    context: Optional[Any] = None,
) -> "bpy.types.Material":
    """
    Creates or updates a Blender Principled BSDF material from PBR texture paths.
    Must be invoked strictly on Blender's main thread.
    """
    clean_name = re.sub(r"[^A-Za-z0-9_.\-]+", "_", str(material_name or "").strip()).strip("_") or "M_PBR_Material"
    mat = bpy.data.materials.new(name=clean_name)
    if hasattr(mat, "use_nodes") and not mat.use_nodes:
        mat.use_nodes = True

    nt = mat.node_tree
    nodes = nt.nodes
    links = nt.links
    nodes.clear()

    # Output & Principled BSDF
    out_node = nodes.new("ShaderNodeOutputMaterial")
    out_node.location = (640, 0)

    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (280, 0)
    links.new(bsdf.outputs["BSDF"], out_node.inputs["Surface"])

    # UV / Object coordinate mapping
    tex_coord = nodes.new("ShaderNodeTexCoord")
    tex_coord.location = (-960, 0)

    mapping = nodes.new("ShaderNodeMapping")
    mapping.location = (-760, 0)
    uv_scale = max(0.001, float(tiling_uv or 0.5))
    mapping.inputs["Scale"].default_value = (uv_scale, uv_scale, uv_scale)
    coord_out_name = "Object" if box_projection else "UV"
    links.new(tex_coord.outputs[coord_out_name], mapping.inputs["Vector"])

    def _add_tex_node(slot_key: str, label: str, y_pos: int, is_color: bool) -> Optional["bpy.types.Node"]:
        fpath = str((tex_paths or {}).get(slot_key) or "").strip()
        if not fpath or not os.path.isfile(fpath):
            return None
        img = _load_texture_image(fpath, is_color=is_color)
        if img is None:
            return None
        tex_node = nodes.new("ShaderNodeTexImage")
        tex_node.label = label
        tex_node.name = f"Tex_{slot_key}"
        tex_node.image = img
        tex_node.location = (-480, y_pos)
        if box_projection:
            tex_node.projection = "BOX"
            tex_node.projection_blend = max(0.0, min(1.0, float(box_blend)))
        links.new(mapping.outputs["Vector"], tex_node.inputs["Vector"])
        return tex_node

    albedo_node = _add_tex_node("albedo", "Base Color", 680, is_color=True)
    ao_node = _add_tex_node("ao", "Ambient Occlusion", 340, is_color=False)
    rough_node = _add_tex_node("roughness", "Roughness / Gloss", 0, is_color=False)
    metal_node = _add_tex_node("metallic", "Metallic", -340, is_color=False)
    normal_node = _add_tex_node("normal", "Normal", -680, is_color=False)
    height_node = _add_tex_node("height", "Height / Displacement", -1020, is_color=False)
    opacity_node = _add_tex_node("opacity", "Opacity / Alpha", -1360, is_color=False)

    # Base Color + optional AO Multiply
    if albedo_node is not None and ao_node is not None:
        mix_ao = nodes.new("ShaderNodeMix")
        mix_ao.data_type = "RGBA"
        mix_ao.blend_type = "MULTIPLY"
        mix_ao.clamp_result = True
        mix_ao.location = (-120, 500)
        fac_s, in_a, in_b, out_res = _find_mix_rgba_sockets(mix_ao)
        if fac_s is not None:
            fac_s.default_value = 1.0
        if in_a is not None and in_b is not None and out_res is not None:
            links.new(albedo_node.outputs["Color"], in_a)
            links.new(ao_node.outputs["Color"], in_b)
            links.new(out_res, bsdf.inputs["Base Color"])
        else:
            links.new(albedo_node.outputs["Color"], bsdf.inputs["Base Color"])
    elif albedo_node is not None:
        links.new(albedo_node.outputs["Color"], bsdf.inputs["Base Color"])

    if (category or "").strip().lower() == "light" and albedo_node is not None:
        em_sock = _get_input_socket(bsdf, ("Emission Color", "Emission"))
        if em_sock is not None:
            links.new(albedo_node.outputs["Color"], em_sock)

    # Roughness / Glossiness Invert
    if rough_node is not None:
        if is_glossiness_map:
            inv_node = nodes.new("ShaderNodeInvert")
            inv_node.location = (-120, 0)
            links.new(rough_node.outputs["Color"], inv_node.inputs["Color"])
            links.new(inv_node.outputs["Color"], bsdf.inputs["Roughness"])
        else:
            links.new(rough_node.outputs["Color"], bsdf.inputs["Roughness"])

    # Metallic (pure unweathered metals use constant Metallic=1.0 so AI glare doesn't punch matte holes)
    cat_low = str(category or "").strip().lower()
    use_pure_metal = (
        cat_low in ("metal", "mirror")
        and not force_metallic_map
        and not _has_prompt_cues(source_prompt or material_name, _MIXED_METAL_CUES)
    )
    metallic_linked = False
    if metal_node is not None:
        if use_pure_metal:
            metal_node.label = "Metallic (Optional)"
        else:
            links.new(metal_node.outputs["Color"], bsdf.inputs["Metallic"])
            metallic_linked = True

    # Opacity / Alpha
    if opacity_node is not None:
        alpha_sock = bsdf.inputs.get("Alpha")
        if alpha_sock is not None:
            links.new(opacity_node.outputs["Color"], alpha_sock)

    # Normal (with optional DirectX G-channel invert) + Bump fallback if only Height exists
    if normal_node is not None:
        norm_map = nodes.new("ShaderNodeNormalMap")
        norm_map.location = (20, -680)
        norm_map.inputs["Strength"].default_value = max(0.0, float(normal_strength))

        if flip_normal_green:
            sep = nodes.new("ShaderNodeSeparateColor")
            sep.location = (-220, -680)
            sep.mode = "RGB"

            sub = nodes.new("ShaderNodeMath")
            sub.operation = "SUBTRACT"
            sub.location = (-80, -740)
            sub.inputs[0].default_value = 1.0

            comb = nodes.new("ShaderNodeCombineColor")
            comb.location = (50, -780)
            comb.mode = "RGB"

            links.new(normal_node.outputs["Color"], sep.inputs["Color"])
            links.new(sep.outputs["Red"], comb.inputs["Red"])
            links.new(sep.outputs["Green"], sub.inputs[1])
            links.new(sub.outputs["Value"], comb.inputs["Green"])
            links.new(sep.outputs["Blue"], comb.inputs["Blue"])
            links.new(comb.outputs["Color"], norm_map.inputs["Color"])
            norm_map.location = (180, -680)
        else:
            links.new(normal_node.outputs["Color"], norm_map.inputs["Color"])

        links.new(norm_map.outputs["Normal"], bsdf.inputs["Normal"])
    elif height_node is not None:
        bump_node = nodes.new("ShaderNodeBump")
        bump_node.location = (20, -680)
        bump_node.inputs["Strength"].default_value = min(1.0, max(0.0, float(normal_strength) * 0.5))
        bump_node.inputs["Distance"].default_value = max(0.001, float(displacement_scale))
        links.new(height_node.outputs["Color"], bump_node.inputs["Height"])
        links.new(bump_node.outputs["Normal"], bsdf.inputs["Normal"])

    # Height -> Displacement (link to Output only when Displacement is explicitly enabled to avoid double-bump)
    if height_node is not None:
        disp_node = nodes.new("ShaderNodeDisplacement")
        disp_node.location = (280, -1020)
        disp_node.inputs["Midlevel"].default_value = float(displacement_midlevel)
        disp_node.inputs["Scale"].default_value = max(0.0, float(displacement_scale))
        links.new(height_node.outputs["Color"], disp_node.inputs["Height"])
        if enable_displacement:
            links.new(disp_node.outputs["Displacement"], out_node.inputs["Displacement"])

    _set_material_displacement_method(
        mat,
        enable_displacement=bool(enable_displacement and height_node is not None),
        has_normal=(normal_node is not None),
    )

    _apply_category_defaults(
        bsdf=bsdf,
        category=category,
        has_metallic_map=metallic_linked,
        source_prompt=source_prompt or material_name,
        custom_ior=custom_ior,
        custom_clearcoat=custom_clearcoat,
        custom_metalness=custom_metalness,
    )

    if apply_to_selection:
        ctx = context or bpy.context
        selected = list(getattr(ctx, "selected_objects", []) or [])
        act = getattr(ctx, "active_object", None)
        if act is not None and act not in selected and getattr(act, "select_get", lambda: False)():
            selected.append(act)
        for obj in selected:
            data = getattr(obj, "data", None)
            if data is None or not hasattr(data, "materials"):
                continue
            try:
                if len(data.materials) == 0:
                    data.materials.append(mat)
                else:
                    idx = max(0, min(len(data.materials) - 1, int(getattr(obj, "active_material_index", 0))))
                    data.materials[idx] = mat
            except Exception:
                continue

    return mat


def _trace_image_from_socket(sock: "bpy.types.NodeSocket", depth: int = 0) -> Optional["bpy.types.Image"]:
    if sock is None or depth > 5 or not sock.is_linked:
        return None
    for link in sock.links:
        node = link.from_node
        if node is None:
            continue
        if node.type == "TEX_IMAGE" and getattr(node, "image", None) is not None:
            return node.image
        for inp in node.inputs:
            if inp.type in ("RGBA", "VECTOR", "VALUE") and inp.is_linked:
                found = _trace_image_from_socket(inp, depth + 1)
                if found is not None:
                    return found
    return None


def pick_diffuse_texture_from_active_object(context: Optional[Any] = None) -> Tuple[str, str]:
    """
    Extracts the diffuse/base color image path from the active object's active material.
    If the image is packed or only exists in Blender memory, exports a temporary PNG.
    Returns `(image_filepath, image_display_name)`.
    """
    ctx = context or bpy.context
    obj = getattr(ctx, "active_object", None)
    if obj is None:
        raise ValueError("Select an object in the 3D Viewport first.")
    mat = getattr(obj, "active_material", None)
    if mat is None or getattr(mat, "node_tree", None) is None:
        raise ValueError(f"Active object '{obj.name}' has no node-based material.")

    nt = mat.node_tree
    img = None
    bsdf = next((n for n in nt.nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf is not None:
        img = _trace_image_from_socket(bsdf.inputs.get("Base Color"))
    if img is None:
        for n in nt.nodes:
            if n.type == "TEX_IMAGE" and getattr(n, "image", None) is not None:
                cs = str(getattr(n.image.colorspace_settings, "name", "") or "").lower()
                if "srgb" in cs or img is None:
                    img = n.image
                    if "srgb" in cs:
                        break
    if img is None:
        raise ValueError(f"No Image Texture found in material '{mat.name}'.")

    raw_fp = getattr(img, "filepath_raw", "") or getattr(img, "filepath", "") or ""
    abs_fp = bpy.path.abspath(raw_fp, library=getattr(img, "library", None)) if raw_fp else ""
    ext = os.path.splitext(abs_fp)[1].lower()
    if abs_fp and os.path.isfile(abs_fp) and ext in SUPPORTED_IMAGE_EXTENSIONS and getattr(img, "packed_file", None) is None:
        return (os.path.normpath(abs_fp), img.name)

    # Packed, procedural/unsaved, or exotic format -> export clean temporary PNG
    safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", img.name or "picked_texture").strip("_") or "picked_texture"
    out_dir = os.path.join(tempfile.gettempdir(), "ai_pbr_studio_picked")
    os.makedirs(out_dir, exist_ok=True)
    tmp_png = os.path.join(out_dir, f"{safe_stem}.png")

    dup = img.copy()
    try:
        dup.filepath_raw = tmp_png
        dup.file_format = "PNG"
        dup.save()
    finally:
        try:
            bpy.data.images.remove(dup)
        except Exception:
            pass

    if not os.path.isfile(tmp_png):
        raise RuntimeError(f"Could not export image '{img.name}' to disk.")
    return (tmp_png, img.name)


def load_bw_mask_image(mask_path: str, mask_name: str = "") -> "bpy.types.Image":
    """Loads a generated B&W blend mask into `bpy.data.images` as Non-Color."""
    img = _load_texture_image(mask_path, is_color=False)
    if img is None:
        raise FileNotFoundError(f"Mask file not found: {mask_path}")
    if mask_name:
        try:
            img.name = mask_name
        except Exception:
            pass
    return img


def _fft_gaussian_2d(arr: Any, np_mod: Any, sigma: float) -> Any:
    h, w = arr.shape
    fy = np_mod.fft.fftfreq(h)[:, None]
    fx = np_mod.fft.fftfreq(w)[None, :]
    gauss = np_mod.exp(-2.0 * (np_mod.pi ** 2) * (sigma ** 2) * (fx * fx + fy * fy))
    return np_mod.fft.ifft2(np_mod.fft.fft2(arr) * gauss).real.astype(np_mod.float32)


def _frankot_chellappa_periodic(p: Any, q: Any, np_mod: Any, damp: float = 5e-4) -> Any:
    h, w = p.shape
    ky = 2.0 * np_mod.pi * np_mod.fft.fftfreq(h)[:, None]
    kx = 2.0 * np_mod.pi * np_mod.fft.fftfreq(w)[None, :]
    denom = kx * kx + ky * ky + float(damp)
    denom[0, 0] = 1.0
    z_spec = (-1j * kx * np_mod.fft.fft2(p) - 1j * ky * np_mod.fft.fft2(q)) / denom
    z_spec[0, 0] = 0.0
    return np_mod.fft.ifft2(z_spec).real.astype(np_mod.float32)


def heal_chord_normal_and_height_dipoles(normal_path: str, height_path: str) -> Tuple[bool, str]:
    """
    Detects and heals isolated CHORD attention-sink dipole singularities (high curl
    or per-axis normal/height spikes) via radius-36 directional clean patch-cloning
    on Normal followed by periodic Frankot-Chellappa integration into Height.
    """
    n_p = os.path.abspath(str(normal_path or "").strip())
    h_p = os.path.abspath(str(height_path or "").strip())
    if not os.path.isfile(n_p) or not os.path.isfile(h_p):
        return (False, "skipped: missing map file")

    try:
        import numpy as np  # type: ignore
    except Exception:
        return (False, "skipped: numpy unavailable")

    im_n = None
    im_h = None
    out_n = None
    out_h = None
    try:
        im_n = bpy.data.images.load(n_p, check_existing=False)
        im_h = bpy.data.images.load(h_p, check_existing=False)
        _set_colorspace_safe(im_n, is_color=False)
        _set_colorspace_safe(im_h, is_color=False)

        w, h = im_n.size[0], im_n.size[1]
        if w < 64 or h < 64 or im_h.size[0] != w or im_h.size[1] != h:
            return (False, "skipped: incompatible dimensions")

        # Blender buffers are bottom-to-top; flip vertically for canonical top-down orientation
        na = np.array(im_n.pixels[:], dtype=np.float32).reshape(h, w, 4)[::-1]
        ha = np.array(im_h.pixels[:], dtype=np.float32).reshape(h, w, 4)[::-1, :, 0]

        nx = na[:, :, 0] * 2.0 - 1.0
        ny = na[:, :, 1] * 2.0 - 1.0
        nz = np.clip(na[:, :, 2] * 2.0 - 1.0, 0.25, 1.0)
        sc = max(0.5, float(w) / 1024.0)

        dny_dx = np.roll(ny, -1, axis=1) - np.roll(ny, 1, axis=1)
        dnx_dy = np.roll(nx, -1, axis=0) - np.roll(nx, 1, axis=0)
        curl_s = np.abs(_fft_gaussian_2d(dny_dx - dnx_dy, np, 2.0 * sc))
        c_med = float(np.median(curl_s))
        c_mad = float(np.median(np.abs(curl_s - c_med))) * 1.4826 + 1e-6
        zc = (curl_s - c_med) / c_mad

        nx_hp = np.abs(_fft_gaussian_2d(nx - _fft_gaussian_2d(nx, np, 6.0 * sc), np, 1.5 * sc))
        ny_hp = np.abs(_fft_gaussian_2d(ny - _fft_gaussian_2d(ny, np, 6.0 * sc), np, 1.5 * sc))
        nx_med = float(np.median(nx_hp))
        nx_mad = float(np.median(np.abs(nx_hp - nx_med))) * 1.4826 + 1e-6
        ny_med = float(np.median(ny_hp))
        ny_mad = float(np.median(np.abs(ny_hp - ny_med))) * 1.4826 + 1e-6
        znx = (nx_hp - nx_med) / nx_mad
        zny = (ny_hp - ny_med) / ny_mad

        ha_hp = np.abs(ha - _fft_gaussian_2d(ha, np, 14.0 * sc))
        h_med = float(np.median(ha_hp))
        h_mad = float(np.median(np.abs(ha_hp - h_med))) * 1.4826 + 1e-6
        zh = (ha_hp - h_med) / h_mad

        seed = (
            ((zc > 6.8) & (curl_s > 0.030))
            | ((znx > 7.2) & (nx_hp > 0.035))
            | ((zny > 7.2) & (ny_hp > 0.035))
            | ((zh > 6.5) & (ha_hp > 0.25))
        ).astype(np.float32)

        min_px = max(8, int(12 * sc * sc))
        ratio = float(seed.mean())
        if int(seed.sum()) < min_px or ratio >= 0.03:
            return (False, "clean")

        mask_hard = (_fft_gaussian_2d(seed, np, 14.0 * sc) > 0.008).astype(np.float32)
        mask_soft = np.clip(_fft_gaussian_2d(mask_hard, np, 8.0 * sc), 0.0, 1.0)
        sh_d = max(48, int(96 * sc))
        if float(np.abs(ny).mean()) >= float(np.abs(nx).mean()):
            shifts = ((sh_d, 0), (-sh_d, 0), (int(1.5 * sh_d), 0), (0, sh_d))
        else:
            shifts = ((0, sh_d), (0, -sh_d), (0, int(1.5 * sh_d)), (sh_d, 0))

        nx_f = nx.copy()
        ny_f = ny.copy()
        rem = mask_soft > 0.001
        for dx, dy in shifts:
            m_sh = np.roll(np.roll(mask_hard, dy, axis=0), dx, axis=1)
            ok = rem & (m_sh < 0.01)
            if np.any(ok):
                nx_f[ok] = np.roll(np.roll(nx, dy, axis=0), dx, axis=1)[ok]
                ny_f[ok] = np.roll(np.roll(ny, dy, axis=0), dx, axis=1)[ok]
                rem = rem & (~ok)

        nx_c = nx * (1.0 - mask_soft) + nx_f * mask_soft
        ny_c = ny * (1.0 - mask_soft) + ny_f * mask_soft
        nz_c = np.sqrt(np.clip(1.0 - nx_c * nx_c - ny_c * ny_c, 0.04, 1.0))

        h_p_fc = _frankot_chellappa_periodic(-nx / nz, ny / nz, np, damp=5e-4)
        h_m_fc = _frankot_chellappa_periodic(-nx / nz, -ny / nz, np, damp=5e-4)
        corr_p = float(np.corrcoef(ha.ravel(), h_p_fc.ravel())[0, 1])
        corr_m = float(np.corrcoef(ha.ravel(), h_m_fc.ravel())[0, 1])
        q_sgn = 1.0 if corr_p >= corr_m else -1.0

        h_clean = _frankot_chellappa_periodic(-nx_c / nz_c, q_sgn * ny_c / nz_c, np, damp=2e-3)
        lo, hi = np.percentile(h_clean, [0.5, 99.5])
        if (hi - lo) > 1e-4:
            h_out = np.clip(0.05 + 0.90 * (h_clean - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)
        else:
            h_out = np.clip(h_clean, 0.0, 1.0).astype(np.float32)

        # Save healed Normal map (flip back to Blender bottom-to-top)
        out_n = bpy.data.images.new("_tmp_healed_normal", width=w, height=h)
        _set_colorspace_safe(out_n, is_color=False)
        rgba_n = np.ones((h, w, 4), dtype=np.float32)
        rgba_n[:, :, 0] = np.clip(nx_c * 0.5 + 0.5, 0.0, 1.0)[::-1]
        rgba_n[:, :, 1] = np.clip(ny_c * 0.5 + 0.5, 0.0, 1.0)[::-1]
        rgba_n[:, :, 2] = np.clip(nz_c * 0.5 + 0.5, 0.0, 1.0)[::-1]
        out_n.pixels.foreach_set(rgba_n.ravel())
        out_n.filepath_raw = n_p
        out_n.file_format = "PNG"
        out_n.save()

        # Save healed Height map (flip back to Blender bottom-to-top)
        out_h = bpy.data.images.new("_tmp_healed_height", width=w, height=h)
        _set_colorspace_safe(out_h, is_color=False)
        rgba_h = np.ones((h, w, 4), dtype=np.float32)
        h_flip = h_out[::-1]
        rgba_h[:, :, 0] = h_flip
        rgba_h[:, :, 1] = h_flip
        rgba_h[:, :, 2] = h_flip
        out_h.pixels.foreach_set(rgba_h.ravel())
        out_h.filepath_raw = h_p
        out_h.file_format = "PNG"
        out_h.save()

        cov = float(mask_hard.mean())
        return (True, f"healed dipole craters (mask={cov * 100:.2f}%, zc={zc.max():.1f})")
    finally:
        for tmp_img in (im_n, im_h, out_n, out_h):
            if tmp_img is not None:
                try:
                    bpy.data.images.remove(tmp_img)
                except Exception:
                    pass
