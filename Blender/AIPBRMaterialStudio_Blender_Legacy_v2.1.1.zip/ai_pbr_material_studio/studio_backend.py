# -*- coding: utf-8 -*-
"""
Thread-safe Backend Bridge, Cost Helper & Library Scanner for Blender
====================================================================
Wraps `core.comfy_to_corona` and `core.pbr_credits_ledger` cleanly for Blender's
main-thread UI / `bpy.app.timers` loop without blocking the 3D Viewport.
"""

import os
import re
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import bpy

from . import blender_material_builder as mat_builder
from .core import comfy_to_corona, pbr_credits_ledger

DEFAULT_LOCAL_COMFY_URL = "http://127.0.0.1:8188"


def _is_managed_cloud_url(url: str) -> bool:
    raw = str(url or "").strip()
    if not raw:
        return False
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = (parsed.hostname or "").strip().lower()
    if not host:
        return False
    cloud_parsed = urlparse(str(getattr(pbr_credits_ledger, "PUBLIC_CLOUDFLARE_GATEWAY_URL", "") or ""))
    cloud_host = (cloud_parsed.hostname or "").strip().lower()
    return ("tail754f20.ts.net" in host) or (bool(cloud_host) and host == cloud_host)


def get_default_output_root() -> str:
    docs_dir = os.path.join(os.path.expanduser("~"), "Documents")
    base = docs_dir if os.path.isdir(docs_dir) else os.path.expanduser("~")
    return os.path.join(base, "AI_PBR_Material_Studio", "Materials")


def get_addon_prefs(context: Optional[Any] = None) -> Optional[Any]:
    pkg = __package__
    ctx = context or bpy.context
    prefs_root = getattr(ctx, "preferences", None)
    if prefs_root is None:
        return None
    addon_entry = prefs_root.addons.get(pkg)
    if addon_entry is None and "." in str(pkg or ""):
        addon_entry = prefs_root.addons.get(pkg.split(".")[-1])
    return getattr(addon_entry, "preferences", None) if addon_entry is not None else None


def resolve_output_root(context: Optional[Any] = None) -> str:
    prefs = get_addon_prefs(context)
    if prefs is not None and bool(getattr(prefs, "save_next_to_blend", False)):
        blend_fp = str(getattr(bpy.data, "filepath", "") or "").strip()
        if blend_fp:
            return os.path.join(os.path.dirname(os.path.abspath(blend_fp)), "PBR_Materials")
    if prefs is not None:
        custom = str(getattr(prefs, "output_dir", "") or "").strip()
        if custom:
            return os.path.abspath(os.path.expanduser(custom))
    return get_default_output_root()


def get_server_config(context: Optional[Any] = None) -> Tuple[str, str, bool]:
    """
    Returns `(server_mode, comfy_url, charge_credits)`.
    `LOCAL` runs against local ComfyUI free of credits; `CLOUD` hits Cloud GPU Gateway
    (or optional custom Cloud/RunPod Gateway URL override).
    """
    prefs = get_addon_prefs(context)
    mode = str(getattr(prefs, "server_mode", "CLOUD") or "CLOUD").upper()
    if mode == "LOCAL":
        url = str(getattr(prefs, "local_comfy_url", DEFAULT_LOCAL_COMFY_URL) or DEFAULT_LOCAL_COMFY_URL).strip().rstrip("/")
        if not url:
            url = DEFAULT_LOCAL_COMFY_URL
        if _is_managed_cloud_url(url):
            return ("CLOUD", url, True)
        return ("LOCAL", url, False)
    custom_cloud = str(getattr(prefs, "custom_cloud_url", "") or "").strip().rstrip("/")
    cloud_url = custom_cloud or pbr_credits_ledger.PUBLIC_CLOUDFLARE_GATEWAY_URL.rstrip("/")
    return ("CLOUD", cloud_url, True)


def apply_server_config(context: Optional[Any] = None) -> Tuple[str, str, bool]:
    prefs = get_addon_prefs(context)
    mode, url, charge = get_server_config(context)
    is_cloud = mode == "CLOUD"
    comfy_to_corona._SEND_CLOUD_AUTH_HEADERS = is_cloud
    pbr_credits_ledger.CUSTOM_GATEWAY_KEY = (
        str(getattr(prefs, "custom_gateway_key", "") or "").strip() if is_cloud else ""
    )
    comfy_to_corona.COMFY_URL = url
    return (mode, url, charge)


def is_instant_physical_metal_prompt(prompt_text: str) -> bool:
    fn = getattr(comfy_to_corona, "is_instant_physical_metal_prompt", None) or getattr(
        comfy_to_corona, "is_pure_polished_metal_prompt", None
    )
    if callable(fn):
        try:
            return bool(fn(str(prompt_text or "")))
        except Exception:
            return False
    return False


def get_effective_cost(res_px: int, ref_mode: str = "", server_mode: str = "CLOUD", prompt_text: str = "") -> float:
    if str(server_mode or "CLOUD").upper() == "LOCAL":
        return 0.0
    if (not ref_mode) and prompt_text and is_instant_physical_metal_prompt(prompt_text):
        return 0.0
    return float(pbr_credits_ledger.get_pbr_generation_cost(int(res_px), ref_mode=str(ref_mode or "")))


def format_effective_cost_label(res_px: int, ref_mode: str = "", server_mode: str = "CLOUD", prompt_text: str = "") -> str:
    if (not ref_mode) and prompt_text and is_instant_physical_metal_prompt(prompt_text):
        return "Free (Physical Metal)"
    if str(server_mode or "CLOUD").upper() == "LOCAL":
        return "Free (Local GPU)"
    cost = pbr_credits_ledger.get_pbr_generation_cost(int(res_px), ref_mode=str(ref_mode or ""))
    return pbr_credits_ledger.format_cost_unit(cost)


def sanitize_blender_material_name(name: str, category: str = "stone") -> str:
    raw = str(name or "").strip()
    if raw.startswith("M_Corona_"):
        raw = "M_PBR_" + raw[len("M_Corona_"):]
    elif not raw.startswith("M_PBR_"):
        cat_cap = str(category or "Material").strip().capitalize()
        raw = f"M_PBR_{cat_cap}_{raw}" if raw else f"M_PBR_{cat_cap}"
    return re.sub(r"[^A-Za-z0-9_.\-]+", "_", raw).strip("_") or "M_PBR_Material"


def _rewrite_progress_message(msg: str) -> str:
    txt = str(msg or "")
    txt = txt.replace("CoronaPhysicalMtl", "Principled BSDF")
    txt = txt.replace("в 3ds Max", "в Blender")
    txt = txt.replace("3ds Max", "Blender")
    return txt


def test_server_connection(
    server_mode: str,
    local_url: str = DEFAULT_LOCAL_COMFY_URL,
    custom_cloud_url: str = "",
    custom_gateway_key: str = "",
) -> Tuple[bool, str]:
    prev_url = comfy_to_corona.COMFY_URL
    prev_gw_key = getattr(pbr_credits_ledger, "CUSTOM_GATEWAY_KEY", "")
    prev_send_auth = getattr(comfy_to_corona, "_SEND_CLOUD_AUTH_HEADERS", True)
    try:
        if str(server_mode).upper() == "LOCAL":
            target_url = (local_url or DEFAULT_LOCAL_COMFY_URL).strip().rstrip("/")
            if _is_managed_cloud_url(target_url):
                return (
                    False,
                    "Managed Cloud Gateway URL cannot be used in Local Free mode. Switch to Cloud GPU Gateway.",
                )
            comfy_to_corona._SEND_CLOUD_AUTH_HEADERS = False
            pbr_credits_ledger.CUSTOM_GATEWAY_KEY = ""
            comfy_to_corona.COMFY_URL = target_url
        else:
            comfy_to_corona._SEND_CLOUD_AUTH_HEADERS = True
            pbr_credits_ledger.CUSTOM_GATEWAY_KEY = str(custom_gateway_key or "").strip()
            c_url = str(custom_cloud_url or "").strip().rstrip("/")
            comfy_to_corona.COMFY_URL = c_url or pbr_credits_ledger.PUBLIC_CLOUDFLARE_GATEWAY_URL.rstrip("/")
        return comfy_to_corona.test_comfy_connection(timeout_sec=5.0)
    finally:
        comfy_to_corona.COMFY_URL = prev_url
        pbr_credits_ledger.CUSTOM_GATEWAY_KEY = prev_gw_key
        comfy_to_corona._SEND_CLOUD_AUTH_HEADERS = prev_send_auth


def tag_view3d_redraw() -> None:
    try:
        wm = getattr(bpy.context, "window_manager", None)
        if wm is None:
            return
        for win in wm.windows:
            scr = getattr(win, "screen", None)
            if scr is None:
                continue
            for area in scr.areas:
                if area.type in ("VIEW_3D", "PREFERENCES"):
                    area.tag_redraw()
    except Exception:
        pass


class _JobRuntime:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.running: bool = False
        self.finished: bool = False
        self.progress: str = "Ready"
        self.last_status: str = ""
        self.last_error: str = ""
        self.result: Optional[Dict[str, Any]] = None
        self.on_complete: Optional[Callable[[Optional[Dict[str, Any]], str], None]] = None
        self.started_at: float = 0.0
        self.cached_balance: Optional[float] = None
        self.cached_copy_id: str = ""
        self.syncing_credits: bool = False
        self.worker_thread: Optional[threading.Thread] = None


_RUNTIME = _JobRuntime()


def get_job_snapshot() -> Dict[str, Any]:
    need_reregister_timer = False
    with _RUNTIME.lock:
        if _RUNTIME.running and _RUNTIME.finished:
            try:
                if not bpy.app.timers.is_registered(_poll_job_timer):
                    need_reregister_timer = True
            except Exception:
                need_reregister_timer = True
        elif (
            _RUNTIME.running
            and not _RUNTIME.finished
            and _RUNTIME.worker_thread is not None
            and not _RUNTIME.worker_thread.is_alive()
        ):
            _RUNTIME.running = False
            _RUNTIME.worker_thread = None
            _RUNTIME.last_error = "Previous job ended unexpectedly — ready to generate."
        bal = _RUNTIME.cached_balance
        cid = _RUNTIME.cached_copy_id
        snap = {
            "running": _RUNTIME.running,
            "progress": _RUNTIME.progress,
            "last_status": _RUNTIME.last_status,
            "last_error": _RUNTIME.last_error,
            "elapsed": int(time.monotonic() - _RUNTIME.started_at) if _RUNTIME.running else 0,
            "cached_balance": bal,
            "cached_copy_id": cid,
            "syncing_credits": _RUNTIME.syncing_credits,
        }
    if need_reregister_timer:
        try:
            bpy.app.timers.register(_poll_job_timer, first_interval=0.05, persistent=True)
        except Exception:
            pass
    return snap


def get_cached_balance_and_id() -> Tuple[Any, str]:
    with _RUNTIME.lock:
        bal = _RUNTIME.cached_balance
        cid = _RUNTIME.cached_copy_id
    if bal is None or not cid:
        bal = pbr_credits_ledger.get_remaining_generations(False)
        cid = pbr_credits_ledger.get_instance_fingerprint()
        with _RUNTIME.lock:
            _RUNTIME.cached_balance = bal
            _RUNTIME.cached_copy_id = cid
    return pbr_credits_ledger.norm_credits(bal), cid


def set_status_message(status_msg: str = "", error_msg: str = "") -> None:
    with _RUNTIME.lock:
        if status_msg:
            _RUNTIME.last_status = status_msg
            _RUNTIME.progress = status_msg
        if error_msg:
            _RUNTIME.last_error = error_msg
        elif status_msg:
            _RUNTIME.last_error = ""
    tag_view3d_redraw()


def refresh_credits_async(event_type: str = "blender_panel_sync") -> None:
    with _RUNTIME.lock:
        if _RUNTIME.syncing_credits:
            return
        _RUNTIME.syncing_credits = True

    def _sync_worker() -> None:
        try:
            res = pbr_credits_ledger.sync_with_audit_server(event_type=event_type)
            bal = pbr_credits_ledger.norm_credits(res.get("credits", 0))
            cid = str(res.get("instance_id") or pbr_credits_ledger.get_instance_fingerprint())
            synced = bool(res.get("synced"))
            with _RUNTIME.lock:
                _RUNTIME.cached_balance = bal
                _RUNTIME.cached_copy_id = cid
                if synced:
                    _RUNTIME.last_status = f"Credits synced: {pbr_credits_ledger.format_credits(bal)} Gens"
        except Exception:
            pass
        finally:
            with _RUNTIME.lock:
                _RUNTIME.syncing_credits = False
            try:
                bpy.app.timers.register(lambda: (tag_view3d_redraw(), None)[1], first_interval=0.05)
            except Exception:
                pass

    threading.Thread(target=_sync_worker, daemon=True).start()


def _poll_job_timer() -> Optional[float]:
    with _RUNTIME.lock:
        done = _RUNTIME.finished
        res = _RUNTIME.result
        err = _RUNTIME.last_error
        cb = _RUNTIME.on_complete
        if done:
            _RUNTIME.running = False
            _RUNTIME.finished = False
            _RUNTIME.on_complete = None

    tag_view3d_redraw()
    if done:
        if cb is not None:
            try:
                cb(res, err)
            except Exception as exc:
                set_status_message(error_msg=f"UI callback error: {exc}")
        bal = pbr_credits_ledger.get_remaining_generations(False)
        with _RUNTIME.lock:
            _RUNTIME.cached_balance = bal
        tag_view3d_redraw()
        return None
    return 0.2


def start_background_job(
    initial_progress: str,
    worker_fn: Callable[[Callable[[str], None]], Dict[str, Any]],
    on_complete_main_thread: Callable[[Optional[Dict[str, Any]], str], None],
) -> bool:
    with _RUNTIME.lock:
        if _RUNTIME.running:
            if _RUNTIME.worker_thread is not None and not _RUNTIME.worker_thread.is_alive():
                _RUNTIME.running = False
                _RUNTIME.worker_thread = None
            else:
                return False
        _RUNTIME.running = True
        _RUNTIME.finished = False
        _RUNTIME.progress = initial_progress
        _RUNTIME.last_error = ""
        _RUNTIME.result = None
        _RUNTIME.on_complete = on_complete_main_thread
        _RUNTIME.started_at = time.monotonic()

    def _emit_progress(msg: str) -> None:
        clean = _rewrite_progress_message(msg)
        with _RUNTIME.lock:
            _RUNTIME.progress = clean

    def _runner() -> None:
        res_out: Optional[Dict[str, Any]] = None
        err_out = ""
        try:
            res_out = worker_fn(_emit_progress)
        except Exception as exc:
            raw_err = str(exc) or exc.__class__.__name__
            if "timed out" in raw_err.lower():
                err_out = "Server timed out (busy GPU / network) — try again (credits auto-refunded)"
            else:
                err_out = raw_err
        finally:
            with _RUNTIME.lock:
                _RUNTIME.result = res_out
                _RUNTIME.last_error = err_out
                _RUNTIME.finished = True
                if not err_out and isinstance(res_out, dict):
                    _RUNTIME.last_status = "Ready"
                    _RUNTIME.progress = "Done"

    bpy.app.timers.register(_poll_job_timer, first_interval=0.15, persistent=True)
    t = threading.Thread(target=_runner, daemon=True)
    with _RUNTIME.lock:
        _RUNTIME.worker_thread = t
    t.start()
    tag_view3d_redraw()
    return True


def cancel_active_job() -> bool:
    try:
        ok = bool(comfy_to_corona.cancel_comfy_generation())
    except Exception:
        ok = False
    with _RUNTIME.lock:
        _RUNTIME.running = False
        _RUNTIME.finished = False
        _RUNTIME.on_complete = None
        _RUNTIME.worker_thread = None
    set_status_message(status_msg="Generation stopped." if ok else "Reset job state — ready to generate.")
    return ok


def list_library_materials(output_root: str, limit: int = 24) -> List[Dict[str, Any]]:
    """Lists recently generated or saved PBR material folders under `output_root`."""
    entries: List[Dict[str, Any]] = []
    if not output_root or not os.path.isdir(output_root):
        return entries

    for dirpath, _dirnames, filenames in os.walk(output_root):
        img_files = [
            os.path.join(dirpath, fn)
            for fn in filenames
            if os.path.splitext(fn)[1].lower() in mat_builder.SUPPORTED_IMAGE_EXTENSIONS
        ]
        if not img_files:
            continue
        slot_map, hints, suggested = mat_builder.scan_blender_pbr_maps(img_files, expand_single_siblings=False)
        if not slot_map:
            continue
        rel = os.path.relpath(dirpath, output_root)
        parts = [p for p in rel.replace("\\", "/").split("/") if p and p != "."]
        cat = parts[0] if len(parts) >= 2 else (hints.get("detected_category") or "stone")
        if cat == "auto":
            cat = "stone"
        try:
            mtime = max(os.path.getmtime(p) for p in slot_map.values())
        except Exception:
            mtime = 0.0
        entries.append(
            {
                "name": os.path.basename(dirpath) or suggested,
                "category": cat,
                "folder": dirpath,
                "textures": slot_map,
                "hints": hints,
                "maps_count": len(slot_map),
                "mtime": mtime,
            }
        )

    entries.sort(key=lambda x: x["mtime"], reverse=True)
    return entries[: max(1, int(limit))]
