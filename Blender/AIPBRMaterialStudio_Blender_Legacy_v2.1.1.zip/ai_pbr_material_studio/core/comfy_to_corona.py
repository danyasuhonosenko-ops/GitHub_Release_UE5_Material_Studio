# -*- coding: utf-8 -*-
"""
ComfyUI Corona PBR Studio for Autodesk 3ds Max & Corona Renderer
================================================================
Generates seamless 5-map PBR textures (Albedo, Normal, Roughness, Metallic, Height)
via ComfyUI (AI 5-Map PBR Engine / DepthAnything V2 + RealVisXL V5 / SDXL 1.0) from:
  1. Text Prompt (Russian or English) or 289 Built-in Material Presets (12 Categories)
  2. Reference Image (Seamless Redraw + 5-Map PBR, Direct PBR Extraction, AI Vision Extractor, or 4x Outpaint)
  3. Full Interior Reference Photo (AI extracts all room materials -> 1-click CoronaPhysicalMtl generation)

Automatically builds physically accurate `CoronaPhysicalMtl` materials in 3ds Max
with `CoronaBitmap` (sRGB for BaseColor, Linear gamma=1.0 for Roughness/Metallic/Normal/Height)
and `CoronaNormal`, placing them into the Material Editor and assigning to selected objects.
"""

import base64
import json
import math
import os
import random
import re
import shutil
import struct
import sys
import threading
import time
import urllib.parse
import urllib.request
import zlib
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

from .presets_data import (
    CATEGORY_KEYWORDS,
    CATEGORY_PRESET_PROMPTS,
    DEFAULT_PBR_MODEL_LABEL,
    DEFAULT_RESOLUTION_LABEL,
    PBR_MODEL_OPTIONS,
    PRESET_CATEGORIES_ORDER,
    RESOLUTION_OPTIONS,
    RU_TO_EN_MATERIALS,
)
from . import pbr_credits_ledger

COMFY_URL = os.environ.get("COMFY_URL", "https://desktop-kbo2jj9.tail754f20.ts.net")

_COMFY_GW_TOKEN_OBF = (
    10, 24, 8, 119, 29, 13, 119, 99, 28, 110, 27, 109, 25, 104, 31, 98,
    24, 107, 30, 108, 106, 111, 105, 27, 110, 31, 99, 104, 25, 109, 24, 98,
    30, 107, 28, 105, 31, 108, 27,
)


def _get_hw_instance_id() -> str:
    try:
        return pbr_credits_ledger.get_instance_fingerprint()
    except Exception:
        def _is_valid_cid(val: str) -> bool:
            s = str(val or "").strip().upper()
            return bool(re.fullmatch(r"PBR-[0-9A-F]{6}-[0-9A-F]{6}", s) and s != "PBR-000000-000000")

        def _pin_registry_cid(cid_val: str) -> None:
            try:
                import winreg
                with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
                    winreg.SetValueEx(rk, "InstanceId", 0, winreg.REG_SZ, cid_val)
            except Exception:
                pass

        try:
            import hashlib, platform, uuid
            try:
                import winreg
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
                    reg_cid, _ = winreg.QueryValueEx(rk, "InstanceId")
                    reg_cid_u = str(reg_cid or "").strip().upper()
                    if _is_valid_cid(reg_cid_u):
                        return reg_cid_u
            except Exception:
                pass

            appdata_json = os.path.join(
                os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
                "UE5PBRStudio",
                "studio_license_state.json",
            )
            try:
                if os.path.isfile(appdata_json):
                    with open(appdata_json, "r", encoding="utf-8") as jf:
                        j_data = json.load(jf)
                    if isinstance(j_data, dict):
                        j_cid = str(j_data.get("instance_id") or "").strip().upper()
                        if _is_valid_cid(j_cid):
                            _pin_registry_cid(j_cid)
                            return j_cid
            except Exception:
                pass

            mguid = ""
            try:
                import winreg
                with winreg.OpenKey(
                    winreg.HKEY_LOCAL_MACHINE,
                    r"SOFTWARE\Microsoft\Cryptography",
                    0,
                    winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
                ) as mk:
                    mg_val, _ = winreg.QueryValueEx(mk, "MachineGuid")
                    mguid = str(mg_val or "").strip().lower()
            except Exception:
                mguid = ""

            if mguid:
                raw_hw = f"UE5_PBR_INSTANCE_MGUID|{mguid}|{platform.machine()}"
            else:
                raw_hw = f"UE5_PBR_INSTANCE|{uuid.getnode()}|{platform.node()}|{platform.machine()}"
            h_hex = hashlib.sha256(raw_hw.encode("utf-8")).hexdigest()[:12].upper()
            cid = f"PBR-{h_hex[:6]}-{h_hex[6:12]}"
            _pin_registry_cid(cid)
            return cid
        except Exception:
            return "PBR-000000-000000"


_SEND_CLOUD_AUTH_HEADERS = True


def _comfy_headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    hdrs: Dict[str, str] = {}
    if _SEND_CLOUD_AUTH_HEADERS:
        hdrs["X-PBR-Gateway-Key"] = pbr_credits_ledger._get_gateway_key()
        hdrs["X-PBR-Instance-ID"] = _get_hw_instance_id()
        hdrs["X-PBR-Token-Capable"] = "1"
        try:
            h_app, h_ver, h_lbl = pbr_credits_ledger.detect_host_app_info()
            os_plat = pbr_credits_ledger.detect_os_platform()
            hdrs["X-PBR-Version"] = pbr_credits_ledger.STUDIO_VERSION
            hdrs["X-PBR-Host-App"] = h_app
            hdrs["X-PBR-Host-Version"] = h_ver
            hdrs["X-PBR-Host-Label"] = h_lbl
            hdrs["X-PBR-OS"] = os_plat
            hdrs["X-PBR-Edition"] = getattr(pbr_credits_ledger, "STUDIO_EDITION", "standard")
            hdrs["User-Agent"] = f"Blender-PBR-Studio/{pbr_credits_ledger.STUDIO_VERSION} ({h_lbl}; {os_plat})"
        except Exception:
            pass
        try:
            ctok = pbr_credits_ledger._get_client_token()
            if ctok:
                hdrs["X-PBR-Client-Token"] = ctok
        except Exception:
            pass
    if extra:
        hdrs.update(extra)
    return hdrs


def _comfy_get(url: str, timeout: float = 10.0):
    req = urllib.request.Request(url, headers=_comfy_headers(), method="GET")
    return urllib.request.urlopen(req, timeout=timeout)
_DEV_ASSISTANT_ROOT = os.environ.get("AIPBR_STUDIO_ROOT", "").strip()
DEFAULT_OUTPUT_ROOT = (
    os.path.join(_DEV_ASSISTANT_ROOT, "3D_Library", "Corona_PBR_Materials")
    if _DEV_ASSISTANT_ROOT and os.path.isdir(_DEV_ASSISTANT_ROOT)
    else os.path.join(_SCRIPT_DIR, "Corona_PBR_Materials")
)
MAX_BRIDGE_CMD_PATH = (
    os.path.join(_DEV_ASSISTANT_ROOT, "asset_scout", "data", "bridge_cmd_max.ms")
    if _DEV_ASSISTANT_ROOT and os.path.isdir(_DEV_ASSISTANT_ROOT)
    else os.path.join(_SCRIPT_DIR, "bridge_cmd_max.ms")
)
DEFAULT_JSON_CHORD = (
    os.path.join(_SCRIPT_DIR, "UE_plagin_chord.json")
    if os.path.exists(os.path.join(_SCRIPT_DIR, "UE_plagin_chord.json"))
    else os.path.join(_SCRIPT_DIR, "Corona_plagin_chord.json")
)
DEFAULT_JSON_DA2 = (
    os.path.join(_SCRIPT_DIR, "UE_plagin.json")
    if os.path.exists(os.path.join(_SCRIPT_DIR, "UE_plagin.json"))
    else os.path.join(_SCRIPT_DIR, "Corona_plagin.json")
)


def _load_gemini_api_key() -> str:
    """Loads GEMINI_API_KEY from environment or <plugin_dir>/.env."""
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if key:
        return key
    env_candidates = [
        os.path.join(_SCRIPT_DIR, ".env"),
        os.path.join(os.path.dirname(_SCRIPT_DIR), ".env"),
    ]
    for env_path in env_candidates:
        if os.path.exists(env_path):
            try:
                with open(env_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("GEMINI_API_KEY="):
                            return line.split("=", 1)[1].strip().strip('"').strip("'")
            except Exception:
                pass
    return ""


def translate_or_clean_prompt(raw_prompt: str) -> str:
    """Translates Russian material prompt to English or cleans English prompt."""
    text = (raw_prompt or "").strip()
    if not text:
        return "oak wood parquet floor, herringbone pattern, natural timber"

    lower = text.lower()
    if lower in RU_TO_EN_MATERIALS:
        return RU_TO_EN_MATERIALS[lower]

    if re.search(r"[а-яА-ЯёЁ]", text):
        for ru_key, en_val in RU_TO_EN_MATERIALS.items():
            if ru_key == lower:
                return en_val
        try:
            q = urllib.parse.quote(text)
            url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=ru&tl=en&dt=t&q={q}"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=4.0) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                translated = "".join(part[0] for part in data[0] if part and part[0])
                if translated.strip():
                    return translated.strip()
        except Exception:
            pass
        for ru_key, en_val in RU_TO_EN_MATERIALS.items():
            if ru_key in lower:
                return en_val

    return text


def make_slug(prompt_en: str) -> str:
    """Creates a clean PascalCase identifier from an English prompt."""
    words = re.findall(r"[A-Za-z0-9]+", prompt_en)
    stop = {
        "top", "down", "view", "of", "a", "an", "the", "seamless",
        "tileable", "texture", "with", "and", "surface", "flat", "even",
    }
    filtered = [w.capitalize() for w in words if w.lower() not in stop][:4]
    slug = "".join(filtered) if filtered else "Material"
    return slug[:28]


def detect_material_category(raw_prompt: str, prompt_en: str = "") -> str:
    """Detects one of the 12 material categories from the prompt."""
    for source_text in (raw_prompt or "", prompt_en or ""):
        clean_src = source_text.strip().lower()
        if not clean_src:
            continue
        for cat_k, items in CATEGORY_PRESET_PROMPTS.items():
            for _p_title, p_txt in items:
                if clean_src == p_txt.strip().lower():
                    return cat_k

    for source_text in (raw_prompt or "", prompt_en or ""):
        if not (source_text or "").strip():
            continue
        words = re.findall(r"[A-Z][a-z]+|[a-z]+|[0-9]+|[а-яА-ЯёЁ]+", source_text)
        low = " ".join(words).lower()
        if not low:
            continue
        best_cat = None
        best_pos = 10**9
        for cat, keywords in CATEGORY_KEYWORDS.items():
            for kw in keywords:
                if kw in ("stained", "hexagonal", "transparent", "translucent"):
                    continue
                if cat == "light" and kw == "light":
                    # Only match standalone 'light'/'lights', never 'lighting' or 'lighted'
                    pat = r"\blights?\b"
                    m_obj = re.search(pat, low)
                    pos = m_obj.start() if m_obj else -1
                elif re.match(r"^[a-z0-9 ]+$", kw):
                    pat = r"\b" + re.escape(kw) + r"(?:s|es|ed|ing)?\b"
                    m_obj = re.search(pat, low)
                    pos = m_obj.start() if m_obj else -1
                else:
                    pos = low.find(kw)
                if pos != -1 and pos < best_pos:
                    best_pos = pos
                    best_cat = cat
        if best_cat:
            return best_cat
    return "stone"


def preprocess_reference_for_seamless(
    image_path: str,
    target_size: int = 1024,
) -> str:
    """
    Pre-processes a reference photo/screenshot BEFORE uploading to ComfyUI so that both
    `img2img_seamless` and `chord_direct` produce 100% seamless, evenly-lit PBR textures:
      1. Trims 2% outer border (removes accidental screenshot window frames/edges).
      2. High-pass de-lighting (flattens room shadow/window lighting gradients while keeping
         exact RGB color and plaster/stone/wood strokes).
      3. 4-way toroidal raised-cosine cross-synthesis with variance preservation (makes the
         input image mathematically periodic in X and Y with zero contrast loss).
    Returns path to the pre-processed PNG file.
    """
    try:
        import numpy as np
        from PIL import Image
        from scipy.ndimage import gaussian_filter

        im = Image.open(image_path).convert("RGB")
        w0, h0 = im.size
        # 1. Trim 2% outer margin to avoid screenshot frames
        if w0 > 64 and h0 > 64:
            mx = max(1, int(w0 * 0.02))
            my = max(1, int(h0 * 0.02))
            im = im.crop((mx, my, w0 - mx, h0 - my))

        im = im.resize((target_size, target_size), Image.Resampling.BICUBIC)
        arr = np.asarray(im, dtype=np.float32)

        # 2. Intrinsic High-Pass De-Lighting (removes directional room shadows/highlights
        #    while preserving the true natural micro-contrast of the surface)
        sigma_delight = max(18.0, target_size * 0.12)
        mean_rgb = np.mean(arr, axis=(0, 1), keepdims=True)
        low_freq = np.zeros_like(arr)
        for c_i in range(3):
            low_freq[:, :, c_i] = gaussian_filter(arr[:, :, c_i], sigma=sigma_delight, mode="reflect")
        delit = (arr / (low_freq + 1.0)) * mean_rgb
        delit_mean = np.mean(delit, axis=(0, 1), keepdims=True)
        delit = (delit - delit_mean) * 1.15 + mean_rgb

        # 3. 4-Way Toroidal Raised-Cosine Synthesis with Variance Preservation
        h, w, _ = delit.shape
        ih = np.roll(delit, w // 2, axis=1)
        iv = np.roll(delit, h // 2, axis=0)
        ihv = np.roll(ih, h // 2, axis=0)

        wx = (0.5 - 0.5 * np.cos(2.0 * np.pi * np.arange(w, dtype=np.float32) / w))[None, :, None]
        wy = (0.5 - 0.5 * np.cos(2.0 * np.pi * np.arange(h, dtype=np.float32) / h))[:, None, None]

        blended = (
            wy * (wx * delit + (1.0 - wx) * ih)
            + (1.0 - wy) * (wx * iv + (1.0 - wx) * ihv)
        )
        # Variance preservation factor so blended zones never look blurry or ghosted
        var_scale = np.sqrt((wx ** 2 + (1.0 - wx) ** 2) * (wy ** 2 + (1.0 - wy) ** 2))
        b_mean = np.mean(blended, axis=(0, 1), keepdims=True)
        seamless = b_mean + (blended - b_mean) / np.maximum(var_scale, 0.5)

        # Final gentle periodic de-light pass so 4x4 tiling has zero low-frequency blotches
        for c_i in range(3):
            lf2 = gaussian_filter(seamless[:, :, c_i], sigma=target_size * 0.20, mode="wrap")
            seamless[:, :, c_i] = seamless[:, :, c_i] - lf2 + float(mean_rgb[0, 0, c_i])

        seamless_u8 = np.clip(seamless, 0, 255).astype(np.uint8)
        out_dir = os.path.join(_SCRIPT_DIR, "_temp_ref")
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, "preprocessed_seamless_ref.png")
        Image.fromarray(seamless_u8).save(out_path, format="PNG")
        return out_path
    except Exception:
        return image_path


def enforce_seamless_pbr_maps(downloaded: Dict[str, str]) -> None:
    """
    Post-processes downloaded PBR maps (Albedo, Normal, Roughness, Metallic, Height)
    to eliminate outer 0..24px convolutional border roll-off (bright/dark edge halos in Albedo/Roughness,
    edge bevels in Normal, and edge steps/domes in Height) while preserving 100% of high-frequency grain phase.
    """
    try:
        import numpy as np
        from PIL import Image
        from scipy.ndimage import gaussian_filter

        for kind, path in downloaded.items():
            if not path or not os.path.exists(path):
                continue
            im = Image.open(path)
            mode = im.mode
            arr = np.asarray(im, dtype=np.float32)
            if arr.ndim == 2:
                arr = arr[:, :, None]
            h, w, ch = arr.shape
            if h < 64 or w < 64:
                continue

            proc_c = min(3, ch)
            is_normal = (kind == "normal")
            is_height = (kind == "height")

            if kind in ("albedo", "roughness"):
                sig_m = max(24.0, float(min(h, w)) * 0.055)
                st_m = 0.85 if kind == "albedo" else 0.80
                for c_m in range(proc_c):
                    ch_m = arr[:, :, c_m]
                    m_val = float(np.mean(ch_m))
                    low_m = gaussian_filter(ch_m, sigma=sig_m, mode="wrap")
                    ch_f = ch_m - st_m * (low_m - m_val)
                    res = ch_f - m_val
                    loc_var = gaussian_filter(res * res, sigma=sig_m, mode="wrap")
                    loc_std = np.sqrt(np.maximum(loc_var, 1e-4))
                    glob_std = float(np.std(res))
                    if glob_std > 0.4:
                        scale_c = np.clip(glob_std / loc_std, 0.55, 1.45)
                        ch_f = m_val + res * (0.30 + 0.70 * scale_c)
                    arr[:, :, c_m] = np.clip(ch_f, 0.0, 255.0)

            B = max(16, int(min(h, w) * 0.024))
            ref_w = max(8, B // 2)
            flat = B // 2
            taper = max(1, B - flat)
            w_d = np.ones((B, 1), dtype=np.float32)
            t_idx = np.arange(taper, dtype=np.float32)[:, None]
            w_d[flat:] = 0.5 * (1.0 + np.cos(np.pi * t_idx / float(taper)))
            w_dx = w_d.T
            sig_par = max(32.0, float(min(h, w)) * 0.08)

            for c_i in range(proc_c):
                channel = arr[:, :, c_i].copy()
                if is_height:
                    pad_d = max(32.0, float(min(h, w)) * 0.06)
                    low_d = gaussian_filter(channel, sigma=pad_d, mode="wrap")
                    channel = channel - low_d + float(np.median(channel))

                prof_tb = gaussian_filter(channel, sigma=(0.8, sig_par), mode="wrap")
                ref_t = np.mean(prof_tb[B:B+ref_w, :], axis=0, keepdims=True)
                ref_b = np.mean(prof_tb[h-B-ref_w:h-B, :], axis=0, keepdims=True)
                ref_tb = 0.5 * (ref_t + ref_b)
                channel[:B, :] -= w_d * (prof_tb[:B, :] - ref_tb)
                channel[h-B:, :] -= w_d[::-1] * (prof_tb[h-B:, :] - ref_tb)

                prof_lr = gaussian_filter(channel, sigma=(sig_par, 0.8), mode="wrap")
                ref_l = np.mean(prof_lr[:, B:B+ref_w], axis=1, keepdims=True)
                ref_r = np.mean(prof_lr[:, w-B-ref_w:w-B], axis=1, keepdims=True)
                ref_lr = 0.5 * (ref_l + ref_r)
                channel[:, :B] -= w_dx * (prof_lr[:, :B] - ref_lr)
                channel[:, w-B:] -= w_dx[:, ::-1] * (prof_lr[:, w-B:] - ref_lr)

                adj_tb = float(np.mean(np.abs(channel[B+4, :] - channel[B+5, :])))
                seam_tb = float(np.mean(np.abs(channel[0, :] - channel[-1, :])))
                if is_height or seam_tb > max(adj_tb * 1.08, adj_tb + 0.6):
                    M = max(24, int(min(h, w) * 0.04)) if is_height else max(12, int(min(h, w) * 0.016))
                    sig_s = 1.5 if is_height else 4.0
                    diff_tb = gaussian_filter(channel[0:1, :] - channel[h-1:h, :], sigma=(0.5, sig_s), mode="wrap")
                    m_idx = np.arange(M, dtype=np.float32)[:, None]
                    ramp_m = 0.5 * (0.5 * (1.0 + np.cos(np.pi * m_idx / float(M))))
                    channel[:M, :] -= ramp_m * diff_tb
                    channel[h-M:, :] += ramp_m[::-1] * diff_tb

                adj_lr = float(np.mean(np.abs(channel[:, B+4] - channel[:, B+5])))
                seam_lr = float(np.mean(np.abs(channel[:, 0] - channel[:, -1])))
                if is_height or seam_lr > max(adj_lr * 1.08, adj_lr + 0.6):
                    M = max(24, int(min(h, w) * 0.04)) if is_height else max(12, int(min(h, w) * 0.016))
                    sig_s = 1.5 if is_height else 4.0
                    diff_lr = gaussian_filter(channel[:, 0:1] - channel[:, w-1:w], sigma=(sig_s, 0.5), mode="wrap")
                    m_idx = np.arange(M, dtype=np.float32)[None, :]
                    ramp_mx = 0.5 * (0.5 * (1.0 + np.cos(np.pi * m_idx / float(M))))
                    channel[:, :M] -= ramp_mx * diff_lr
                    channel[:, w-M:] += ramp_mx[:, ::-1] * diff_lr

                arr[:, :, c_i] = channel

            if is_normal and proc_c >= 3:
                for c_xy in (0, 1):
                    ch_n = arr[:, :, c_xy]
                    low_n = gaussian_filter(ch_n, sigma=48.0, mode="wrap")
                    arr[:, :, c_xy] = ch_n - low_n + 128.0
                nx = (arr[:, :, 0] / 255.0) * 2.0 - 1.0
                ny = (arr[:, :, 1] / 255.0) * 2.0 - 1.0
                nz = np.maximum(0.1, (arr[:, :, 2] / 255.0) * 2.0 - 1.0)
                norm = np.sqrt(nx * nx + ny * ny + nz * nz) + 1e-6
                arr[:, :, 0] = ((nx / norm) * 0.5 + 0.5) * 255.0
                arr[:, :, 1] = ((ny / norm) * 0.5 + 0.5) * 255.0
                arr[:, :, 2] = ((nz / norm) * 0.5 + 0.5) * 255.0

            out_u8 = np.clip(arr, 0, 255).astype(np.uint8)
            if mode == "L" or out_u8.shape[2] == 1:
                Image.fromarray(out_u8[:, :, 0], mode="L").save(path, format="PNG")
            else:
                Image.fromarray(out_u8[:, :, :3], mode="RGB").save(path, format="PNG")
    except Exception:
        pass


def upload_image_to_comfy(image_path: str) -> str:
    """
    Uploads a local reference image to ComfyUI (/upload/image) and returns the uploaded filename
    for use in a `LoadImage` node.
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Reference image not found: {image_path}")

    boundary = f"----ComfyBoundary{random.randint(100000, 999999)}"
    filename = os.path.basename(image_path)
    ext = os.path.splitext(filename)[1].lower()
    mime = "image/png" if ext == ".png" else ("image/webp" if ext == ".webp" else "image/jpeg")

    with open(image_path, "rb") as f:
        file_bytes = f.read()

    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="image"; filename="{filename}"\r\n'
        f"Content-Type: {mime}\r\n\r\n"
    ).encode("utf-8") + file_bytes + (
        f"\r\n--{boundary}\r\n"
        f'Content-Disposition: form-data; name="overwrite"\r\n\r\n'
        f"true\r\n"
        f"--{boundary}--\r\n"
    ).encode("utf-8")

    req = urllib.request.Request(
        f"{COMFY_URL}/upload/image",
        data=body,
        headers=_comfy_headers({"Content-Type": f"multipart/form-data; boundary={boundary}"}),
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20.0) as resp:
        res = json.loads(resp.read().decode("utf-8"))
    return res.get("name", filename)


def extract_materials_from_reference_image(
    image_path: str,
    target_hint: str = "",
) -> List[Dict[str, Any]]:
    """
    Uses Gemini Vision (`gemini-2.5-flash`) to analyze a reference photo (either a close-up surface
    photo or a full interior design reference photo) and extract a list of PBR material definitions.
    Each item contains:
      - title_ru: Russian title (e.g. "Светлый дубовый паркет ёлочкой")
      - surface_ru: Target surface in room (e.g. "Пол", "Стены", "Обивка дивана", "Столешница")
      - prompt_en: Detailed English SDXL prompt for seamless top-down texture generation
      - category: One of (wood, stone, concrete, tile, brick, metal, fabric, glass, mirror, plastic, light)
      - roughness_mult: Recommended roughness multiplier (0.2..1.0)
      - ior: Recommended Corona IOR (1.35..2.4)
      - metalness: 0 or 1
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Файл референса не найден: {image_path}")

    with open(image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode("utf-8")

    ext = os.path.splitext(image_path)[1].lower()
    mime = "image/png" if ext == ".png" else ("image/webp" if ext == ".webp" else "image/jpeg")

    api_key = _load_gemini_api_key()
    if not api_key:
        for v_url in (
            "http://127.0.0.1:8788/api/vision_extract",
            "https://danya-pc.tail754f20.ts.net:10000/api/vision_extract",
            f"{COMFY_URL}/api/vision_extract",
        ):
            try:
                v_req = urllib.request.Request(
                    v_url,
                    data=json.dumps({"image_b64": img_b64, "mime_type": mime, "target_hint": target_hint}).encode("utf-8"),
                    headers=_comfy_headers({"Content-Type": "application/json"}),
                    method="POST",
                )
                with urllib.request.urlopen(v_req, timeout=30.0) as v_resp:
                    v_data = json.loads(v_resp.read().decode("utf-8"))
                if isinstance(v_data, dict) and isinstance(v_data.get("materials"), list) and v_data["materials"]:
                    return v_data["materials"]
            except Exception:
                continue
        raise RuntimeError("GEMINI_API_KEY не найден локально, а сервер AI Vision недоступен.")

    hint_instruction = (
        f"Пользователь особо указал интересующую поверхность/материал: '{target_hint}'. "
        "Поставь этот материал ПЕРВЫМ в списке и опиши его максимально точно."
        if target_hint.strip()
        else "Опиши ТОЛЬКО реальный материал/текстуру, изображённую на этом фото-референсе (первым элементом поставь главный материал кадра)."
    )

    system_prompt = (
        "Ты — ведущий 3D-художник и специалист по PBR-материалам (Unreal Engine 5 / CoronaPhysicalMtl) и генерации бесшовных текстур в SDXL + AI 5-Map PBR Engine.\n"
        f"{hint_instruction}\n"
        "Верни СТРОГО валидный JSON-массив объектов (без markdown-обертки), где каждый объект имеет поля:\n"
        '- "title_ru": краткое понятное название материала на русском\n'
        '- "surface_ru": где применяется (например, "Пол", "Стены", "Поверхность")\n'
        '- "prompt_en": детальный промпт на английском языке для генерации бесшовной однородной PBR-поверхности именно этого материала с фото (вид сверху, точный цвет, порода дерева/камня/бетона/ткани, характер волокон/прожилок/пор, степень матовости/глянца; НЕ добавляй кирпичную кладку, доски, паркетную ёлочку, панели, стыки, швы или прямые линии разреза, описывай чистую непрерывную однородную бесшовную поверхность материала)\n'
        '- "category": строго одно из значений: "wood", "stone", "concrete", "tile", "brick", "metal", "fabric", "glass", "mirror", "plastic", "light"\n'
        '- "ior": число float (обычно 1.5 для дерева/камня/пластика, 1.35 для ткани, 1.52 для стекла)\n'
        '- "metalness": 0 для диэлектриков, 1 для чистых металлов/зеркал\n'
        '- "clearcoat": число от 0.0 до 0.5'
    )

    payload = {
        "contents": [
            {
                "parts": [
                    {"text": system_prompt},
                    {"inline_data": {"mime_type": mime, "data": img_b64}},
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.2,
            "responseMimeType": "application/json",
            "thinkingConfig": {"thinkingBudget": 0},
        },
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30.0) as resp:
        resp_data = json.loads(resp.read().decode("utf-8"))

    raw_text = (
        resp_data.get("candidates", [{}])[0]
        .get("content", {})
        .get("parts", [{}])[0]
        .get("text", "[]")
    )
    raw_text = re.sub(r"^```(?:json)?|```$", "", raw_text.strip(), flags=re.MULTILINE).strip()
    parsed = json.loads(raw_text)
    if isinstance(parsed, dict):
        parsed = parsed.get("materials", [parsed])
    return parsed if isinstance(parsed, list) else []


_MODULAR_PROMPT_KEYWORDS = (
    "plank", "planks", "floorboard", "parquet", "herringbone", "chevron",
    "brick", "brickwork", "masonry", "tile", "tiles", "tiled", "mosaic", "grout", "mortar joint",
    "cobble", "cobblestone", "paving", "paver", "butcher block", "shingle", "slat", "slats",
    "pegboard", "checkerboard", "subway tile", "hexagon", "hexagonal", "terrazzo tile",
    "glulam", "clt", "plywood edge", "veneer plies", "multi-layer", "stepped concentric",
    "grid of", "ribbed", "fluted", "reeded", "diamond plate", "layer lines",
)


_MODULAR_PROMPT_RE = re.compile(
    r"\b(?:" + "|".join(re.escape(k) for k in _MODULAR_PROMPT_KEYWORDS) + r")s?\b",
    re.IGNORECASE,
)


def is_explicit_modular_prompt(prompt_en: str) -> bool:
    """Returns True only when the prompt explicitly requests discrete tiles, bricks, planks, slats, or geometric modules."""
    p_low = str(prompt_en or "").strip().lower()
    return bool(_MODULAR_PROMPT_RE.search(p_low))


def build_scaled_pbr_prompts(prompt_en: str, pattern_scale: float = 2.0, is_modular: Optional[bool] = None) -> tuple:
    """Returns concise (full_positive, full_negative) with minimal wording so extra tokens do not distort generation."""
    sc = float(pattern_scale or 2.0)
    modular = is_explicit_modular_prompt(prompt_en) if is_modular is None else bool(is_modular)
    if sc >= 2.8:
        scale_tag = "distant wide top-down"
        scale_neg = "close-up, macro, "
    elif sc >= 1.5:
        scale_tag = "wide top-down"
        scale_neg = "close-up, macro, "
    elif sc <= 0.65:
        scale_tag = "macro close-up top-down"
        scale_neg = "distant view, "
    else:
        scale_tag = "top-down"
        scale_neg = ""

    base_neg = (
        f"{scale_neg}perspective, angled view, 3d render, harsh shadows, vignette, blurry, watermark, text, border"
    )
    if modular:
        pos = f"{prompt_en}, {scale_tag} seamless pattern, flat even lighting, PBR texture"
        return pos, base_neg

    pos = f"{prompt_en}, {scale_tag} seamless texture, flat even lighting, PBR"
    continuous_neg = "planks, boards, tiles, bricks, grid, seams, joints, panels, "
    return pos, f"{continuous_neg}{base_neg}"


def _build_txt2pbr_workflow(
    prompt_en: str,
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    ckpt_name: str = "SDXL\\realvisxlV50_v50Bakedvae.safetensors",
    seed: Optional[int] = None,
    pattern_scale: float = 2.0,
) -> Dict[str, Any]:
    """Builds the ComfyUI workflow dict for Text/Preset -> Seamless PBR."""
    is_chord_pipe = pipeline_mode in ("chord", "flux_chord", "wan_chord")
    json_path = DEFAULT_JSON_CHORD if is_chord_pipe else DEFAULT_JSON_DA2
    if not os.path.exists(json_path):
        json_path = DEFAULT_JSON_DA2
    with open(json_path, "r", encoding="utf-8") as f:
        workflow = json.load(f)

    seed_val = int(seed) if seed is not None and int(seed) > 0 else random.randint(1, 2**31 - 1)

    clean_prompt_en = str(prompt_en or "").strip()
    low_clean = clean_prompt_en.lower()
    is_explicit_diag = any(k in low_clean for k in ("diagonal", "herringbone", "chevron", "twill", "45 degree", "diamond"))
    is_radial_or_random_wood = any(k in low_clean for k in ("burl", "ring", "cross-section", "cross-cut", "stump", "chipboard", "particleboard", "osb", "mdf", "cork", "bark", "pegboard", "fibrolit", "woodchip"))
    is_metal_prompt = any(k in low_clean for k in ("metal", "steel", "copper", "bronze", "brass", "gold", "chrome", "silver", "iron", "titanium", "aluminum", "aluminium", "mirror", "nickel", "platinum"))
    is_smooth_metal_prompt = is_metal_prompt and any(
        k in low_clean for k in ("polished", "satin", "bead-blasted", "mirror", "chrome", "smooth", "anodized")
    ) and not is_explicit_modular_prompt(clean_prompt_en)
    diag_neg = False
    if "brushed" in low_clean and not is_explicit_diag:
        align_prefix = "straight vertical grain, " if "vertical" in low_clean else "straight horizontal grain, "
        clean_prompt_en = align_prefix + clean_prompt_en
        diag_neg = True
    elif any(k in low_clean for k in ("wood", "veneer", "grain", "plank", "timber", "lumber", "plywood", "board")) and not is_radial_or_random_wood and not is_explicit_diag:
        align_prefix = "straight vertical grain, " if "vertical" in low_clean else "straight horizontal grain, "
        clean_prompt_en = align_prefix + clean_prompt_en
        diag_neg = True
    elif any(k in low_clean for k in ("fluted", "reeded", "ribbed", "slat", "striped", "brick", "tile", "parquet", "checkerboard", "grid", "cladding")) and not is_explicit_diag:
        align_prefix = "straight vertical lines, " if "vertical" in low_clean else "straight grid lines, "
        clean_prompt_en = align_prefix + clean_prompt_en
        diag_neg = True

    eff_pattern_scale = min(float(pattern_scale or 2.0), 1.0) if is_smooth_metal_prompt else pattern_scale
    full_positive, full_negative = build_scaled_pbr_prompts(clean_prompt_en, pattern_scale=eff_pattern_scale)
    if is_metal_prompt:
        full_negative = (
            "lamp, sconce, pendant, dome, faucet, knob, pipe, tube, 3d object, studio backdrop, reflection stripe, "
            + full_negative
        )
    if diag_neg:
        full_negative = "diagonal, slanted, tilted, skewed, " + full_negative

    if pipeline_mode == "wan_chord":
        workflow.pop("101", None)
        workflow["71"] = {
            "class_type": "UNETLoader",
            "inputs": {"unet_name": ckpt_name or "Wan2.1\\wan2.1_t2v_1.3B_bf16.safetensors", "weight_dtype": "default"},
        }
        workflow["71_clip"] = {
            "class_type": "CLIPLoader",
            "inputs": {"clip_name": "umt5_xxl_fp8_e4m3fn_scaled.safetensors", "type": "wan"},
        }
        workflow["71_vae"] = {
            "class_type": "VAELoader",
            "inputs": {"vae_name": "wan_2.1_vae.safetensors"},
        }
        workflow["72"] = {"class_type": "CLIPTextEncode", "inputs": {"text": full_positive, "clip": ["71_clip", 0]}}
        workflow["73"] = {"class_type": "CLIPTextEncode", "inputs": {"text": full_negative, "clip": ["71_clip", 0]}}
        workflow["77"] = {
            "class_type": "EmptyHunyuanLatentVideo",
            "inputs": {"width": 1024, "height": 1024, "length": 1, "batch_size": 1},
        }
        workflow["105"] = {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed_val,
                "steps": 20,
                "cfg": 6.0,
                "sampler_name": "uni_pc",
                "scheduler": "simple",
                "denoise": 1.0,
                "model": ["71", 0],
                "positive": ["72", 0],
                "negative": ["73", 0],
                "latent_image": ["77", 0],
            },
        }
        workflow["75"] = {
            "class_type": "VAEDecode",
            "inputs": {"samples": ["105", 0], "vae": ["71_vae", 0]},
        }
    else:
        if "71" in workflow and "inputs" in workflow["71"]:
            workflow["71"]["inputs"]["ckpt_name"] = ckpt_name
        if "72" in workflow and "inputs" in workflow["72"]:
            workflow["72"]["inputs"]["text"] = full_positive
        if "73" in workflow and "inputs" in workflow["73"]:
            workflow["73"]["inputs"]["text"] = full_negative
        if "77" in workflow and "inputs" in workflow["77"]:
            workflow["77"]["inputs"]["width"] = 1024
            workflow["77"]["inputs"]["height"] = 1024
        if pipeline_mode == "flux_chord" and "105" in workflow and "inputs" in workflow["105"]:
            workflow["105"]["inputs"]["steps"] = 20
            workflow["105"]["inputs"]["cfg"] = 1.0
            workflow["105"]["inputs"]["sampler_name"] = "euler"
            workflow["105"]["inputs"]["scheduler"] = "simple"

    _attach_pbr_decomposition_nodes(workflow, source_image_node=["102", 0], res_px=res_px, pipeline_mode=pipeline_mode)

    for _nid, node_data in workflow.items():
        inputs = node_data.get("inputs", {})
        if "seed" in inputs:
            inputs["seed"] = seed_val

    return workflow


def _build_bw_mask_workflow(
    prompt_en: str,
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    ckpt_name: str = "SDXL\\realvisxlV50_v50Bakedvae.safetensors",
    seed: Optional[int] = None,
) -> Tuple[Dict[str, Any], int]:
    """Builds a ComfyUI workflow dict for seamless B&W grayscale alpha mask generation."""
    seed_val = int(seed) if seed is not None and int(seed) > 0 else random.randint(1, 2**31 - 1)
    workflow = _build_txt2pbr_workflow(
        prompt_en=prompt_en,
        res_px=res_px,
        pipeline_mode=pipeline_mode,
        ckpt_name=ckpt_name,
        seed=seed_val,
    )

    full_positive = (
        f"{prompt_en}, top-down orthographic seamless continuous black and white grayscale alpha mask, "
        "high contrast monochrome stencil pattern, pure black and white values, flat studio map, 8k procedural pbr mask"
    )
    full_negative = (
        "color, colorful, rgb, saturation, 3d render, perspective, angled view, directional lighting, "
        "shadows, vignette, depth of field, blurry, watermark, text, border"
    )
    if "72" in workflow and "inputs" in workflow["72"]:
        workflow["72"]["inputs"]["text"] = full_positive
    if "73" in workflow and "inputs" in workflow["73"]:
        workflow["73"]["inputs"]["text"] = full_negative

    for unused_id in ("78", "79", "80", "81", "82", "84", "85", "86", "90", "108", "109", "110", "111", "112"):
        workflow.pop(unused_id, None)

    workflow["83"] = {
        "class_type": "ImageDesaturate+",
        "inputs": {
            "image": ["102", 0],
            "factor": 1.0,
            "method": "luminance (Rec.709)",
        },
    }
    mask_source: List[Any] = ["83", 0]
    target_res = int(res_px or 1024)
    if target_res != 1024:
        workflow["90"] = {
            "class_type": "ImageScale",
            "inputs": {
                "upscale_method": "lanczos" if target_res > 1024 else "area",
                "width": target_res,
                "height": target_res,
                "crop": "disabled",
                "image": mask_source,
            },
        }
        mask_source = ["90", 0]

    workflow["76"] = {
        "class_type": "SaveImage",
        "inputs": {"filename_prefix": "api_bw_mask", "images": mask_source},
    }

    for _nid, node_data in workflow.items():
        inputs = node_data.get("inputs", {})
        if "seed" in inputs:
            inputs["seed"] = seed_val

    return workflow, seed_val


def _fft_gauss_2d_np(arr: Any, np_mod: Any, sigma: float) -> Any:
    h, w = arr.shape
    fy = np_mod.fft.fftfreq(h)[:, None]
    fx = np_mod.fft.fftfreq(w)[None, :]
    gauss = np_mod.exp(-2.0 * (np_mod.pi ** 2) * (float(sigma) ** 2) * (fx * fx + fy * fy))
    return np_mod.fft.ifft2(np_mod.fft.fft2(arr) * gauss).real.astype(np_mod.float32)


def _frankot_chellappa_np(p: Any, q: Any, np_mod: Any, damp: float = 2e-3) -> Any:
    h, w = p.shape
    ky = 2.0 * np_mod.pi * np_mod.fft.fftfreq(h)[:, None]
    kx = 2.0 * np_mod.pi * np_mod.fft.fftfreq(w)[None, :]
    denom = kx * kx + ky * ky + float(damp)
    denom[0, 0] = 1.0
    z_spec = (-1j * kx * np_mod.fft.fft2(p) - 1j * ky * np_mod.fft.fft2(q)) / denom
    z_spec[0, 0] = 0.0
    return np_mod.fft.ifft2(z_spec).real.astype(np_mod.float32)


def _paeth_predictor(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def _read_png_rgb_stdlib(png_path: str) -> tuple[int, int, bytearray]:
    """Pure-stdlib 8-bit non-interlaced Gray/RGB/RGBA PNG reader returning (width, height, packed_rgb_bytearray)."""
    with open(png_path, "rb") as f:
        data = f.read()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Not a PNG file")
    pos = 8
    w = h = bit_depth = color_type = interlace = 0
    idat_parts = []
    n_tot = len(data)
    while pos + 8 <= n_tot:
        clen, ctype = struct.unpack(">I4s", data[pos:pos + 8])
        pos += 8
        chunk = data[pos:pos + clen]
        pos += clen + 4
        if ctype == b"IHDR":
            w, h, bit_depth, color_type, _comp, _flt, interlace = struct.unpack(">IIBBBBB", chunk)
        elif ctype == b"IDAT":
            idat_parts.append(chunk)
        elif ctype == b"IEND":
            break
    if bit_depth != 8 or interlace != 0 or color_type not in (0, 2, 6):
        raise ValueError(f"Unsupported PNG format: {w}x{h} bd={bit_depth} ct={color_type} il={interlace}")
    bpp = 1 if color_type == 0 else (3 if color_type == 2 else 4)
    stride = w * bpp
    raw = zlib.decompress(b"".join(idat_parts))
    prev = bytearray(stride)
    rgb_out = bytearray(w * h * 3)
    in_pos = 0
    out_pos = 0
    row_len_3 = w * 3
    for _y in range(h):
        ftype = raw[in_pos]
        in_pos += 1
        cur = bytearray(raw[in_pos:in_pos + stride])
        in_pos += stride
        if ftype == 1:
            for i in range(bpp, stride):
                cur[i] = (cur[i] + cur[i - bpp]) & 0xFF
        elif ftype == 2:
            for i in range(stride):
                cur[i] = (cur[i] + prev[i]) & 0xFF
        elif ftype == 3:
            for i in range(bpp):
                cur[i] = (cur[i] + (prev[i] >> 1)) & 0xFF
            for i in range(bpp, stride):
                cur[i] = (cur[i] + ((cur[i - bpp] + prev[i]) >> 1)) & 0xFF
        elif ftype == 4:
            for i in range(bpp):
                cur[i] = (cur[i] + prev[i]) & 0xFF
            for i in range(bpp, stride):
                cur[i] = (cur[i] + _paeth_predictor(cur[i - bpp], prev[i], prev[i - bpp])) & 0xFF
        elif ftype != 0:
            raise ValueError(f"Unsupported PNG filter {ftype}")
        prev = cur
        if bpp == 3:
            rgb_out[out_pos:out_pos + row_len_3] = cur
        elif bpp == 1:
            rgb_out[out_pos:out_pos + row_len_3:3] = cur
            rgb_out[out_pos + 1:out_pos + row_len_3:3] = cur
            rgb_out[out_pos + 2:out_pos + row_len_3:3] = cur
        else:
            rgb_out[out_pos:out_pos + row_len_3:3] = cur[0::4]
            rgb_out[out_pos + 1:out_pos + row_len_3:3] = cur[1::4]
            rgb_out[out_pos + 2:out_pos + row_len_3:3] = cur[2::4]
        out_pos += row_len_3
    return w, h, rgb_out


def heal_chord_normal_and_height_dipoles_disk(normal_path: str, height_path: str = "") -> Tuple[bool, str]:
    """
    Detects and heals isolated CHORD attention-sink dipole craters on disk PNGs
    via curl + per-axis high-pass outlier detection, directional clean patch-cloning
    on Normal, and periodic Frankot-Chellappa integration into Height.
    """
    n_p = os.path.abspath(str(normal_path or "").strip())
    h_p = os.path.abspath(str(height_path or "").strip()) if height_path else ""
    if not os.path.isfile(n_p):
        return (False, "skipped: missing normal")
    has_h = bool(h_p and os.path.isfile(h_p))
    try:
        import numpy as np  # type: ignore
    except Exception:
        return (False, "skipped: numpy unavailable")

    w, h, nrm_buf = _read_png_rgb_stdlib(n_p)
    if w < 64 or h < 64:
        return (False, "skipped: small dimensions")
    na = np.frombuffer(nrm_buf, dtype=np.uint8).reshape((h, w, 3)).astype(np.float32) / 255.0
    if has_h:
        hw, hh, hgt_buf = _read_png_rgb_stdlib(h_p)
        if hw != w or hh != h:
            has_h = False
            ha = None
        else:
            ha = np.frombuffer(hgt_buf, dtype=np.uint8).reshape((h, w, 3))[:, :, 0].astype(np.float32) / 255.0
    else:
        ha = None

    nx = na[:, :, 0] * 2.0 - 1.0
    ny = na[:, :, 1] * 2.0 - 1.0
    nz = np.clip(na[:, :, 2] * 2.0 - 1.0, 0.25, 1.0)
    sc = max(0.5, float(w) / 1024.0)

    dny_dx = np.roll(ny, -1, axis=1) - np.roll(ny, 1, axis=1)
    dnx_dy = np.roll(nx, -1, axis=0) - np.roll(nx, 1, axis=0)
    curl_s = np.abs(_fft_gauss_2d_np(dny_dx - dnx_dy, np, 2.0 * sc))
    cm = float(np.median(curl_s))
    cmad = float(np.median(np.abs(curl_s - cm))) * 1.4826 + 1e-6
    zc = (curl_s - cm) / cmad

    nx_hp = np.abs(_fft_gauss_2d_np(nx - _fft_gauss_2d_np(nx, np, 6.0 * sc), np, 1.5 * sc))
    ny_hp = np.abs(_fft_gauss_2d_np(ny - _fft_gauss_2d_np(ny, np, 6.0 * sc), np, 1.5 * sc))
    nxm = float(np.median(nx_hp))
    nxmad = float(np.median(np.abs(nx_hp - nxm))) * 1.4826 + 1e-6
    nym = float(np.median(ny_hp))
    nymad = float(np.median(np.abs(ny_hp - nym))) * 1.4826 + 1e-6
    znx = (nx_hp - nxm) / nxmad
    zny = (ny_hp - nym) / nymad

    seed = (
        ((zc > 6.8) & (curl_s > 0.030))
        | ((znx > 7.2) & (nx_hp > 0.035))
        | ((zny > 7.2) & (ny_hp > 0.035))
    )
    if has_h and ha is not None:
        ha_hp = np.abs(ha - _fft_gauss_2d_np(ha, np, 14.0 * sc))
        hm = float(np.median(ha_hp))
        hmad = float(np.median(np.abs(ha_hp - hm))) * 1.4826 + 1e-6
        zh = (ha_hp - hm) / hmad
        seed = seed | ((zh > 6.5) & (ha_hp > 0.25))

    seed_f = seed.astype(np.float32)
    min_px = max(8, int(12 * sc * sc))
    if int(seed_f.sum()) < min_px or float(seed_f.mean()) >= 0.03:
        return (False, "clean")

    mask_hard = (_fft_gauss_2d_np(seed_f, np, 14.0 * sc) > 0.008).astype(np.float32)
    mask_soft = np.clip(_fft_gauss_2d_np(mask_hard, np, 8.0 * sc), 0.0, 1.0)
    sh_d = max(48, int(96 * sc))
    if float(np.abs(ny).mean()) >= float(np.abs(nx).mean()):
        shifts = ((sh_d, 0), (-sh_d, 0), (int(1.5 * sh_d), 0), (0, sh_d))
    else:
        shifts = ((0, sh_d), (0, -sh_d), (0, int(1.5 * sh_d)), (sh_d, 0))

    nx_f = nx.copy()
    ny_f = ny.copy()
    rem = mask_soft > 0.001
    for dx, dy in shifts:
        m_sh = np.roll(np.roll(mask_hard, dy, axis=0), dx, axis=1)
        ok = rem & (m_sh < 0.01)
        if np.any(ok):
            nx_f[ok] = np.roll(np.roll(nx, dy, axis=0), dx, axis=1)[ok]
            ny_f[ok] = np.roll(np.roll(ny, dy, axis=0), dx, axis=1)[ok]
            rem = rem & (~ok)

    nx_c = nx * (1.0 - mask_soft) + nx_f * mask_soft
    ny_c = ny * (1.0 - mask_soft) + ny_f * mask_soft
    nz_c = np.sqrt(np.clip(1.0 - nx_c * nx_c - ny_c * ny_c, 0.04, 1.0))

    nrm_out = np.empty((h, w, 3), dtype=np.uint8)
    nrm_out[:, :, 0] = np.clip((nx_c * 0.5 + 0.5) * 255.0 + 0.5, 0.0, 255.0).astype(np.uint8)
    nrm_out[:, :, 1] = np.clip((ny_c * 0.5 + 0.5) * 255.0 + 0.5, 0.0, 255.0).astype(np.uint8)
    nrm_out[:, :, 2] = np.clip((nz_c * 0.5 + 0.5) * 255.0 + 0.5, 0.0, 255.0).astype(np.uint8)
    _write_png_rgb_stdlib(n_p, w, h, [bytearray(nrm_out[y].tobytes()) for y in range(h)])

    if has_h and ha is not None:
        hp_fc = _frankot_chellappa_np(-nx / nz, ny / nz, np, damp=5e-4)
        hm_fc = _frankot_chellappa_np(-nx / nz, -ny / nz, np, damp=5e-4)
        cp = float(np.corrcoef(ha.ravel(), hp_fc.ravel())[0, 1])
        cm_c = float(np.corrcoef(ha.ravel(), hm_fc.ravel())[0, 1])
        q_sgn = 1.0 if cp >= cm_c else -1.0
        h_clean = _frankot_chellappa_np(-nx_c / nz_c, q_sgn * ny_c / nz_c, np, damp=2e-3)
        lo, hi = np.percentile(h_clean, [0.5, 99.5])
        if (hi - lo) > 1e-4:
            h_out = np.clip(0.05 + 0.90 * (h_clean - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)
        else:
            h_out = np.clip(h_clean, 0.0, 1.0).astype(np.float32)
        h_u8 = np.clip(h_out * 255.0 + 0.5, 0.0, 255.0).astype(np.uint8)
        h_rgb = np.repeat(h_u8[:, :, None], 3, axis=2)
        _write_png_rgb_stdlib(h_p, w, h, [bytearray(h_rgb[y].tobytes()) for y in range(h)])

    return (True, f"healed dipole craters (mask={float(mask_hard.mean()) * 100:.2f}%, zc={float(zc.max()):.1f})")


def _write_png_rgb_stdlib(png_path: str, w: int, h: int, rows_rgb: list[bytearray]) -> None:
    """Pure-stdlib 8-bit RGB PNG writer (filter=0 per scanline, zlib level 3)."""
    def _chunk(ctype: bytes, payload: bytes) -> bytes:
        return struct.pack(">I", len(payload)) + ctype + payload + struct.pack(">I", zlib.crc32(ctype + payload) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    raw = bytearray((w * 3 + 1) * h)
    rlen = w * 3
    pos = 0
    for y in range(h):
        raw[pos] = 0
        raw[pos + 1:pos + 1 + rlen] = rows_rgb[y]
        pos += 1 + rlen
    idat = zlib.compress(bytes(raw), 3)
    tmp_path = png_path + ".tmp"
    os.makedirs(os.path.dirname(os.path.abspath(png_path)), exist_ok=True)
    with open(tmp_path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(_chunk(b"IHDR", ihdr))
        f.write(_chunk(b"IDAT", idat))
        f.write(_chunk(b"IEND", b""))
    os.replace(tmp_path, png_path)


def _resample_rgb_rows_512(w0: int, h0: int, rgb_bytes: bytearray) -> list[bytearray]:
    """Resamples flat RGB buffer to 512x512 list of bytearrays using fast 2x2 box (for 1024x1024) or nearest grid."""
    rows: list[bytearray] = []
    if w0 == 512 and h0 == 512:
        step = 1536
        for y in range(512):
            off = y * step
            rows.append(rgb_bytes[off:off + step])
        return rows
    if w0 == 1024 and h0 == 1024:
        rlen = 3072
        for y in range(512):
            r0 = rgb_bytes[(2 * y) * rlen:(2 * y) * rlen + rlen]
            r1 = rgb_bytes[(2 * y + 1) * rlen:(2 * y + 1) * rlen + rlen]
            dst = bytearray(1536)
            for c in range(3):
                a0 = r0[c::6]
                a1 = r0[c + 3::6]
                b0 = r1[c::6]
                b1 = r1[c + 3::6]
                dst[c::3] = bytes((a0[i] + a1[i] + b0[i] + b1[i] + 2) >> 2 for i in range(512))
            rows.append(dst)
        return rows
    for y in range(512):
        sy = min(h0 - 1, (y * h0) // 512)
        base = sy * w0 * 3
        dst = bytearray(1536)
        sx_list = [min(w0 - 1, (x * w0) // 512) * 3 for x in range(512)]
        p = 0
        for sx in sx_list:
            idx = base + sx
            dst[p:p + 3] = rgb_bytes[idx:idx + 3]
            p += 3
        rows.append(dst)
    return rows


def _crossfade_rows_in_place(canvas_rows: list[bytearray], top_rows: list[bytearray], bot_rows: list[bytearray], half_band: int = 12) -> None:
    """Applies a smooth 24px raised-cosine vertical crossfade across y=512 and toroidal wrap y=0/1024."""
    full_band = half_band * 2
    for idx in range(full_band):
        y = 512 - half_band + idx
        d = idx - half_band
        w_bot = 0.5 - 0.5 * math.cos(math.pi * (idx + 0.5) / full_band)
        w_top = 1.0 - w_bot
        if d < 0:
            row_a = top_rows[512 + d]
            row_b = bot_rows[max(0, min(511, -1 - d))]
        else:
            row_a = top_rows[max(0, min(511, 511 - d))]
            row_b = bot_rows[d]
        canvas_rows[y] = bytearray(int(row_a[k] * w_top + row_b[k] * w_bot + 0.5) for k in range(3072))

    for idx in range(full_band):
        y = (1024 - half_band + idx) % 1024
        d = idx - half_band
        w_top = 0.5 - 0.5 * math.cos(math.pi * (idx + 0.5) / full_band)
        w_bot = 1.0 - w_top
        if d < 0:
            row_b = bot_rows[512 + d]
            row_a = top_rows[max(0, min(511, -1 - d))]
        else:
            row_b = bot_rows[max(0, min(511, 511 - d))]
            row_a = top_rows[d]
        canvas_rows[y] = bytearray(int(row_b[k] * w_bot + row_a[k] * w_top + 0.5) for k in range(3072))


def prepare_4x_expansion_canvas(image_path: str, out_dir: str = "") -> Tuple[str, bool]:
    """
    Builds a 1024x1024 staggered-mirror 2x2 seamless seed canvas (512px scale per tile)
    so non-inpainting SDXL + SeamlessTile can expand a surface cleanly to 4x area without
    blank borders or butterfly mirror creases.
    Returns `(canvas_png_path, is_precomposed_2x2)`.
    """
    dst_dir = (out_dir or "").strip() or os.path.dirname(os.path.abspath(image_path))
    out_path = os.path.join(dst_dir, "expand4x_canvas_1024.png")
    shift_px = 341
    shift_b = shift_px * 3

    try:
        from PIL import Image
        im = Image.open(image_path).convert("RGB").resize((512, 512), Image.Resampling.BICUBIC)
        raw_tile = im.tobytes()
        top_src: list[bytearray] = []
        for y in range(512):
            row_l = bytearray(raw_tile[y * 1536:(y + 1) * 1536])
            row_r = bytearray(1536)
            row_r[0::3] = row_l[0::3][::-1]
            row_r[1::3] = row_l[1::3][::-1]
            row_r[2::3] = row_l[2::3][::-1]
            top_src.append(row_l + row_r)
        bot_src = [top_src[511 - y][shift_b:] + top_src[511 - y][:shift_b] for y in range(512)]
        canvas_rows = [bytearray(r) for r in top_src] + [bytearray(r) for r in bot_src]
        _crossfade_rows_in_place(canvas_rows, top_src, bot_src, half_band=24)
        out_im = Image.frombytes("RGB", (1024, 1024), b"".join(bytes(r) for r in canvas_rows))
        os.makedirs(dst_dir, exist_ok=True)
        tmp_path = out_path + ".tmp"
        out_im.save(tmp_path, format="PNG")
        os.replace(tmp_path, out_path)
        return out_path, True
    except ImportError:
        pass
    except Exception:
        pass

    try:
        w0, h0, rgb_buf = _read_png_rgb_stdlib(image_path)
        tile_rows = _resample_rgb_rows_512(w0, h0, rgb_buf)
        top_src = []
        for y in range(512):
            row_l = tile_rows[y]
            row_r = bytearray(1536)
            row_r[0::3] = row_l[0::3][::-1]
            row_r[1::3] = row_l[1::3][::-1]
            row_r[2::3] = row_l[2::3][::-1]
            top_src.append(row_l + row_r)
        bot_src = [top_src[511 - y][shift_b:] + top_src[511 - y][:shift_b] for y in range(512)]
        canvas_rows = [bytearray(r) for r in top_src] + [bytearray(r) for r in bot_src]
        _crossfade_rows_in_place(canvas_rows, top_src, bot_src, half_band=24)
        _write_png_rgb_stdlib(out_path, 1024, 1024, canvas_rows)
        return out_path, True
    except Exception:
        return image_path, False


def _build_outpaint_4x_pbr_workflow(
    uploaded_comfy_filename: str,
    prompt_en: str = "",
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    ckpt_name: str = "SDXL\\realvisxlV50_v50Bakedvae.safetensors",
    feather_px: int = 48,
    denoise: float = 0.68,
    seed: Optional[int] = None,
    precomposed_2x2: bool = False,
) -> Dict[str, Any]:
    """
    Generative 4x (2x2 area) Seamless Texture Expansion workflow (Staggered 2x2 Seed Canvas + SeamlessTile Img2Img + 5-Map PBR).
    """
    eff_res = int(res_px or 1024)
    eff_ckpt = ckpt_name if (ckpt_name and "sdxl" in str(ckpt_name).lower()) else "SDXL\\realvisxlV50_v50Bakedvae.safetensors"
    eff_pbr_pipe = "da2" if pipeline_mode == "da2" else "chord"
    eff_seed = int(seed) if seed is not None else random.randint(1, 2**31 - 1)
    clean_prompt = str(prompt_en or "").strip() or (
        "homogeneous architectural surface texture, matching natural color palette and surface micro-detail"
    )
    _is_modular = is_explicit_modular_prompt(clean_prompt)
    if _is_modular:
        full_positive = f"{clean_prompt}, top-down seamless pattern, flat even lighting, PBR texture"
        full_negative = (
            "perspective, angled view, 3d render, harsh shadows, vignette, blurry, seam, border, watermark, text"
        )
    else:
        full_positive = f"{clean_prompt}, top-down seamless texture, flat even lighting, PBR"
        full_negative = (
            "planks, boards, tiles, bricks, grid, seams, joints, panels, "
            "perspective, angled view, 3d render, harsh shadows, vignette, blurry, border, watermark, text"
        )

    workflow: Dict[str, Any] = {
        "71": {
            "class_type": "CheckpointLoaderSimple",
            "inputs": {"ckpt_name": eff_ckpt},
        },
        "101": {
            "class_type": "SeamlessTile",
            "inputs": {
                "model": ["71", 0],
                "tiling": "enable",
                "copy_model": "Modify in place",
            },
        },
        "72": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": full_positive, "clip": ["71", 1]},
        },
        "73": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": full_negative, "clip": ["71", 1]},
        },
        "200": {
            "class_type": "LoadImage",
            "inputs": {"image": uploaded_comfy_filename},
        },
    }

    if precomposed_2x2:
        workflow["201"] = {
            "class_type": "ImageScale",
            "inputs": {
                "upscale_method": "bicubic",
                "width": 1024,
                "height": 1024,
                "crop": "disabled",
                "image": ["200", 0],
            },
        }
        vae_src = ["201", 0]
    else:
        workflow["201"] = {
            "class_type": "ImageScale",
            "inputs": {
                "upscale_method": "bicubic",
                "width": 512,
                "height": 512,
                "crop": "disabled",
                "image": ["200", 0],
            },
        }
        workflow["202"] = {
            "class_type": "ImagePadKJ",
            "inputs": {
                "image": ["201", 0],
                "left": 0,
                "right": 512,
                "top": 0,
                "bottom": 512,
                "extra_padding": 0,
                "pad_mode": "edge",
                "color": "128, 128, 128",
            },
        }
        workflow["202_tr"] = {
            "class_type": "ImageCompositeMasked",
            "inputs": {
                "destination": ["202", 0],
                "source": ["201", 0],
                "x": 512,
                "y": 0,
                "resize_source": False,
            },
        }
        workflow["202_bl"] = {
            "class_type": "ImageCompositeMasked",
            "inputs": {
                "destination": ["202_tr", 0],
                "source": ["201", 0],
                "x": 0,
                "y": 512,
                "resize_source": False,
            },
        }
        workflow["202_br"] = {
            "class_type": "ImageCompositeMasked",
            "inputs": {
                "destination": ["202_bl", 0],
                "source": ["201", 0],
                "x": 512,
                "y": 512,
                "resize_source": False,
            },
        }
        vae_src = ["202_br", 0]

    workflow["205"] = {
        "class_type": "VAEEncode",
        "inputs": {"pixels": vae_src, "vae": ["71", 2]},
    }
    workflow["105"] = {
        "class_type": "KSampler",
        "inputs": {
            "seed": eff_seed,
            "steps": 28,
            "cfg": 5.2,
            "sampler_name": "dpmpp_2m",
            "scheduler": "karras",
            "denoise": float(max(0.45, min(0.80, float(denoise)))),
            "model": ["101", 0],
            "positive": ["72", 0],
            "negative": ["73", 0],
            "latent_image": ["205", 0],
        },
    }
    workflow["75"] = {
        "class_type": "CircularVAEDecode",
        "inputs": {"samples": ["105", 0], "vae": ["71", 2], "tiling": "enable"},
    }

    if eff_res >= 2048:
        workflow["210"] = {
            "class_type": "UpscaleModelLoader",
            "inputs": {"model_name": "RealESRGAN_x2plus.pth"},
        }
        workflow["211"] = {
            "class_type": "ImageUpscaleWithModel",
            "inputs": {"upscale_model": ["210", 0], "image": ["75", 0]},
        }
        detail_src = ["211", 0]
        detail_mult = 1.15
    else:
        detail_src = ["75", 0]
        detail_mult = 1.18

    workflow["102"] = {
        "class_type": "EnhanceDetail",
        "inputs": {
            "images": detail_src,
            "filter_radius": 2,
            "sigma": 0.1,
            "denoise": 0.03,
            "detail_mult": detail_mult,
        },
    }
    _attach_pbr_decomposition_nodes(
        workflow,
        source_image_node=["102", 0],
        res_px=eff_res,
        pipeline_mode=eff_pbr_pipe,
    )
    return workflow


def _probe_image_size(image_path: str) -> Tuple[int, int]:
    """
    Returns `(width, height)` for common image formats (PNG, JPEG, BMP, GIF, WebP, TGA).
    Uses PIL if available and falls back to pure-Python header parsing so embedded runtimes
    without Pillow (e.g. UE5 Python) still determine exact aspect ratios.
    """
    p = str(image_path or "").strip()
    if not p or not os.path.isfile(p):
        return (0, 0)
    try:
        from PIL import Image
        with Image.open(p) as im:
            return (int(im.size[0]), int(im.size[1]))
    except Exception:
        pass
    try:
        with open(p, "rb") as f:
            head = f.read(64)
            if len(head) >= 24 and head[:8] == b"\x89PNG\r\n\x1a\n":
                w, h = struct.unpack(">II", head[16:24])
                return (int(w), int(h))
            if len(head) >= 26 and head[:2] == b"BM":
                w, h = struct.unpack("<ii", head[18:26])
                return (abs(int(w)), abs(int(h)))
            if len(head) >= 10 and head[:6] in (b"GIF87a", b"GIF89a"):
                w, h = struct.unpack("<HH", head[6:10])
                return (int(w), int(h))
            if len(head) >= 30 and head[:4] == b"RIFF" and head[8:12] == b"WEBP":
                chunk = head[12:16]
                if chunk == b"VP8X" and len(head) >= 30:
                    w = 1 + int.from_bytes(head[24:27], "little")
                    h = 1 + int.from_bytes(head[27:30], "little")
                    return (w, h)
                if chunk == b"VP8 " and len(head) >= 30:
                    w, h = struct.unpack("<HH", head[26:30])
                    return (w & 0x3FFF, h & 0x3FFF)
                if chunk == b"VP8L" and len(head) >= 25:
                    b0, b1, b2, b3 = head[21:25]
                    bits = b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
                    return ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
            if len(head) >= 2 and head[:2] == b"\xff\xd8":
                f.seek(2)
                while True:
                    b = f.read(1)
                    if not b:
                        break
                    while b == b"\xff":
                        b = f.read(1)
                    if not b:
                        break
                    marker = b[0]
                    if marker in (0xD8, 0xD9, 0x00, 0x01) or (0xD0 <= marker <= 0xD7):
                        continue
                    seg_len_b = f.read(2)
                    if len(seg_len_b) < 2:
                        break
                    seg_len = struct.unpack(">H", seg_len_b)[0]
                    if (0xC0 <= marker <= 0xCF) and marker not in (0xC4, 0xC8, 0xCC):
                        sof = f.read(5)
                        if len(sof) == 5:
                            h, w = struct.unpack(">HH", sof[1:5])
                            return (int(w), int(h))
                        break
                    if seg_len >= 2:
                        f.seek(seg_len - 2, os.SEEK_CUR)
            if p.lower().endswith(".tga") and len(head) >= 18:
                w, h = struct.unpack("<HH", head[12:16])
                if 16 <= w <= 16384 and 16 <= h <= 16384:
                    return (int(w), int(h))
    except Exception:
        pass
    return (0, 0)


def compute_aspect_preserving_dims(
    image_path: str,
    max_side: int = 1024,
    multiple: int = 16,
    min_dim: int = 64,
    max_dim: int = 4096,
) -> Tuple[int, int]:
    """
    Scales `(orig_w, orig_h)` so the longest side equals `max_side` (clamped to `[min_dim, max_dim]`)
    while preserving exact aspect ratio and rounding both dimensions to `multiple` (16).
    """
    cap = max(min_dim, min(max_dim, int(max_side or 1024)))
    orig_w, orig_h = _probe_image_size(image_path)
    if orig_w <= 0 or orig_h <= 0:
        return (cap, cap)
    long_side = max(orig_w, orig_h)
    scale = float(cap) / float(long_side)
    raw_w = float(orig_w) * scale
    raw_h = float(orig_h) * scale
    mult = max(1, int(multiple))
    out_w = max(min_dim, min(max_dim, int(round(raw_w / mult)) * mult))
    out_h = max(min_dim, min(max_dim, int(round(raw_h / mult)) * mult))
    return (out_w, out_h)


def _build_reference_pbr_workflow(
    uploaded_comfy_filename: str,
    ref_mode: str = "chord_direct",
    prompt_en: str = "",
    denoise: float = 0.55,
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    ckpt_name: str = "SDXL\\realvisxlV50_v50Bakedvae.safetensors",
    seed: Optional[int] = None,
    pattern_scale: float = 1.0,
    target_w: Optional[int] = None,
    target_h: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Builds a ComfyUI workflow for Reference Image -> Corona/UE5 PBR:
      - ref_mode == 'outpaint_4x':
          Generative 4x (2x2 area) seamless texture expansion (outpainting around center tile + 5-map PBR).
      - ref_mode == 'chord_direct' OR denoise <= 0.01:
          Directly feeds the uploaded photo into ImageScale -> EnhanceDetail -> AI 5-Map PBR Engine
          (extracts Albedo, Normal, Roughness, Metallic, Height directly from the reference photo without diffusion).
          When denoise <= 0.01, Albedo ('76') is taken directly from the scaled input image ('201') so an
          already-seamless diffuse texture is preserved 100% untouched.
      - ref_mode == 'img2img_seamless' (with denoise > 0.01):
          Loads the reference image -> scales to 1024x1024 -> VAEEncode -> SeamlessTile KSampler (denoise)
          -> CircularVAEDecode -> EnhanceDetail -> AI 5-Map PBR Engine (creates a 100% seamless tileable texture
          preserving the color/structure of the reference photo).
    """
    if ref_mode == "outpaint_4x":
        return _build_outpaint_4x_pbr_workflow(
            uploaded_comfy_filename=uploaded_comfy_filename,
            prompt_en=prompt_en,
            res_px=res_px,
            pipeline_mode=pipeline_mode,
            ckpt_name=ckpt_name,
            denoise=float(denoise) if 0.45 <= float(denoise) <= 0.80 else 0.68,
            seed=seed,
            precomposed_2x2=False,
        )
    keep_exact_albedo = float(denoise) <= 0.01
    if ref_mode == "chord_direct" or keep_exact_albedo:
        eff_w = max(64, min(4096, int(target_w or res_px or 1024)))
        eff_h = max(64, min(4096, int(target_h or res_px or 1024)))
        workflow: Dict[str, Any] = {
            "200": {
                "class_type": "LoadImage",
                "inputs": {"image": uploaded_comfy_filename},
            },
            "201": {
                "class_type": "ImageScale",
                "inputs": {
                    "upscale_method": "bicubic",
                    "width": eff_w,
                    "height": eff_h,
                    "crop": "disabled",
                    "image": ["200", 0],
                },
            },
            "102": {
                "class_type": "EnhanceDetail",
                "inputs": {
                    "images": ["201", 0],
                    "filter_radius": 2,
                    "sigma": 0.1,
                    "denoise": 0.03,
                    "detail_mult": 1.20,
                },
            },
            "76": {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_albedo", "images": ["201", 0]}},
            "80": {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_height", "images": ["102", 0]}},
            "82": {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_normal", "images": ["102", 0]}},
            "85": {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_roughness", "images": ["102", 0]}},
        }
        _attach_pbr_decomposition_nodes(
            workflow,
            source_image_node=["102", 0],
            res_px=res_px,
            pipeline_mode=pipeline_mode,
            target_w=eff_w,
            target_h=eff_h,
            already_scaled=True,
        )
        if "76" in workflow:
            workflow["76"]["inputs"]["images"] = ["201", 0]
        return workflow

    # Otherwise: 'img2img_seamless' (Reference Image -> Seamless Tileable Variation -> 5-map PBR)
    eff_pipe_for_ref = "chord" if pipeline_mode == "wan_chord" else pipeline_mode
    eff_ckpt_for_ref = "SDXL\\realvisxlV50_v50Bakedvae.safetensors" if pipeline_mode == "wan_chord" else ckpt_name
    workflow = _build_txt2pbr_workflow(
        prompt_en=prompt_en or "homogeneous architectural surface texture, uniform flat lighting, consistent natural micro-relief",
        res_px=res_px,
        pipeline_mode=eff_pipe_for_ref,
        ckpt_name=eff_ckpt_for_ref,
        seed=seed,
        pattern_scale=pattern_scale,
    )
    workflow.pop("77", None)  # Replace EmptyLatentImage with LoadImage -> ImageScale(1024x1024) -> VAEEncode
    workflow["200"] = {
        "class_type": "LoadImage",
        "inputs": {"image": uploaded_comfy_filename},
    }
    workflow["201"] = {
        "class_type": "ImageScale",
        "inputs": {
            "upscale_method": "bicubic",
            "width": 1024,
            "height": 1024,
            "crop": "disabled",
            "image": ["200", 0],
        },
    }
    workflow["202"] = {
        "class_type": "VAEEncode",
        "inputs": {
            "pixels": ["201", 0],
            "vae": ["71", 2],
        },
    }
    if "75" in workflow and "inputs" in workflow["75"]:
        workflow["75"]["inputs"]["vae"] = ["71", 2]
    if "102" in workflow and "inputs" in workflow["102"]:
        workflow["102"]["inputs"]["detail_mult"] = 1.12
        workflow["102"]["inputs"]["denoise"] = 0.02
    if "105" in workflow and "inputs" in workflow["105"]:
        workflow["105"]["inputs"]["latent_image"] = ["202", 0]
        eff_denoise = float(max(0.02, min(0.95, float(denoise))))
        workflow["105"]["inputs"]["denoise"] = eff_denoise
        workflow["105"]["inputs"]["cfg"] = 4.0

    return workflow


def _attach_pbr_decomposition_nodes(
    workflow: Dict[str, Any],
    source_image_node: List[Any],
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    target_w: Optional[int] = None,
    target_h: Optional[int] = None,
    already_scaled: bool = False,
) -> None:
    """Attaches either AI 5-Map PBR Engine (5-map) or DepthAnything V2 (4-map) nodes to `workflow` and enforces exact target resolution on all output maps."""
    target_res = int(res_px or 1024)
    eff_w = max(64, min(4096, int(target_w or target_res)))
    eff_h = max(64, min(4096, int(target_h or target_res)))
    if pipeline_mode in ("chord", "flux_chord", "wan_chord"):
        for old_id in ("78", "79", "81", "83", "84", "108", "109"):
            workflow.pop(old_id, None)

        chord_img_input = source_image_node
        if (not already_scaled) and (eff_w != 1024 or eff_h != 1024):
            workflow["90"] = {
                "class_type": "ImageScale",
                "inputs": {
                    "upscale_method": "bicubic" if max(eff_w, eff_h) > 1024 else "area",
                    "width": eff_w,
                    "height": eff_h,
                    "crop": "disabled",
                    "image": source_image_node,
                },
            }
            chord_img_input = ["90", 0]

        workflow["110"] = {
            "class_type": "ChordLoadModel",
            "inputs": {"ckpt_name": "chord_v1.safetensors"},
        }
        workflow["111"] = {
            "class_type": "ChordMaterialEstimation",
            "inputs": {
                "chord_model": ["110", 0],
                "image": chord_img_input,
            },
        }
        workflow["112"] = {
            "class_type": "ChordNormalToHeight",
            "inputs": {"normal": ["111", 1]},
        }
        workflow["76"] = {
            "class_type": "SaveImage",
            "inputs": {"filename_prefix": "api_albedo", "images": ["111", 0]},
        }
        workflow["82"] = {
            "class_type": "SaveImage",
            "inputs": {"filename_prefix": "api_normal", "images": ["111", 1]},
        }
        workflow["85"] = {
            "class_type": "SaveImage",
            "inputs": {"filename_prefix": "api_roughness", "images": ["111", 2]},
        }
        workflow["80"] = {
            "class_type": "SaveImage",
            "inputs": {"filename_prefix": "api_height", "images": ["112", 0]},
        }
        workflow["86"] = {
            "class_type": "SaveImage",
            "inputs": {"filename_prefix": "api_metallic", "images": ["111", 3]},
        }
    else:
        scaled_src = source_image_node
        if (not already_scaled) and (eff_w != 1024 or eff_h != 1024):
            workflow["90"] = {
                "class_type": "ImageScale",
                "inputs": {
                    "upscale_method": "bicubic" if max(eff_w, eff_h) > 1024 else "area",
                    "width": eff_w,
                    "height": eff_h,
                    "crop": "disabled",
                    "image": source_image_node,
                },
            }
            scaled_src = ["90", 0]
        workflow["79"] = {
            "class_type": "DownloadAndLoadDepthAnythingV2Model",
            "inputs": {
                "model": "depth_anything_v2_vitl_fp16.safetensors",
                "precision": "fp32",
            },
        }
        workflow["78"] = {
            "class_type": "DepthAnything_V2",
            "inputs": {
                "da_model": ["79", 0],
                "images": scaled_src,
            },
        }
        workflow["81"] = {
            "class_type": "NormalMapSimple",
            "inputs": {
                "images": scaled_src,
                "scale_XY": 1.5,
            },
        }
        workflow["83"] = {
            "class_type": "ImageDesaturate+",
            "inputs": {
                "image": scaled_src,
                "factor": 1.0,
                "method": "luminance (Rec.709)",
            },
        }
        workflow["84"] = {
            "class_type": "ImageInvert",
            "inputs": {"image": ["83", 0]},
        }
        workflow["76"] = {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_albedo", "images": scaled_src}}
        workflow["80"] = {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_height", "images": ["78", 0]}}
        workflow["82"] = {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_normal", "images": ["81", 0]}}
        workflow["85"] = {"class_type": "SaveImage", "inputs": {"filename_prefix": "api_roughness", "images": ["84", 0]}}


def cancel_comfy_generation() -> bool:
    """Interrupts any running ComfyUI prompt and clears pending queue."""
    ok_any = False
    for path, payload in (("/interrupt", b"{}"), ("/queue", b'{"clear": true}')):
        try:
            req = urllib.request.Request(
                f"{COMFY_URL}{path}",
                data=payload,
                headers=_comfy_headers({"Content-Type": "application/json"}),
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=4.0):
                ok_any = True
        except Exception:
            pass
    return ok_any


def test_comfy_connection(timeout_sec: float = 4.0) -> Tuple[bool, str]:
    """Probes ComfyUI /system_stats to verify connectivity and GPU status."""
    try:
        with _comfy_get(f"{COMFY_URL}/system_stats", timeout=timeout_sec) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        devices = data.get("devices") or []
        if devices and isinstance(devices, list):
            gpu_name = devices[0].get("name") or "GPU"
            vram_gb = (devices[0].get("vram_total") or 0) / (1024 ** 3)
            if vram_gb > 0:
                return True, f"Connected ({gpu_name}, {vram_gb:.1f} GB VRAM)"
            return True, f"Connected ({gpu_name})"
        return True, f"Connected ({COMFY_URL})"
    except Exception as exc:
        return False, str(exc)


def execute_comfy_workflow_and_download(
    workflow: Dict[str, Any],
    dest_folder: str,
    asset_base_name: str,
    progress_cb: Optional[Callable[[str], None]] = None,
    timeout_sec: int = 600,
    is_bw_mask: bool = False,
    enforce_seamless: bool = True,
) -> Dict[str, str]:
    """
    Submits `workflow` to ComfyUI (`http://127.0.0.1:8188/prompt`), waits for completion,
    and downloads the generated PBR textures (`albedo`, `normal`, `roughness`, `metallic`, `height`)
    into `dest_folder`.
    """
    os.makedirs(dest_folder, exist_ok=True)
    req = urllib.request.Request(
        f"{COMFY_URL}/prompt",
        data=json.dumps({"prompt": workflow}).encode("utf-8"),
        headers=_comfy_headers({"Content-Type": "application/json"}),
        method="POST",
    )
    import urllib.error as _urllib_err
    for _attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=45.0) as resp:
                res_data = json.loads(resp.read().decode("utf-8"))
            break
        except _urllib_err.HTTPError:
            raise
        except Exception:
            if _attempt >= 1:
                raise
            if progress_cb:
                progress_cb("Retrying server connection...")
            time.sleep(2.0)
    prompt_id = res_data["prompt_id"]

    start_t = time.time()
    node_to_kind = {
        "76": "albedo",
        "80": "height",
        "82": "normal",
        "85": "roughness",
        "86": "metallic",
        "91": "albedo",
        "92": "height",
        "93": "normal",
        "94": "roughness",
        "95": "metallic",
    }

    downloaded: Dict[str, str] = {}
    while True:
        elapsed = int(time.time() - start_t)
        if elapsed > timeout_sec:
            raise TimeoutError(f"ComfyUI generation timed out after {timeout_sec}s")
        if progress_cb:
            progress_cb(f"Генерация в ComfyUI... ({elapsed} сек)")

        try:
            with _comfy_get(f"{COMFY_URL}/history/{prompt_id}", timeout=12.0) as h_resp:
                history = json.loads(h_resp.read().decode("utf-8"))
            if prompt_id in history:
                entry = history[prompt_id]
                st_info = entry.get("status", {})
                if st_info.get("status_str") == "error":
                    raise RuntimeError(f"ComfyUI internal error: {st_info}")

                outputs = entry.get("outputs", {})
                for nid, node_out in outputs.items():
                    for image in node_out.get("images", []):
                        fname = image["filename"]
                        kind = "mask" if is_bw_mask or fname.lower().startswith("api_bw_mask") else node_to_kind.get(str(nid))
                        if not kind:
                            low_f = fname.lower()
                            if "mask" in low_f:
                                kind = "mask"
                            elif "normal" in low_f:
                                kind = "normal"
                            elif "rough" in low_f:
                                kind = "roughness"
                            elif "height" in low_f:
                                kind = "height"
                            elif "metal" in low_f:
                                kind = "metallic"
                            else:
                                kind = "albedo"

                        params = urllib.parse.urlencode(
                            {
                                "filename": fname,
                                "subfolder": image.get("subfolder", ""),
                                "type": image.get("type", "output"),
                            }
                        )
                        img_bytes = _comfy_get(f"{COMFY_URL}/view?{params}", timeout=45.0).read()
                        clean_filename = (
                            f"{asset_base_name}.png"
                            if kind == "mask"
                            else f"T_{asset_base_name}_{kind.capitalize()}.png"
                        )
                        local_path = os.path.join(dest_folder, clean_filename)
                        with open(local_path, "wb") as out_f:
                            out_f.write(img_bytes)
                        downloaded[kind] = local_path

                try:
                    free_req = urllib.request.Request(
                        f"{COMFY_URL}/free",
                        data=b'{"unload_models": false, "free_memory": true}',
                        headers=_comfy_headers({"Content-Type": "application/json"}),
                        method="POST",
                    )
                    urllib.request.urlopen(free_req, timeout=3.0).read()
                except Exception:
                    pass
                break
        except RuntimeError:
            raise
        except Exception:
            pass
        time.sleep(1.0)

    if not is_bw_mask and enforce_seamless:
        enforce_seamless_pbr_maps(downloaded)
    return downloaded


LOCAL_PBR_SLOT_SPECS = [
    ("albedo", "Albedo / Diff", False, False),
    ("normal", "Normal (DX/GL)", False, True),
    ("roughness", "Rough / Gloss", True, False),
    ("height", "Height / Disp", True, False),
    ("metallic", "Metallic", True, False),
    ("opacity", "Opacity / Mask", True, False),
]

LOCAL_PBR_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".tga", ".bmp", ".exr", ".tif", ".tiff", ".psd", ".hdr"
}

_LOCAL_PBR_EXT_RANK = {
    ".png": 5,
    ".exr": 5,
    ".tif": 4,
    ".tiff": 4,
    ".tga": 3,
    ".jpg": 2,
    ".jpeg": 2,
    ".bmp": 1,
    ".psd": 1,
    ".hdr": 1,
}

_LOCAL_PBR_SUFFIX_RE = re.compile(
    r"(?:_|-|\s)+(?:"
    r"1k|2k|4k|8k|16k|jpg|jpeg|png|exr|tga|tif|tiff|"
    r"base[\s_-]*color|albedo|diffuse|diff|dif|color|col|alb|bc|"
    r"normal[\s_-]*dx|normal[\s_-]*gl|normal[\s_-]*map|normal|nrml|nrm|norm|nor|"
    r"roughness|rough[\s_-]*map|rough|rgh|glossiness|gloss|gls|smoothness|refl[\s_-]*gloss|rgloss|"
    r"displacement|disp|height[\s_-]*map|height|hgt|bump|"
    r"metallic|metalness|metal|met|refl[\s_-]*metal|"
    r"opacity|alpha|cutout|transparency|transp|opac|mask|"
    r"ao|ambient[\s_-]*occlusion|occlusion"
    r")$",
    re.IGNORECASE,
)


def _mxs_quote_escape(text: str) -> str:
    """Escapes backslashes and double quotes for safe embedding inside MAXScript string literals."""
    return str(text or "").replace("\\", "/").replace('"', '\\"')


def classify_pbr_texture_filename(file_path: str) -> Tuple[str, Dict[str, Any]]:
    """
    Classifies a downloaded PBR texture filename into `(slot_key, hints_dict)`.
    Returns `("", {})` for preview thumbnails or unrecognized non-map files.
    In 3ds Max / Corona, `CoronaNormal` expects DirectX (-Y) by default (`flipGreen = false`),
    so OpenGL normal maps (`_nor_gl`, `_opengl`) set `flip_normal_green = True`.
    """
    stem = os.path.splitext(os.path.basename(str(file_path or "")))[0]
    split_camel = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", stem)
    tokens = [t.lower() for t in re.split(r"[^a-zA-Z0-9]+", split_camel) if t]
    if not tokens:
        return ("", {})
    tok_set = set(tokens)
    joined = "_".join(tokens)

    preview_words = {"preview", "thumb", "thumbnail", "sphere", "ball", "shaderball", "render", "contact", "readme"}
    if tok_set & preview_words:
        return ("", {})

    # 1. Normal map (DX priority=2 > generic/GL priority=1; GL needs flipGreen=True for 3ds Max)
    if (tok_set & {"normaldx", "normalgl", "normalmap", "normal", "nrm", "nor", "norm", "nrml", "bumpnormal"}) or (
        "normal" in joined
    ):
        has_gl = (
            ("normalgl" in tok_set)
            or ("opengl" in tok_set)
            or ("gl" in tok_set and "dx" not in tok_set and "directx" not in tok_set)
        )
        has_dx = ("normaldx" in tok_set) or ("directx" in tok_set) or ("dx" in tok_set)
        return ("normal", {"flip_normal_green": bool(has_gl and not has_dx), "priority": 2 if has_dx else 1})

    # 2. Roughness / Glossiness (Roughness priority=2 > Glossiness priority=1)
    if (tok_set & {"roughness", "rough", "rgh", "roughmap"}) or ("rough" in joined):
        return ("roughness", {"is_glossiness": False, "priority": 2})
    if tok_set & {"glossiness", "gloss", "gls", "smoothness", "reflgloss", "rgloss"}:
        return ("roughness", {"is_glossiness": True, "priority": 1})

    # 3. Height / Displacement
    if (tok_set & {"displacement", "disp", "height", "hgt", "heightmap", "bump"}) or (
        tokens[-1] in ("disp", "height")
    ):
        prio = 2 if (tok_set & {"displacement", "disp", "height", "hgt", "heightmap"}) else 1
        return ("height", {"priority": prio})

    # 4. Opacity / Alpha / Cutout Mask
    if (tok_set & {"opacity", "alpha", "cutout", "transparency", "transp", "opac"}) or (
        "mask" in tok_set and not (tok_set & {"ao", "occlusion"})
    ):
        return ("opacity", {"priority": 2 if (tok_set & {"opacity", "alpha", "cutout"}) else 1})

    # 5. Metallic (explicit keywords or trailing 'metal' so 'BrushedMetal_Color' hits albedo)
    if (tok_set & {"metallic", "metalness", "met", "reflmetal"}) or tokens[-1] == "metal":
        return ("metallic", {"priority": 2})

    # 6. Albedo / BaseColor / Diffuse
    has_base_color = any(tokens[i] == "base" and tokens[i + 1] == "color" for i in range(len(tokens) - 1))
    if has_base_color or (tok_set & {"albedo", "basecolor", "diffuse", "diff", "dif", "color", "col", "alb", "bc"}):
        return ("albedo", {"priority": 2})

    return ("", {})


def extract_local_material_stem(slot_paths: Dict[str, str], fallback_dir: str = "") -> str:
    """Extracts a clean identifier stem from downloaded PBR map filenames or parent directory."""
    picked = ""
    for sk, *_rest in LOCAL_PBR_SLOT_SPECS:
        cand = str((slot_paths or {}).get(sk) or "").strip()
        if cand:
            picked = cand
            break
    stem = ""
    if picked:
        stem = os.path.splitext(os.path.basename(picked))[0]
        for _ in range(4):
            nxt = _LOCAL_PBR_SUFFIX_RE.sub("", stem).strip(" _-")
            if nxt == stem or not nxt:
                break
            stem = nxt
        for pfx in ("M_Corona_", "MI_", "T_"):
            if stem.startswith(pfx) and len(stem) > len(pfx):
                stem = stem[len(pfx):]
    if not stem and fallback_dir:
        stem = os.path.basename(os.path.normpath(fallback_dir))
    clean = re.sub(r"[^A-Za-z0-9_]+", "_", stem).strip("_")
    return clean or "LocalPBR"


def scan_pbr_textures_from_paths(
    file_paths: List[str],
    expand_single_siblings: bool = True,
) -> Tuple[Dict[str, str], Dict[str, Any], str]:
    """
    Classifies local texture paths into PBR slots (expanding single-file selection to sibling
    maps in the same directory when they belong to the same material pack).
    Returns `(slot_map, hints_dict, suggested_name)`.
    """
    valid_inputs: List[str] = []
    for p in file_paths or []:
        sp = os.path.normpath(str(p or "").strip())
        if sp and os.path.isfile(sp) and os.path.splitext(sp)[1].lower() in LOCAL_PBR_EXTENSIONS:
            if sp not in valid_inputs:
                valid_inputs.append(sp)

    candidates = list(valid_inputs)
    fallback_dir = os.path.dirname(valid_inputs[0]) if valid_inputs else ""

    if expand_single_siblings and len(valid_inputs) == 1:
        single_path = valid_inputs[0]
        parent_dir = os.path.dirname(single_path)
        ref_stem = extract_local_material_stem({"albedo": single_path}).lower()
        try:
            dir_textures = sorted(
                os.path.join(parent_dir, fn)
                for fn in os.listdir(parent_dir)
                if os.path.splitext(fn)[1].lower() in LOCAL_PBR_EXTENSIONS
                and os.path.isfile(os.path.join(parent_dir, fn))
            )
        except Exception:
            dir_textures = []

        if len(dir_textures) <= 24:
            matched = []
            for fp in dir_textures:
                cand_stem = extract_local_material_stem({"albedo": fp}).lower()
                if not ref_stem or cand_stem == ref_stem or ref_stem in cand_stem or cand_stem in ref_stem:
                    matched.append(fp)
            if len(matched) > 1:
                candidates = matched
            elif len(dir_textures) <= 12:
                candidates = dir_textures

    best_per_slot: Dict[str, Tuple[Tuple[int, int, str], str, Dict[str, Any]]] = {}
    for fp in candidates:
        slot_k, info = classify_pbr_texture_filename(fp)
        if not slot_k:
            continue
        ext_low = os.path.splitext(fp)[1].lower()
        score = (int(info.get("priority", 1)), _LOCAL_PBR_EXT_RANK.get(ext_low, 0), fp.lower())
        prev = best_per_slot.get(slot_k)
        if prev is None or score > prev[0]:
            best_per_slot[slot_k] = (score, fp, info)

    slot_map = {k: v[1] for k, v in best_per_slot.items()}
    hints: Dict[str, Any] = {
        "flip_normal_green": False,
        "is_glossiness": False,
        "detected_category": "auto",
    }
    if "normal" in best_per_slot:
        hints["flip_normal_green"] = bool(best_per_slot["normal"][2].get("flip_normal_green", False))
    if "roughness" in best_per_slot:
        hints["is_glossiness"] = bool(best_per_slot["roughness"][2].get("is_glossiness", False))

    suggested_name = extract_local_material_stem(slot_map, fallback_dir=fallback_dir)
    if suggested_name and suggested_name != "LocalPBR":
        hints["detected_category"] = detect_material_category(suggested_name.replace("_", " "))
    return (slot_map, hints, suggested_name)


def build_corona_physical_mtl_maxscript(
    material_name: str,
    category: str,
    tex_paths: Dict[str, str],
    medit_slot: int = 1,
    apply_to_selection: bool = True,
    uvw_box_mm: float = 1000.0,
    tiling_uv: float = 1.0,
    bump_strength: float = 1.0,
    enable_displacement: bool = False,
    displacement_max_mm: float = 5.0,
    custom_ior: Optional[float] = None,
    custom_clearcoat: Optional[float] = None,
    custom_metalness: Optional[int] = None,
    flip_normal_green: bool = False,
    is_glossiness_map: bool = False,
    force_metalness_map: bool = False,
) -> str:
    """
    Generates MAXScript code that creates a native `CoronaPhysicalMtl` (with fallback to `CoronaLegacyMtl`),
    configures `CoronaBitmap` nodes with physically accurate gamma and OCIO Raw support, wires `CoronaNormal`,
    Roughness/Glossiness, Metallic, Height/Displacement, and Opacity, places into `meditMaterials[medit_slot]`,
    and optionally applies to `selection`.
    """
    mat_name_esc = _mxs_quote_escape(material_name)
    albedo_p = _mxs_quote_escape(tex_paths.get("albedo") or "")
    normal_p = _mxs_quote_escape(tex_paths.get("normal") or "")
    rough_p = _mxs_quote_escape(tex_paths.get("roughness") or "")
    metal_p = _mxs_quote_escape(tex_paths.get("metallic") or "")
    height_p = _mxs_quote_escape(tex_paths.get("height") or "")
    opacity_p = _mxs_quote_escape(tex_paths.get("opacity") or "")

    slot = max(1, min(24, int(medit_slot)))
    cat = (category or "stone").lower()

    # Category-specific physical defaults
    ior = custom_ior if custom_ior is not None else 1.50
    clearcoat = custom_clearcoat if custom_clearcoat is not None else 0.0
    sheen = 0.0
    sheen_rough = 0.5
    metalness_mode = custom_metalness if custom_metalness is not None else 0
    refraction = 0.0
    self_illum = 0.0
    anisotropy = 0.0

    if cat == "wood":
        ior = custom_ior or 1.52
        clearcoat = custom_clearcoat if custom_clearcoat is not None else 0.15
    elif cat in ("stone", "tile"):
        ior = custom_ior or 1.55
        clearcoat = custom_clearcoat if custom_clearcoat is not None else 0.20
    elif cat == "concrete" or cat == "brick":
        ior = custom_ior or 1.50
        clearcoat = 0.0
    elif cat == "fabric":
        ior = custom_ior or 1.35
        sheen = 0.35
        sheen_rough = 0.55
    elif cat == "metal":
        metalness_mode = 1
        anisotropy = 0.25
    elif cat == "mirror":
        metalness_mode = 1
    elif cat == "glass":
        ior = custom_ior or 1.52
        refraction = 1.0
    elif cat == "light":
        self_illum = 5.0

    apply_str = "true" if apply_to_selection else "false"
    disp_str = "true" if enable_displacement else "false"
    flip_nrm_str = "true" if flip_normal_green else "false"
    rough_mode_val = 1 if is_glossiness_map else 0
    force_metal_str = "true" if force_metalness_map else "false"

    ms = f"""(
    try (
        if not (matchPattern (classOf renderers.current as string) pattern:"*Corona*") do (
            renderers.current = Corona()
        )
        if not (matchPattern (classOf renderers.medit as string) pattern:"*Corona*") do (
            renderers.medit_locked = false
            renderers.medit = Corona()
            renderers.medit_locked = true
        )
    ) catch ()
    local matName = "{mat_name_esc}"
    local albedoPath = "{albedo_p}"
    local normalPath = "{normal_p}"
    local roughPath = "{rough_p}"
    local metalPath = "{metal_p}"
    local heightPath = "{height_p}"
    local opacityPath = "{opacity_p}"
    local tileUV = {tiling_uv:.3f}
    local uvwSize = {uvw_box_mm:.1f}
    local bumpMult = {bump_strength:.3f}
    local useDisp = {disp_str}
    local dispMax = {displacement_max_mm:.2f}
    local applyToSel = {apply_str}
    local meditIdx = {slot}
    local flipNormG = {flip_nrm_str}
    local roughModeVal = {rough_mode_val}
    local forceMetalMap = {force_metal_str}

    fn makeCoronaTex pathStr isLinear uvwTile = (
        if pathStr == "" or not (doesFileExist pathStr) do return undefined
        local isOcio = try (ColorPipelineMgr.Mode == #OCIO_Default) catch false
        local bmp = undefined
        try (
            bmp = CoronaBitmap()
            bmp.filename = pathStr
            bmp.realWorldScale = false
            bmp.uvwScale = [uvwTile, uvwTile, 1.0]
            if isLinear then (
                bmp.gamma = 1.0
                if isOcio do try (if isProperty bmp #colorSpace do bmp.colorSpace = "Raw") catch ()
            ) else (
                bmp.gamma = -1.0
            )
        ) catch (
            if isLinear then (
                local bmObj = undefined
                if isOcio then (
                    bmObj = try (openBitMap pathStr colorSpace:"Raw") catch undefined
                ) else (
                    bmObj = try (openBitMap pathStr gamma:1.0) catch undefined
                )
                if bmObj != undefined then (
                    bmp = Bitmaptexture bitmap:bmObj
                ) else (
                    bmp = Bitmaptexture fileName:pathStr
                )
            ) else (
                bmp = Bitmaptexture fileName:pathStr
            )
            bmp.coords.realWorldScale = false
            bmp.coords.U_Tiling = uvwTile
            bmp.coords.V_Tiling = uvwTile
        )
        bmp
    )

    local texAlbedo  = makeCoronaTex albedoPath false tileUV
    local texRough   = makeCoronaTex roughPath true tileUV
    local texNormal  = makeCoronaTex normalPath true tileUV
    local texHeight  = makeCoronaTex heightPath true tileUV
    local texMetal   = makeCoronaTex metalPath true tileUV
    local texOpacity = makeCoronaTex opacityPath true tileUV

    local mtl = undefined
    try (
        mtl = CoronaPhysicalMtl name:matName
        mtl.baseLevel = 1.0
        mtl.baseIor = {ior:.3f}
        mtl.roughnessMode = roughModeVal
        mtl.metalnessMode = {metalness_mode}

        if texAlbedo != undefined do (
            mtl.baseTexmap = texAlbedo
            mtl.baseTexmapOn = true
        )
        if texRough != undefined do (
            mtl.baseRoughnessTexmap = texRough
            mtl.baseRoughnessTexmapOn = true
        )
        if texMetal != undefined and ({metalness_mode} == 0 or forceMetalMap) do (
            if forceMetalMap do try (mtl.metalnessMode = 0) catch ()
            mtl.metalnessTexmap = texMetal
            mtl.metalnessTexmapOn = true
        )
        if texOpacity != undefined do (
            try (
                mtl.opacityTexmap = texOpacity
                mtl.opacityTexmapOn = true
            ) catch ()
        )
        if texNormal != undefined then (
            local cNorm = CoronaNormal()
            cNorm.normalMap = texNormal
            cNorm.addGamma = false
            try (if isProperty cNorm #flipGreen do cNorm.flipGreen = flipNormG) catch ()
            cNorm.multiplier = bumpMult
            if texHeight != undefined do (
                cNorm.additionalBump = texHeight
                cNorm.additionalBumpOn = true
                cNorm.additionalBumpStrength = 0.35
            )
            mtl.baseBumpTexmap = cNorm
            mtl.baseBumpTexmapOn = true
            mtl.baseBumpMapAmount = bumpMult
        ) else if texHeight != undefined do (
            mtl.baseBumpTexmap = texHeight
            mtl.baseBumpTexmapOn = true
            mtl.baseBumpMapAmount = (bumpMult * 0.5)
        )
        if texHeight != undefined do (
            mtl.displacementTexmap = texHeight
            mtl.displacementTexmapOn = useDisp
            mtl.displacementMinimum = 0.0
            mtl.displacementMaximum = dispMax
        )

        if {clearcoat:.3f} > 0.0 do (
            mtl.clearcoatAmount = {clearcoat:.3f}
            mtl.clearcoatRoughness = 0.12
        )
        if {sheen:.3f} > 0.0 do (
            mtl.sheenAmount = {sheen:.3f}
            mtl.sheenRoughness = {sheen_rough:.3f}
        )
        if {anisotropy:.3f} > 0.0 do (
            mtl.baseAnisotropy = {anisotropy:.3f}
        )
        if {refraction:.3f} > 0.0 do (
            mtl.refractionAmount = {refraction:.3f}
        )
        if {self_illum:.3f} > 0.0 do (
            mtl.selfIllumLevel = {self_illum:.3f}
            if texAlbedo != undefined do (
                mtl.selfIllumTexmap = texAlbedo
                mtl.selfIllumTexmapOn = true
            )
        )
    ) catch (
        mtl = CoronaLegacyMtl name:matName
        if texAlbedo != undefined do (
            try (mtl.texmapDiffuse = texAlbedo; mtl.texmapOnDiffuse = true) catch ()
        )
        if texRough != undefined do (
            try (mtl.levelReflect = 1.0; mtl.texmapReflectGlossiness = texRough; mtl.texmapOnReflectGlossiness = true) catch ()
        )
        if texNormal != undefined do (
            try (
                local cNormLeg = CoronaNormal()
                cNormLeg.normalMap = texNormal
                cNormLeg.addGamma = false
                if isProperty cNormLeg #flipGreen do cNormLeg.flipGreen = flipNormG
                cNormLeg.multiplier = bumpMult
                mtl.texmapBump = cNormLeg
                mtl.texmapOnBump = true
            ) catch ()
        )
        if texOpacity != undefined do (
            try (mtl.texmapOpacity = texOpacity; mtl.texmapOnOpacity = true) catch ()
        )
        if texHeight != undefined and useDisp do (
            try (mtl.texmapDisplace = texHeight; mtl.texmapOnDisplace = true; mtl.displacementMaximum = dispMax) catch ()
        )
    )

    if mtl != undefined do (
        try (meditMaterials[meditIdx] = mtl) catch ()
        try (
            local viewIdx = sme.GetViewByName "ComfyUI_PBR"
            if viewIdx == 0 do viewIdx = sme.CreateView "ComfyUI_PBR"
            local v = sme.GetView viewIdx
            v.CreateNode mtl [50, 50]
            v.LayoutAll()
        ) catch ()
        try (
            if ro_CoronaComfyPBRStudio != undefined do (
                ro_CoronaComfyPBRStudio.lbl_status.text = "Done! " + matName + " -> Slot #" + (meditIdx as string) + " & SME [ComfyUI_PBR]"
                ro_CoronaComfyPBRStudio.refreshCreditsUI syncServer:false
            )
        ) catch ()
        try (
            if CoronaToUE5ExporterRollout != undefined and CoronaToUE5ExporterRollout.open do (
                CoronaToUE5ExporterRollout.refreshCreditsUI syncServer:false
            )
        ) catch ()
        try (
            python.Execute "import builtins; w=getattr(builtins, '_CORONA_PBR_STUDIO_QT', None); (w.refresh_credits_ui(False) if w else None)"
        ) catch ()
        if applyToSel and selection.count > 0 do (
            for obj in selection where isValidNode obj and superClassOf obj == GeometryClass do (
                obj.material = mtl
                if uvwSize > 0.0 do (
                    local hasUVW = false
                    for m in obj.modifiers where classOf m == Uvwmap do hasUVW = true
                    if not hasUVW do (
                        try (
                            addModifier obj (Uvwmap maptype:4 length:uvwSize width:uvwSize height:uvwSize)
                        ) catch ()
                    )
                )
            )
        )
        redrawViews()
    )
)
"""
    return ms


def send_maxscript_to_3dsmax(ms_code: str) -> bool:
    """Writes MAXScript code to `bridge_cmd_max.ms` for immediate execution in 3ds Max."""
    try:
        os.makedirs(os.path.dirname(MAX_BRIDGE_CMD_PATH), exist_ok=True)
        with open(MAX_BRIDGE_CMD_PATH, "w", encoding="utf-8") as f:
            f.write(ms_code)
        return True
    except Exception:
        return False


def assemble_corona_material_from_local_textures(
    slot_paths: Dict[str, str],
    material_name: str = "",
    category: str = "auto",
    medit_slot: int = 1,
    apply_to_selection: bool = True,
    uvw_box_mm: float = 1000.0,
    tiling_uv: float = 1.0,
    bump_strength: float = 1.0,
    enable_displacement: bool = False,
    displacement_max_mm: float = 5.0,
    flip_normal_green: bool = False,
    is_glossiness_map: bool = False,
    copy_to_library: bool = False,
    send_to_max: bool = False,
    output_root: str = DEFAULT_OUTPUT_ROOT,
) -> Dict[str, Any]:
    """
    Assembles a physically accurate `CoronaPhysicalMtl` from downloaded PBR texture maps
    on disk (Poly Haven, AmbientCG, Poliigon, Megascans, etc.) without consuming any AI credits.
    """
    valid_paths: Dict[str, str] = {}
    for sk, *_rest in LOCAL_PBR_SLOT_SPECS:
        raw_p = str((slot_paths or {}).get(sk) or "").strip()
        if raw_p and os.path.isfile(raw_p):
            valid_paths[sk] = os.path.normpath(raw_p)

    if not valid_paths:
        raise ValueError("Select at least one valid local PBR texture file.")

    raw_name = str(material_name or "").strip()
    clean_stem = re.sub(r"[^A-Za-z0-9_]+", "_", raw_name).strip("_") if raw_name else extract_local_material_stem(valid_paths)
    clean_stem = clean_stem or "LocalPBR"

    raw_cat = str(category or "auto").strip().lower()
    if not raw_cat or raw_cat == "auto":
        detected_cat = detect_material_category(clean_stem.replace("_", " "))
        cat = detected_cat or "stone"
    else:
        cat = raw_cat

    if raw_name.startswith("M_"):
        mat_name = re.sub(r"[^A-Za-z0-9_]+", "_", raw_name).strip("_")
    else:
        stem_for_mat = clean_stem
        for pfx in (f"M_Corona_{cat.capitalize()}_", "M_Corona_"):
            if stem_for_mat.lower().startswith(pfx.lower()) and len(stem_for_mat) > len(pfx):
                stem_for_mat = stem_for_mat[len(pfx):]
        mat_name = f"M_Corona_{cat.capitalize()}_{stem_for_mat}"

    final_paths = dict(valid_paths)
    dest_folder = os.path.dirname(next(iter(valid_paths.values())))

    if copy_to_library:
        lib_dir = os.path.join(output_root, cat, clean_stem)
        os.makedirs(lib_dir, exist_ok=True)
        copied_paths: Dict[str, str] = {}
        for sk, src_p in valid_paths.items():
            ext = os.path.splitext(src_p)[1].lower() or ".png"
            dst_p = os.path.join(lib_dir, f"{clean_stem}_{sk}{ext}")
            if os.path.abspath(src_p).lower() != os.path.abspath(dst_p).lower():
                shutil.copy2(src_p, dst_p)
            copied_paths[sk] = dst_p
        final_paths = copied_paths
        dest_folder = lib_dir

    ms_code = build_corona_physical_mtl_maxscript(
        material_name=mat_name,
        category=cat,
        tex_paths=final_paths,
        medit_slot=medit_slot,
        apply_to_selection=apply_to_selection,
        uvw_box_mm=uvw_box_mm,
        tiling_uv=tiling_uv,
        bump_strength=bump_strength,
        enable_displacement=enable_displacement,
        displacement_max_mm=displacement_max_mm,
        flip_normal_green=flip_normal_green,
        is_glossiness_map=is_glossiness_map,
        force_metalness_map=bool(final_paths.get("metallic")),
    )

    if send_to_max:
        send_maxscript_to_3dsmax(ms_code)

    return {
        "ok": True,
        "kind": "local_maps",
        "material_name": mat_name,
        "category": cat,
        "textures": final_paths,
        "maps_count": len(final_paths),
        "medit_slot": max(1, min(24, int(medit_slot))),
        "dest_folder": dest_folder,
        "maxscript": ms_code,
    }



_POLISHED_METAL_INCLUDE_CUES = (
    "polished", "mirror", "chrome", "chromium", "полирован", "зеркаль", "глянцев",
)

_POLISHED_METAL_EXCLUDE_CUES = (
    "brushed", "scratch", "scratches", "scratched", "worn", "wear", "aged",
    "rust", "rusted", "oxid", "patina", "corten", "hammer", "dimple",
    "forged", "wrought", "sand-cast", "mill scale", "galvaniz", "spangled",
    "bead", "blasted", "pitted", "engrav", "emboss", "perforat", "mesh",
    "diamond", "flut", "rib", "corrugat", "checkered", "checker", "grid",
    "tile", "tiles", "brick", "panel", "plank", "slat", "foil", "chainmail",
    "oil-rubbed", "tarnish", "verdigris", "dirty", "grunge", "crack", "peel",
    "marble", "stone", "granite", "wood", "glass", "ceramic", "porcelain",
    "terrazzo", "lacquer", "epoxy", "resin", "car paint",
    "браш", "царап", "потерт", "ржав", "окис", "патин", "кован", "чекан",
    "рифлен", "перфор", "сетк", "состарен", "матов",
)


_BRUSHED_METAL_INCLUDE_CUES = (
    "brushed", "браш", "крацован",
)

_BRUSHED_METAL_EXCLUDE_CUES = (
    "scratch", "scratches", "scratched", "worn", "wear", "aged", "hammer", "dimple",
    "forged", "wrought", "sand-cast", "mill scale", "galvaniz", "spangled",
    "bead", "blasted", "pitted", "engrav", "emboss", "perforat", "mesh",
    "diamond", "flut", "rib", "corrugat", "checkered", "checker", "grid",
    "tile", "tiles", "brick", "panel", "plank", "slat", "foil", "chainmail",
    "oil-rubbed", "tarnish", "verdigris", "dirty", "grunge", "crack", "peel",
    "wood", "oak", "ash", "charred", "yakisugi", "marble", "stone", "granite",
    "glass", "ceramic", "porcelain", "terrazzo", "lacquer", "epoxy", "resin",
    "царап", "потерт", "кован", "чекан", "рифлен", "перфор", "сетк", "дерев", "дуб",
)


def is_pure_polished_metal_prompt(raw_prompt: str, prompt_en: str = "") -> bool:
    """
    Returns True when the request is for an unpatterned pure smooth/mirror/polished
    metal surface where diffusion models hallucinate 3D lamps/pipes/backdrops.
    """
    raw_s = str(raw_prompt or "").strip()
    en_s = str(prompt_en or "").strip()
    if not (raw_s or en_s):
        return False
    cat = detect_material_category(raw_s, en_s)
    if cat not in ("metal", "mirror"):
        return False
    combined = f"{raw_s} {en_s}".lower()
    if not any(c in combined for c in _POLISHED_METAL_INCLUDE_CUES):
        return False
    if any(c in combined for c in _POLISHED_METAL_EXCLUDE_CUES):
        return False
    return True


def is_physical_brushed_metal_prompt(raw_prompt: str, prompt_en: str = "") -> bool:
    """
    Returns True for brushed metal requests where anisotropic periodic FFT hairline
    synthesis produces crisp razor-straight hairlines without wavy corduroy SDXL artifacts.
    """
    raw_s = str(raw_prompt or "").strip()
    en_s = str(prompt_en or "").strip()
    if not (raw_s or en_s):
        return False
    cat = detect_material_category(raw_s, en_s)
    if cat not in ("metal", "mirror"):
        return False
    combined = f"{raw_s} {en_s}".lower()
    if not any(c in combined for c in _BRUSHED_METAL_INCLUDE_CUES):
        return False
    if any(c in combined for c in _BRUSHED_METAL_EXCLUDE_CUES):
        return False
    return True


def is_instant_physical_metal_prompt(raw_prompt: str, prompt_en: str = "") -> bool:
    return is_pure_polished_metal_prompt(raw_prompt, prompt_en) or is_physical_brushed_metal_prompt(raw_prompt, prompt_en)


def _write_rgb_png_fast(path: str, rgb_u8: Any) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    h, w, _ = rgb_u8.shape
    try:
        import numpy as _np
        raw = _np.concatenate(
            [_np.zeros((h, 1), dtype=_np.uint8), _np.ascontiguousarray(rgb_u8.reshape(h, w * 3), dtype=_np.uint8)],
            axis=1,
        ).tobytes()
    except Exception:
        raw_rows = [bytearray(rgb_u8[y].tobytes()) for y in range(h)]
        _write_png_rgb_stdlib(path, w, h, raw_rows)
        return

    def _chunk(tag: bytes, payload: bytes) -> bytes:
        return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    idat = zlib.compress(raw, 3)
    tmp_path = path + ".tmp"
    with open(tmp_path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(_chunk(b"IHDR", ihdr))
        f.write(_chunk(b"IDAT", idat))
        f.write(_chunk(b"IEND", b""))
    os.replace(tmp_path, path)


def _select_metal_f0_profile(prompt_low: str, is_brushed: bool = False) -> Tuple[Tuple[int, int, int], float, float, float, bool]:
    # Returns (base_srgb_255, rough_base, rough_amp, normal_amp, flag)
    # flag = is_machined (polished) or is_heavy_or_corten (brushed)
    is_machined = "machined" in prompt_low
    is_heavy = any(k in prompt_low for k in ("heavy", "coarse", "corten", "rust", "груб", "ржав"))
    is_satin = "satin" in prompt_low

    if any(k in prompt_low for k in ("rose gold", "pink gold", "розов")):
        rgb, rb, ra, na = ((236, 178, 156) if is_brushed else (240, 184, 162)), 0.050, 0.025, 0.004
    elif "champagne" in prompt_low:
        rgb, rb, ra, na = ((226, 198, 138) if is_brushed else (234, 206, 152)), 0.070, 0.030, 0.005
    elif any(k in prompt_low for k in ("24k", "yellow gold", "gold", "золот")):
        rgb, rb, ra, na = ((240, 204, 118) if is_brushed else (250, 214, 118)), 0.045, 0.024, 0.004
    elif any(k in prompt_low for k in ("brass", "латун")):
        rgb, rb, ra, na = ((216, 182, 108) if is_brushed else (228, 194, 118)), 0.060, 0.030, 0.005
    elif any(k in prompt_low for k in ("copper", "мед")):
        rgb, rb, ra, na = ((232, 150, 118) if is_brushed else (242, 162, 130)), 0.055, 0.028, 0.005
    elif any(k in prompt_low for k in ("bronze", "бронз")):
        rgb, rb, ra, na = ((172, 134, 92) if is_brushed else (194, 146, 98)), 0.075, 0.032, 0.006
    elif any(k in prompt_low for k in ("corten", "кортен")):
        rgb, rb, ra, na = (194, 116, 66), 0.360, 0.080, 0.040
    elif any(k in prompt_low for k in ("black chrome", "black steel", "gunmetal", "черн", "тёмн", "темн")):
        rgb, rb, ra, na = (78, 82, 88), 0.050, 0.024, 0.004
    elif any(k in prompt_low for k in ("cast iron", "чугун")):
        rgb, rb, ra, na = ((124, 128, 134) if is_brushed else (136, 140, 146)), 0.145, 0.050, 0.012
        is_machined = True
        is_heavy = True
    elif any(k in prompt_low for k in ("chrome", "хром", "mirror", "зеркал")):
        rgb, rb, ra, na = (230, 233, 238), 0.022, 0.014, 0.002
    elif any(k in prompt_low for k in ("silver", "серебр")):
        rgb, rb, ra, na = (238, 238, 234), 0.035, 0.020, 0.003
    elif any(k in prompt_low for k in ("aluminum", "aluminium", "алюмин")):
        rgb, rb, ra, na = ((216, 220, 226) if is_brushed else (222, 226, 232)), 0.070, 0.030, 0.005
    elif any(k in prompt_low for k in ("titanium", "титан")):
        rgb, rb, ra, na = ((182, 178, 170) if is_brushed else (190, 186, 178)), 0.080, 0.032, 0.005
    elif any(k in prompt_low for k in ("iron", "желез")):
        rgb, rb, ra, na = ((176, 180, 186) if is_brushed else (182, 186, 192)), 0.085, 0.035, 0.006
    else:
        rgb, rb, ra, na = ((206, 210, 215) if is_brushed else (212, 216, 221)), 0.060, 0.030, 0.005

    if is_brushed:
        rb = max(0.28 if is_heavy else (0.17 if is_satin else 0.21), rb)
        ra = 0.075 if is_heavy else 0.055
        na = 0.045 if is_heavy else 0.026
        return (rgb, rb, ra, na, is_heavy)
    if is_satin and "mirror" not in prompt_low and "chrome" not in prompt_low:
        rb = max(rb, 0.12)
    return (rgb, rb, ra, na, is_machined)


def _synthesize_brushed_metal_pbr_maps(
    prompt_en: str,
    res_px: int,
    used_seed: int,
    dest_folder: str,
    asset_base_name: str,
    category: str,
    material_name: str,
    progress_cb: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    """
    Synthesizes 100% seamless, razor-straight anisotropic brushed metal 5-map PBR packs
    matching real studio brushed metal swatches without wavy corduroy SDXL artifacts or dipoles.
    """
    n = max(64, int(res_px or 1024))
    p_low = str(prompt_en or "").lower()
    rgb, rough_base, rough_amp, normal_amp, is_heavy = _select_metal_f0_profile(p_low, is_brushed=True)
    is_corten = any(k in p_low for k in ("corten", "rust", "кортен", "ржав"))
    is_horizontal = any(k in p_low for k in ("horizontal", "горизонтал")) and not any(
        k in p_low for k in ("vertical", "вертикал")
    )
    if progress_cb:
        progress_cb(f"Synthesizing razor-straight Brushed Metal ({n}x{n}, 0 Gens)...")

    os.makedirs(dest_folder, exist_ok=True)
    paths = {
        "albedo": os.path.join(dest_folder, f"T_{asset_base_name}_Albedo.png"),
        "roughness": os.path.join(dest_folder, f"T_{asset_base_name}_Roughness.png"),
        "normal": os.path.join(dest_folder, f"T_{asset_base_name}_Normal.png"),
        "height": os.path.join(dest_folder, f"T_{asset_base_name}_Height.png"),
        "metallic": os.path.join(dest_folder, f"T_{asset_base_name}_Metallic.png"),
    }

    try:
        import numpy as _np
        rng = _np.random.default_rng(int(used_seed) & 0xFFFFFFFF)
        ky = (2.0 * _np.pi * _np.fft.fftfreq(n)[:, None]).astype(_np.float32)
        kx = (2.0 * _np.pi * _np.fft.rfftfreq(n)[None, :]).astype(_np.float32)

        res_sc = max(0.5, float(n) / 1024.0)
        sc_w = (2.0 if is_heavy else 1.0) * (res_sc ** 0.35)
        sc_l = res_sc

        def _hairline_band(lx_px: float, ly_px: float, kx_min_px: float):
            w = rng.standard_normal((n, n), dtype=_np.float32)
            spec = (
                _np.fft.rfft2(w)
                * (1.0 - _np.exp(-0.5 * (kx * kx_min_px) ** 2))
                * _np.exp(-0.5 * (kx * lx_px) ** 2)
                * _np.exp(-0.5 * (ky * ly_px) ** 2)
            )
            spec[0, 0] = 0.0
            arr = _np.fft.irfft2(spec, s=(n, n)).astype(_np.float32)
            return arr / max(float(_np.std(arr)), 1e-6), spec

        b1, _s1 = _hairline_band(0.95 * sc_w, 260.0 * sc_l, 9.0 * sc_w)
        b2, s2 = _hairline_band(0.45 * sc_w, 130.0 * sc_l, 3.6 * sc_w)
        b3, s3 = _hairline_band(0.18 * sc_w, 62.0 * sc_l, 1.6 * sc_w)

        streaks = _np.tanh(0.80 * (0.22 * b1 + 0.43 * b2 + 0.35 * b3)).astype(_np.float32)

        fc = _np.sqrt((kx * 0.8) ** 2 + (ky * 0.18) ** 2 + 0.004).astype(_np.float32)
        wc = _np.fft.rfft2(rng.standard_normal((n, n), dtype=_np.float32)) / (fc ** 1.8)
        wc[0, 0] = 0.0
        cloud = _np.fft.irfft2(wc, s=(n, n)).astype(_np.float32)
        cloud /= max(float(_np.std(cloud)), 1e-6)

        gx = _np.fft.irfft2(1j * kx * (0.30 * s2 + 0.70 * s3), s=(n, n)).astype(_np.float32)
        gy = _np.fft.irfft2(1j * ky * (0.30 * s2 + 0.70 * s3), s=(n, n)).astype(_np.float32)
        h_raw = _np.fft.irfft2(0.30 * s2 + 0.70 * s3, s=(n, n)).astype(_np.float32)
        h_raw /= max(float(_np.std(h_raw)), 1e-6)

        if is_horizontal:
            streaks = _np.ascontiguousarray(streaks.T)
            cloud = _np.ascontiguousarray(cloud.T)
            h_raw = _np.ascontiguousarray(h_raw.T)
            gx, gy = _np.ascontiguousarray(gy.T), _np.ascontiguousarray(gx.T)

        base = _np.array(rgb, dtype=_np.float32)
        tone = _np.clip(1.0 + 0.090 * streaks + 0.015 * cloud, 0.72, 1.25).astype(_np.float32)
        albedo_f = base[None, None, :] * tone[:, :, None]

        metal_u8 = _np.full((n, n), 255, dtype=_np.uint8)
        rust_boost = 0.0
        if is_corten:
            fr = _np.sqrt(kx * kx + ky * ky + 0.008).astype(_np.float32)
            wr = _np.fft.rfft2(rng.standard_normal((n, n), dtype=_np.float32)) / (fr ** 1.85)
            wr[0, 0] = 0.0
            rmask = _np.fft.irfft2(wr, s=(n, n)).astype(_np.float32)
            rmask = _np.clip(0.5 + 0.25 * (rmask / max(float(_np.std(rmask)), 1e-6) + 0.35 * streaks), 0.12, 0.95)
            if is_horizontal:
                rmask = _np.ascontiguousarray(rmask.T)
            rust_col = _np.array([146.0, 72.0, 36.0], dtype=_np.float32)
            mix_r = 0.58 * rmask[:, :, None]
            albedo_f = albedo_f * (1.0 - mix_r) + (rust_col[None, None, :] * (1.0 + 0.12 * streaks[:, :, None])) * mix_r
            metal_u8 = _np.clip(255.0 - 90.0 * rmask, 145.0, 255.0).astype(_np.uint8)
            rust_boost = 0.14 * rmask

        albedo_u8 = _np.clip(albedo_f, 0.0, 255.0).astype(_np.uint8)
        _write_rgb_png_fast(paths["albedo"], albedo_u8)

        rough_val = _np.clip(rough_base - rough_amp * streaks + 0.025 * cloud + rust_boost, 0.08, 0.72)
        rough_u8 = _np.clip(rough_val * 255.0, 12.0, 220.0).astype(_np.uint8)
        _write_rgb_png_fast(paths["roughness"], _np.repeat(rough_u8[:, :, None], 3, axis=2))

        gs = max(float(_np.std(gx)), float(_np.std(gy)), 1e-6)
        nx = _np.clip(-(gx / gs) * normal_amp, -0.25, 0.25)
        ny = _np.clip(-(gy / gs) * normal_amp, -0.25, 0.25)
        nz = _np.sqrt(_np.clip(1.0 - nx * nx - ny * ny, 0.25, 1.0))
        norm_u8 = _np.empty((n, n, 3), dtype=_np.uint8)
        norm_u8[:, :, 0] = _np.clip((nx * 0.5 + 0.5) * 255.0, 0.0, 255.0).astype(_np.uint8)
        norm_u8[:, :, 1] = _np.clip((ny * 0.5 + 0.5) * 255.0, 0.0, 255.0).astype(_np.uint8)
        norm_u8[:, :, 2] = _np.clip((nz * 0.5 + 0.5) * 255.0, 0.0, 255.0).astype(_np.uint8)
        _write_rgb_png_fast(paths["normal"], norm_u8)

        h_u8 = _np.clip((0.5 + 0.08 * _np.clip(h_raw, -2.5, 2.5)) * 255.0, 0.0, 255.0).astype(_np.uint8)
        _write_rgb_png_fast(paths["height"], _np.repeat(h_u8[:, :, None], 3, axis=2))
        _write_rgb_png_fast(paths["metallic"], _np.repeat(metal_u8[:, :, None], 3, axis=2))
    except ImportError:
        r_b = int(max(12, min(200, round(rough_base * 255))))
        _write_png_rgb_stdlib(paths["albedo"], n, n, [bytearray(rgb) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["roughness"], n, n, [bytearray((r_b, r_b, r_b)) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["normal"], n, n, [bytearray((128, 128, 255)) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["height"], n, n, [bytearray((128, 128, 128)) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["metallic"], n, n, [bytearray((255, 255, 255)) * n for _ in range(n)])

    return {
        "status": "ok",
        "material_name": material_name,
        "category": category,
        "prompt_en": prompt_en,
        "dest_folder": dest_folder,
        "textures": paths,
        "maxscript": "",
        "sent_to_max": False,
        "seed": used_seed,
        "credits_cost": 0.0,
        "credits_remaining": pbr_credits_ledger.get_remaining_generations(False),
    }


def _synthesize_polished_metal_pbr_maps(
    prompt_en: str,
    res_px: int,
    used_seed: int,
    dest_folder: str,
    asset_base_name: str,
    category: str,
    material_name: str,
    progress_cb: Optional[Callable[[str], None]] = None,
) -> Dict[str, Any]:
    """
    Synthesizes 100% seamless, artifact-free 5-map PBR textures for pure smooth/mirror/polished metals.
    Avoids diffusion 3D object hallucinations (lamps/pipes/backdrops) and CHORD roughness/metalness drop-outs.
    """
    n = max(64, int(res_px or 1024))
    rgb, rough_base, rough_amp, normal_amp, is_machined = _select_metal_f0_profile(str(prompt_en or "").lower(), is_brushed=False)
    if progress_cb:
        progress_cb(f"Synthesizing calibrated seamless Polished Metal ({n}x{n}, 0 Gens)...")

    os.makedirs(dest_folder, exist_ok=True)
    paths = {
        "albedo": os.path.join(dest_folder, f"T_{asset_base_name}_Albedo.png"),
        "roughness": os.path.join(dest_folder, f"T_{asset_base_name}_Roughness.png"),
        "normal": os.path.join(dest_folder, f"T_{asset_base_name}_Normal.png"),
        "height": os.path.join(dest_folder, f"T_{asset_base_name}_Height.png"),
        "metallic": os.path.join(dest_folder, f"T_{asset_base_name}_Metallic.png"),
    }

    try:
        import numpy as _np
        rng = _np.random.default_rng(int(used_seed) & 0xFFFFFFFF)
        ky = (2.0 * _np.pi * _np.fft.fftfreq(n)[:, None]).astype(_np.float32)
        kx = (2.0 * _np.pi * _np.fft.rfftfreq(n)[None, :]).astype(_np.float32)

        # Band 1: Broad organic buffing cloud (for natural specular break-up)
        f_cloud = _np.sqrt(kx * kx + ky * ky + 0.004).astype(_np.float32)
        w1 = rng.standard_normal((n, n), dtype=_np.float32)
        spec_cloud = _np.fft.rfft2(w1) * (1.0 / (f_cloud ** 1.85))
        spec_cloud[0, 0] = 0.0
        cloud = _np.fft.irfft2(spec_cloud, s=(n, n)).astype(_np.float32)
        cloud /= max(float(_np.std(cloud)), 1e-6)

        # Band 2: Micro-polish hairline streaks (gentle horizontal anisotropy + fine micro-variation)
        ky_streak = ky * (0.28 if is_machined else 0.45)
        kx_streak = kx * (2.6 if is_machined else 1.8)
        f_micro = _np.sqrt(kx_streak * kx_streak + ky_streak * ky_streak + 0.015).astype(_np.float32)
        w2 = rng.standard_normal((n, n), dtype=_np.float32)
        spec_micro = _np.fft.rfft2(w2) * (1.0 / (f_micro ** 1.45))
        spec_micro[0, 0] = 0.0
        micro = _np.fft.irfft2(spec_micro, s=(n, n)).astype(_np.float32)
        micro /= max(float(_np.std(micro)), 1e-6)

        # Blend height field and derive exact periodic DirectX (-Y) normal
        h_field = (0.55 * cloud + 0.45 * micro).astype(_np.float32)
        h_spec = _np.fft.rfft2(h_field)
        dh_dx = _np.fft.irfft2(1j * kx * h_spec, s=(n, n)).astype(_np.float32)
        dh_dy = _np.fft.irfft2(1j * ky * h_spec, s=(n, n)).astype(_np.float32)
        grad_scale = max(float(_np.std(dh_dx)), float(_np.std(dh_dy)), 1e-6)
        nx = _np.clip(-(dh_dx / grad_scale) * normal_amp, -0.35, 0.35)
        ny = _np.clip(-(dh_dy / grad_scale) * normal_amp, -0.35, 0.35)
        nz = _np.sqrt(_np.clip(1.0 - nx * nx - ny * ny, 0.25, 1.0))

        # Subtle micro-tonal variation in Albedo (+/- ~1.5%, completely uniform metallic F0)
        tone = _np.clip(1.0 + 0.014 * (0.65 * cloud + 0.35 * micro), 0.94, 1.06).astype(_np.float32)
        albedo_f = _np.empty((n, n, 3), dtype=_np.uint8)
        for ci in range(3):
            albedo_f[:, :, ci] = _np.clip(float(rgb[ci]) * tone, 0.0, 255.0).astype(_np.uint8)
        _write_rgb_png_fast(paths["albedo"], albedo_f)

        # Roughness: calibrated mirror/polished value + organic buffing breakup
        rough_val = _np.clip(rough_base + rough_amp * (0.60 * cloud + 0.40 * micro), 0.01, 0.45)
        rough_u8 = _np.clip(rough_val * 255.0, 2.0, 140.0).astype(_np.uint8)
        rough_rgb = _np.repeat(rough_u8[:, :, None], 3, axis=2)
        _write_rgb_png_fast(paths["roughness"], rough_rgb)

        # Normal (DirectX -Y matching studio CHORD convention)
        norm_rgb = _np.empty((n, n, 3), dtype=_np.uint8)
        norm_rgb[:, :, 0] = _np.clip((nx * 0.5 + 0.5) * 255.0, 0.0, 255.0).astype(_np.uint8)
        norm_rgb[:, :, 1] = _np.clip((ny * 0.5 + 0.5) * 255.0, 0.0, 255.0).astype(_np.uint8)
        norm_rgb[:, :, 2] = _np.clip((nz * 0.5 + 0.5) * 255.0, 0.0, 255.0).astype(_np.uint8)
        _write_rgb_png_fast(paths["normal"], norm_rgb)

        # Height (gentle mid-grey micro-polish height)
        h_u8 = _np.clip((0.5 + 0.04 * _np.clip(h_field, -2.5, 2.5)) * 255.0, 0.0, 255.0).astype(_np.uint8)
        _write_rgb_png_fast(paths["height"], _np.repeat(h_u8[:, :, None], 3, axis=2))

        # Metallic (pure solid conductor = 255)
        metal_rgb = _np.full((n, n, 3), 255, dtype=_np.uint8)
        _write_rgb_png_fast(paths["metallic"], metal_rgb)
    except ImportError:
        # Stdlib fallback without numpy
        r_b = int(max(4, min(120, round(rough_base * 255))))
        _write_png_rgb_stdlib(paths["albedo"], n, n, [bytearray(rgb) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["roughness"], n, n, [bytearray((r_b, r_b, r_b)) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["normal"], n, n, [bytearray((128, 128, 255)) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["height"], n, n, [bytearray((128, 128, 128)) * n for _ in range(n)])
        _write_png_rgb_stdlib(paths["metallic"], n, n, [bytearray((255, 255, 255)) * n for _ in range(n)])

    return {
        "status": "ok",
        "material_name": material_name,
        "category": category,
        "prompt_en": prompt_en,
        "dest_folder": dest_folder,
        "textures": paths,
        "maxscript": "",
        "sent_to_max": False,
        "seed": used_seed,
        "credits_cost": 0.0,
        "credits_remaining": pbr_credits_ledger.get_remaining_generations(False),
    }


def generate_corona_pbr_from_prompt(
    prompt_text: str,
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    ckpt_name: str = "SDXL\\realvisxlV50_v50Bakedvae.safetensors",
    medit_slot: int = 1,
    apply_to_selection: bool = True,
    uvw_box_mm: float = 1000.0,
    tiling_uv: float = 1.0,
    bump_strength: float = 1.0,
    enable_displacement: bool = False,
    custom_ior: Optional[float] = None,
    custom_clearcoat: Optional[float] = None,
    custom_metalness: Optional[int] = None,
    output_root: str = DEFAULT_OUTPUT_ROOT,
    progress_cb: Optional[Callable[[str], None]] = None,
    charge_credits: bool = True,
    seed: Optional[int] = None,
    send_to_max: bool = True,
    pattern_scale: float = 2.0,
) -> Dict[str, Any]:
    """
    End-to-end pipeline:
      1. Translates/cleans `prompt_text` and detects category.
      2. Verifies & deducts generation credits (with auto-refund on failure).
      3. Runs SDXL + SeamlessTile + AI 5-Map PBR Engine (or DepthAnything V2) in ComfyUI.
      4. Saves the 5 PBR maps into `<output_root>/<category>/<material_name>/`.
      5. Builds `CoronaPhysicalMtl` in 3ds Max, puts it in `meditMaterials[medit_slot]`, and applies to `selection`.
    """
    prompt_en = translate_or_clean_prompt(prompt_text)
    category = detect_material_category(prompt_text, prompt_en)
    slug = make_slug(prompt_en)
    res_tag = {512: "512", 1024: "1K", 2048: "2K", 4096: "4K"}.get(res_px, f"{res_px}")
    used_seed = int(seed) if seed is not None and int(seed) > 0 else random.randint(1, 2**31 - 1)
    stamp = used_seed % 1000
    asset_base_name = f"{slug}_{res_tag}_{stamp}"
    material_name = f"M_Corona_{category.capitalize()}_{asset_base_name}"
    dest_folder = os.path.join(output_root, category, asset_base_name)

    if is_pure_polished_metal_prompt(prompt_text, prompt_en):
        return _synthesize_polished_metal_pbr_maps(
            prompt_en=prompt_en,
            res_px=int(res_px or 1024),
            used_seed=used_seed,
            dest_folder=dest_folder,
            asset_base_name=asset_base_name,
            category=category,
            material_name=material_name,
            progress_cb=progress_cb,
        )
    if is_physical_brushed_metal_prompt(prompt_text, prompt_en):
        return _synthesize_brushed_metal_pbr_maps(
            prompt_en=prompt_en,
            res_px=int(res_px or 1024),
            used_seed=used_seed,
            dest_folder=dest_folder,
            asset_base_name=asset_base_name,
            category=category,
            material_name=material_name,
            progress_cb=progress_cb,
        )

    cost = pbr_credits_ledger.get_pbr_generation_cost(res_px)
    if charge_credits:
        ok_c, _new_bal, msg_c = pbr_credits_ledger.consume_credits(
            cost,
            event_type="credit_consumed",
            extra={"source": "blender_pbr_studio", "res_px": res_px, "pipeline": pipeline_mode},
        )
        if not ok_c:
            raise RuntimeError(msg_c)

    if progress_cb:
        model_disp = {
            "chord": "SDXL+",
            "da2": "SDXL",
            "flux_chord": "FLUX",
            "wan_chord": "WAN",
        }.get(str(pipeline_mode or "").lower(), "AI PBR")
        progress_cb(f"Подготовка воркфлоу [{model_disp} {res_tag} | Seed {used_seed} | {cost} Gen]: '{prompt_en}'...")

    workflow = _build_txt2pbr_workflow(
        prompt_en=prompt_en,
        res_px=res_px,
        pipeline_mode=pipeline_mode,
        ckpt_name=ckpt_name,
        seed=used_seed,
        pattern_scale=float(pattern_scale or 2.0),
    )
    try:
        downloaded = execute_comfy_workflow_and_download(
            workflow=workflow,
            dest_folder=dest_folder,
            asset_base_name=asset_base_name,
            progress_cb=progress_cb,
        )
    except Exception:
        if charge_credits:
            pbr_credits_ledger.refund_credits(cost, reason="generation_error")
        raise

    try:
        heal_chord_normal_and_height_dipoles_disk(
            downloaded.get("normal", ""),
            downloaded.get("height", ""),
        )
    except Exception:
        pass

    if progress_cb:
        progress_cb(f"Создание CoronaPhysicalMtl ({material_name}) в 3ds Max...")

    ms_code = build_corona_physical_mtl_maxscript(
        material_name=material_name,
        category=category,
        tex_paths=downloaded,
        medit_slot=medit_slot,
        apply_to_selection=apply_to_selection,
        uvw_box_mm=uvw_box_mm,
        tiling_uv=tiling_uv,
        bump_strength=bump_strength,
        enable_displacement=enable_displacement,
        custom_ior=custom_ior,
        custom_clearcoat=custom_clearcoat,
        custom_metalness=custom_metalness,
    )
    sent = send_maxscript_to_3dsmax(ms_code) if send_to_max else False

    return {
        "status": "ok",
        "material_name": material_name,
        "category": category,
        "prompt_en": prompt_en,
        "dest_folder": dest_folder,
        "textures": downloaded,
        "maxscript": ms_code,
        "sent_to_max": sent,
        "seed": used_seed,
        "credits_cost": cost,
        "credits_remaining": pbr_credits_ledger.get_remaining_generations(False),
    }


def generate_corona_bw_mask_from_prompt(
    prompt_text: str,
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    ckpt_name: str = "SDXL\\realvisxlV50_v50Bakedvae.safetensors",
    output_root: str = DEFAULT_OUTPUT_ROOT,
    progress_cb: Optional[Callable[[str], None]] = None,
    charge_credits: bool = True,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Generates a seamless monochrome B&W blend mask PNG via ComfyUI for CoronaLayeredMtl mixing."""
    prompt_en = translate_or_clean_prompt(prompt_text)
    slug = make_slug(prompt_en)
    res_tag = {512: "512", 1024: "1K", 2048: "2K", 4096: "4K"}.get(res_px, f"{res_px}")
    used_seed = int(seed) if seed is not None and int(seed) > 0 else random.randint(1, 2**31 - 1)
    mask_name = f"T_Mask_{slug}_{res_tag}_S{used_seed % 100000}"
    dest_folder = os.path.join(output_root, "bw_mask")

    cost = pbr_credits_ledger.get_pbr_generation_cost(res_px)
    if charge_credits:
        ok_c, _new_bal, msg_c = pbr_credits_ledger.consume_credits(
            cost,
            event_type="credit_consumed",
            extra={"source": "blender_pbr_studio_mask", "res_px": res_px, "pipeline": pipeline_mode},
        )
        if not ok_c:
            raise RuntimeError(msg_c)

    if progress_cb:
        progress_cb(f"Генерация B&W маски [{res_tag} | Seed {used_seed} | {cost} Gen]: '{prompt_en}'...")

    workflow, used_seed = _build_bw_mask_workflow(
        prompt_en=prompt_en,
        res_px=res_px,
        pipeline_mode=pipeline_mode,
        ckpt_name=ckpt_name,
        seed=used_seed,
    )
    try:
        downloaded = execute_comfy_workflow_and_download(
            workflow=workflow,
            dest_folder=dest_folder,
            asset_base_name=mask_name,
            progress_cb=progress_cb,
            is_bw_mask=True,
        )
    except Exception:
        if charge_credits:
            pbr_credits_ledger.refund_credits(cost, reason="generation_error")
        raise

    mask_path = downloaded.get("mask") or next(iter(downloaded.values()), "")
    return {
        "status": "ok",
        "kind": "bw_mask",
        "mask_name": mask_name,
        "mask_path": mask_path,
        "prompt_en": prompt_en,
        "dest_folder": dest_folder,
        "seed": used_seed,
        "credits_cost": cost,
        "credits_remaining": pbr_credits_ledger.get_remaining_generations(False),
    }


def generate_corona_pbr_from_reference(
    reference_image_path: str,
    ref_mode: str = "img2img_seamless",
    prompt_hint: str = "",
    denoise: float = 0.55,
    res_px: int = 1024,
    pipeline_mode: str = "chord",
    ckpt_name: str = "SDXL\\realvisxlV50_v50Bakedvae.safetensors",
    medit_slot: int = 1,
    apply_to_selection: bool = True,
    uvw_box_mm: float = 1000.0,
    tiling_uv: float = 1.0,
    bump_strength: float = 1.0,
    enable_displacement: bool = False,
    output_root: str = DEFAULT_OUTPUT_ROOT,
    progress_cb: Optional[Callable[[str], None]] = None,
    charge_credits: bool = True,
    seed: Optional[int] = None,
    send_to_max: bool = True,
    pattern_scale: float = 2.0,
) -> Dict[str, Any]:
    """
    Generates a Corona PBR material from a Reference Image (`reference_image_path`) in one of 3 modes:
      - `chord_direct`: Direct photo-to-PBR decomposition via AI 5-Map PBR Engine (`ChordMaterialEstimation`).
      - `img2img_seamless`: Uploads reference photo to ComfyUI, runs SeamlessTile SDXL Img2Img (`denoise`),
        then decomposes into 5 PBR maps via AI 5-Map PBR Engine.
      - `ai_vision_pbr`: Uses Gemini Vision to extract the exact material prompt & physical parameters from
        the reference image, then generates seamless 5-map PBR textures in ComfyUI.
    """
    if not os.path.exists(reference_image_path):
        raise FileNotFoundError(f"Файл референса не найден: {reference_image_path}")

    custom_ior = None
    custom_clearcoat = None
    custom_metalness = None

    if ref_mode == "ai_vision_pbr":
        if progress_cb:
            progress_cb("AI Vision анализирует референс-изображение...")
        extracted = extract_materials_from_reference_image(reference_image_path, target_hint=prompt_hint)
        if extracted:
            top = extracted[0]
            prompt_en = top.get("prompt_en") or translate_or_clean_prompt(prompt_hint or "natural stone texture")
            custom_ior = float(top.get("ior", 1.5))
            custom_clearcoat = float(top.get("clearcoat", 0.0))
            custom_metalness = int(top.get("metalness", 0))
        else:
            prompt_en = translate_or_clean_prompt(prompt_hint or "natural architectural surface texture")
        return generate_corona_pbr_from_prompt(
            prompt_text=prompt_en,
            res_px=res_px,
            pipeline_mode=pipeline_mode,
            ckpt_name=ckpt_name,
            medit_slot=medit_slot,
            apply_to_selection=apply_to_selection,
            uvw_box_mm=uvw_box_mm,
            tiling_uv=tiling_uv,
            bump_strength=bump_strength,
            enable_displacement=enable_displacement,
            custom_ior=custom_ior,
            custom_clearcoat=custom_clearcoat,
            custom_metalness=custom_metalness,
            output_root=output_root,
            progress_cb=progress_cb,
            charge_credits=charge_credits,
            seed=seed,
            send_to_max=send_to_max,
            pattern_scale=float(pattern_scale or 2.0),
        )

    # Pre-process reference image (2x2 expansion canvas for outpaint_4x, raw aspect-preserved input for chord_direct, or de-light + seamless tile)
    is_precomposed_4x = False
    target_w_ref: Optional[int] = None
    target_h_ref: Optional[int] = None
    if ref_mode == "outpaint_4x":
        if progress_cb:
            progress_cb("Подготовка 2x2 холста 4x-расширения и загрузка в ComfyUI...")
        prepped_ref_path, is_precomposed_4x = prepare_4x_expansion_canvas(reference_image_path)
    elif ref_mode == "chord_direct":
        target_w_ref, target_h_ref = compute_aspect_preserving_dims(reference_image_path, max_side=res_px)
        if progress_cb:
            progress_cb(f"Прямое извлечение PBR ({target_w_ref}x{target_h_ref}, без обрезки и перерисовки)...")
        prepped_ref_path = reference_image_path
    else:
        if progress_cb:
            progress_cb("Де-лайтинг и бесшовная подготовка референса + загрузка в ComfyUI...")
        prepped_ref_path = preprocess_reference_for_seamless(reference_image_path, target_size=max(1024, res_px))
    uploaded_name = upload_image_to_comfy(prepped_ref_path)

    prompt_en = translate_or_clean_prompt(prompt_hint) if prompt_hint.strip() else ""
    category = detect_material_category(prompt_hint, prompt_en) if prompt_hint.strip() else "concrete"
    if not prompt_en:
        prompt_en = "homogeneous architectural plaster stone surface texture, uniform flat studio illumination, natural micro-relief"
    slug = make_slug(prompt_en if prompt_hint.strip() else os.path.splitext(os.path.basename(reference_image_path))[0])
    res_tag = {512: "512", 1024: "1K", 2048: "2K", 4096: "4K"}.get(res_px, f"{res_px}")
    used_seed = int(seed) if seed is not None and int(seed) > 0 else random.randint(1, 2**31 - 1)
    stamp = used_seed % 1000
    asset_prefix = "Expand4x" if ref_mode == "outpaint_4x" else "Ref"
    asset_base_name = f"{asset_prefix}_{slug}_{res_tag}_{stamp}"
    material_name = f"M_Corona_{category.capitalize()}_{asset_base_name}"
    dest_folder = os.path.join(output_root, category, asset_base_name)

    # Save a copy of the reference image inside the material folder for traceability
    os.makedirs(dest_folder, exist_ok=True)
    try:
        shutil.copy2(reference_image_path, os.path.join(dest_folder, "reference_source" + os.path.splitext(reference_image_path)[1]))
    except Exception:
        pass

    cost = pbr_credits_ledger.get_pbr_generation_cost(res_px, ref_mode=ref_mode)
    if charge_credits:
        ok_c, _new_bal, msg_c = pbr_credits_ledger.consume_credits(
            cost,
            event_type="credit_consumed",
            extra={"source": "blender_pbr_studio_ref", "res_px": res_px, "pipeline": pipeline_mode, "ref_mode": ref_mode},
        )
        if not ok_c:
            raise RuntimeError(msg_c)

    if ref_mode == "outpaint_4x":
        workflow = _build_outpaint_4x_pbr_workflow(
            uploaded_comfy_filename=uploaded_name,
            prompt_en=prompt_en,
            res_px=res_px,
            pipeline_mode=pipeline_mode,
            ckpt_name=ckpt_name,
            denoise=float(denoise) if 0.45 <= float(denoise) <= 0.80 else 0.68,
            seed=used_seed,
            precomposed_2x2=is_precomposed_4x,
        )
    else:
        workflow = _build_reference_pbr_workflow(
            uploaded_comfy_filename=uploaded_name,
            ref_mode=ref_mode,
            prompt_en=prompt_en,
            denoise=denoise,
            res_px=res_px,
            pipeline_mode=pipeline_mode,
            ckpt_name=ckpt_name,
            seed=used_seed,
            pattern_scale=float(pattern_scale or 2.0),
            target_w=target_w_ref,
            target_h=target_h_ref,
        )
    try:
        downloaded = execute_comfy_workflow_and_download(
            workflow=workflow,
            dest_folder=dest_folder,
            asset_base_name=asset_base_name,
            progress_cb=progress_cb,
            enforce_seamless=(ref_mode != "chord_direct"),
        )
    except Exception:
        if charge_credits:
            pbr_credits_ledger.refund_credits(cost, reason="generation_error")
        raise

    try:
        heal_chord_normal_and_height_dipoles_disk(
            downloaded.get("normal", ""),
            downloaded.get("height", ""),
        )
    except Exception:
        pass

    if progress_cb:
        progress_cb(f"Создание CoronaPhysicalMtl ({material_name}) в 3ds Max...")

    ms_code = build_corona_physical_mtl_maxscript(
        material_name=material_name,
        category=category,
        tex_paths=downloaded,
        medit_slot=medit_slot,
        apply_to_selection=apply_to_selection,
        uvw_box_mm=uvw_box_mm,
        tiling_uv=tiling_uv,
        bump_strength=bump_strength,
        enable_displacement=enable_displacement,
    )
    sent = send_maxscript_to_3dsmax(ms_code) if send_to_max else False

    return {
        "status": "ok",
        "material_name": material_name,
        "category": category,
        "ref_mode": ref_mode,
        "prompt_en": prompt_en,
        "dest_folder": dest_folder,
        "textures": downloaded,
        "maxscript": ms_code,
        "sent_to_max": sent,
        "seed": used_seed,
        "credits_cost": cost,
        "credits_remaining": pbr_credits_ledger.get_remaining_generations(False),
    }


def run_cli_job(job_json_path: str) -> int:
    """Executes a Qt-dispatched generation job and streams @@PROGRESS@@ / @@RESULT_JSON@@ lines."""
    try:
        with open(job_json_path, "r", encoding="utf-8-sig") as f:
            job = json.load(f)
    except Exception as exc:
        print(f"@@ERROR@@Cannot read job JSON: {exc}", flush=True)
        return 2

    def _emit_prog(msg: str) -> None:
        print(f"@@PROGRESS@@{msg}", flush=True)

    j_type = str(job.get("type") or "prompt")
    try:
        if j_type == "bw_mask":
            res = generate_corona_bw_mask_from_prompt(
                prompt_text=str(job.get("prompt") or ""),
                res_px=int(job.get("res_px") or 1024),
                pipeline_mode=str(job.get("pipeline_mode") or "chord"),
                ckpt_name=str(job.get("ckpt_name") or "SDXL\\realvisxlV50_v50Bakedvae.safetensors"),
                progress_cb=_emit_prog,
                charge_credits=bool(job.get("charge_credits", True)),
                seed=job.get("seed"),
            )
        elif j_type == "reference":
            res = generate_corona_pbr_from_reference(
                reference_image_path=str(job.get("ref_path") or ""),
                ref_mode=str(job.get("ref_mode") or "img2img_seamless"),
                prompt_hint=str(job.get("prompt_hint") or ""),
                denoise=float(job.get("denoise") or 0.52),
                res_px=int(job.get("res_px") or 1024),
                pipeline_mode=str(job.get("pipeline_mode") or "chord"),
                ckpt_name=str(job.get("ckpt_name") or "SDXL\\realvisxlV50_v50Bakedvae.safetensors"),
                medit_slot=int(job.get("medit_slot") or 1),
                apply_to_selection=bool(job.get("apply_to_selection", True)),
                uvw_box_mm=float(job.get("uvw_box_mm") or 1000.0),
                tiling_uv=float(job.get("tiling_uv") or 1.0),
                bump_strength=float(job.get("bump_strength") or 1.0),
                enable_displacement=bool(job.get("enable_displacement", False)),
                progress_cb=_emit_prog,
                charge_credits=bool(job.get("charge_credits", True)),
                seed=job.get("seed"),
                send_to_max=bool(job.get("send_to_max", False)),
                pattern_scale=float(job.get("pattern_scale") or 2.0),
            )
        elif j_type == "extract_room":
            _emit_prog("AI Vision анализирует фото интерьера...")
            items = extract_materials_from_reference_image(
                image_path=str(job.get("ref_path") or ""),
                target_hint=str(job.get("prompt_hint") or ""),
            )
            res = {"status": "ok", "kind": "extract_room", "materials": items}
        else:
            res = generate_corona_pbr_from_prompt(
                prompt_text=str(job.get("prompt") or ""),
                res_px=int(job.get("res_px") or 1024),
                pipeline_mode=str(job.get("pipeline_mode") or "chord"),
                ckpt_name=str(job.get("ckpt_name") or "SDXL\\realvisxlV50_v50Bakedvae.safetensors"),
                medit_slot=int(job.get("medit_slot") or 1),
                apply_to_selection=bool(job.get("apply_to_selection", True)),
                uvw_box_mm=float(job.get("uvw_box_mm") or 1000.0),
                tiling_uv=float(job.get("tiling_uv") or 1.0),
                bump_strength=float(job.get("bump_strength") or 1.0),
                enable_displacement=bool(job.get("enable_displacement", False)),
                custom_ior=job.get("custom_ior"),
                custom_clearcoat=job.get("custom_clearcoat"),
                custom_metalness=job.get("custom_metalness"),
                progress_cb=_emit_prog,
                charge_credits=bool(job.get("charge_credits", True)),
                seed=job.get("seed"),
                send_to_max=bool(job.get("send_to_max", False)),
                pattern_scale=float(job.get("pattern_scale") or 2.0),
            )
        print("@@RESULT_JSON@@" + json.dumps(res, ensure_ascii=False), flush=True)
        return 0
    except Exception as exc:
        print(f"@@ERROR@@{exc}", flush=True)
        return 1


# ============================================================================
# Standalone / 3ds Max Companion GUI (Qt Dark Studio -> Tkinter Fallback)
# ============================================================================

def launch_corona_pbr_studio() -> None:
    """Launches the UE5-style Qt Dark Studio if PySide is available, otherwise Tkinter fallback."""
    try:
        import corona_pbr_studio_qt
        corona_pbr_studio_qt.show_corona_pbr_studio_qt(standalone=True)
        return
    except Exception:
        pass
    _launch_corona_pbr_studio_tk()


def _launch_corona_pbr_studio_tk() -> None:
    """Legacy Tkinter fallback window when Qt (PySide2/PySide6) is unavailable."""
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("ComfyUI Corona PBR Studio — 3ds Max & Corona Renderer")
    root.geometry("1060x820")
    root.configure(bg="#14161d")

    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("TFrame", background="#14161d")
    style.configure("Card.TFrame", background="#1d202b")
    style.configure("TLabel", background="#14161d", foreground="#e4e8f2", font=("Segoe UI", 9))
    style.configure("Card.TLabel", background="#1d202b", foreground="#e4e8f2", font=("Segoe UI", 9))
    style.configure("Title.TLabel", background="#14161d", foreground="#67b7ff", font=("Segoe UI", 13, "bold"))
    style.configure("Section.TLabel", background="#1d202b", foreground="#79c0ff", font=("Segoe UI", 10, "bold"))
    style.configure("TButton", background="#2b3142", foreground="#ffffff", font=("Segoe UI", 9, "bold"), padding=5)
    style.map("TButton", background=[("active", "#3b445e")])
    style.configure("Accent.TButton", background="#1f6feb", foreground="#ffffff", font=("Segoe UI", 10, "bold"), padding=7)
    style.map("Accent.TButton", background=[("active", "#388bfd")])
    style.configure("Green.TButton", background="#238636", foreground="#ffffff", font=("Segoe UI", 10, "bold"), padding=7)
    style.map("Green.TButton", background=[("active", "#2ea043")])

    # Header
    hdr = ttk.Frame(root)
    hdr.pack(fill="x", padx=14, pady=(10, 4))
    ttk.Label(hdr, text="ComfyUI Corona PBR Studio (3ds Max + CoronaPhysicalMtl)", style="Title.TLabel").pack(side="left")
    status_var = tk.StringVar(value="[Готово] Выберите пресет, введите промпт или загрузите референс-изображение")
    status_lbl = tk.Label(hdr, textvariable=status_var, bg="#14161d", fg="#56d364", font=("Segoe UI", 9, "bold"))
    status_lbl.pack(side="right")

    # Unified Credits & Key Activation Bar (synced with UE5 & Audit Server)
    credits_bar = tk.Frame(root, bg="#191d27", padx=10, pady=6)
    credits_bar.pack(fill="x", padx=14, pady=(0, 6))

    copy_id_var = tk.StringVar(value=f"Copy ID: {pbr_credits_ledger.get_instance_fingerprint()}")
    tk.Label(
        credits_bar,
        textvariable=copy_id_var,
        bg="#191d27",
        fg="#8b949e",
        font=("Consolas", 9, "bold"),
    ).pack(side="left", padx=(0, 10))

    credits_var = tk.StringVar(value="Credits: ... Gens")
    credits_pill = tk.Label(
        credits_bar,
        textvariable=credits_var,
        bg="#163222",
        fg="#56d364",
        font=("Segoe UI", 9, "bold"),
        padx=8,
        pady=3,
    )
    credits_pill.pack(side="left", padx=(0, 10))

    key_entry_var = tk.StringVar(value="")
    key_entry = tk.Entry(
        credits_bar,
        textvariable=key_entry_var,
        bg="#101218",
        fg="#f0f4fc",
        insertbackground="#ffffff",
        font=("Segoe UI", 9),
        relief="flat",
        width=28,
    )
    key_entry.pack(side="left", fill="x", expand=True, ipady=3, padx=(0, 6))

    def _refresh_credits_bar(sync_server: bool = False):
        bal = pbr_credits_ledger.get_remaining_generations(sync_server=sync_server)
        copy_id_var.set(f"Copy ID: {pbr_credits_ledger.get_instance_fingerprint()}")
        if bal > pbr_credits_ledger.LOW_GENERATIONS_WARNING_THRESHOLD:
            credits_var.set(f"Credits: {bal} Gens")
            credits_pill.configure(bg="#163222", fg="#56d364")
        elif bal > 0:
            credits_var.set(f"Credits: {bal} Gens (LOW)")
            credits_pill.configure(bg="#3b2f10", fg="#f2b63d")
        else:
            credits_var.set("Credits: 0 Gens (TOP UP)")
            credits_pill.configure(bg="#3d1717", fg="#ff6b6b")

    def _on_sync_credits():
        _refresh_credits_bar(sync_server=True)
        bal = pbr_credits_ledger.get_remaining_generations(False)
        status_var.set(f"Баланс синхронизирован: {bal} Gens")

    def _on_activate_key():
        ok, new_bal, msg = pbr_credits_ledger.activate_key(key_entry_var.get())
        _refresh_credits_bar(sync_server=False)
        if ok:
            key_entry_var.set("")
            messagebox.showinfo("Генерации начислены", msg)
            status_var.set(f"Активирован ключ: баланс {new_bal} Gens")
        else:
            messagebox.showwarning("Ключ не принят", msg)

    def _on_buy_credits():
        cid = pbr_credits_ledger.open_buy_url()
        status_var.set(f"Открыт магазин генераций (Copy ID скопирован: {cid})")

    tk.Button(
        credits_bar,
        text="🔑 Активировать",
        command=_on_activate_key,
        bg="#1f6feb",
        fg="#ffffff",
        relief="flat",
        font=("Segoe UI", 8, "bold"),
        padx=8,
        pady=3,
    ).pack(side="left", padx=(0, 4))
    tk.Button(
        credits_bar,
        text="↻",
        command=_on_sync_credits,
        bg="#2b3142",
        fg="#ffffff",
        relief="flat",
        font=("Segoe UI", 8, "bold"),
        padx=6,
        pady=3,
    ).pack(side="left", padx=(0, 4))
    tk.Button(
        credits_bar,
        text="+ Купить генерации",
        command=_on_buy_credits,
        bg="#238636",
        fg="#ffffff",
        relief="flat",
        font=("Segoe UI", 8, "bold"),
        padx=8,
        pady=3,
    ).pack(side="left")

    main_pane = tk.PanedWindow(root, orient="horizontal", bg="#14161d", sashwidth=6, bd=0)
    main_pane.pack(fill="both", expand=True, padx=14, pady=6)

    # Left Column: Prompt + Reference Image + Corona Parameters
    left_frame = ttk.Frame(main_pane, style="Card.TFrame")
    main_pane.add(left_frame, width=540)

    # Right Column: 289 Presets + AI Extracted Reference Materials
    right_frame = ttk.Frame(main_pane, style="Card.TFrame")
    main_pane.add(right_frame, width=480)

    # --- SECTION 1: Prompt & Model Settings ---
    s1 = tk.Frame(left_frame, bg="#1d202b", padx=12, pady=10)
    s1.pack(fill="x", padx=8, pady=(8, 4))
    ttk.Label(s1, text="1. Текстовый промпт материала (RU / EN)", style="Section.TLabel").pack(anchor="w")

    prompt_var = tk.StringVar(value="oak wood parquet floor, classic herringbone pattern, warm natural timber grain")
    prompt_entry = tk.Entry(
        s1,
        textvariable=prompt_var,
        bg="#101218",
        fg="#f0f4fc",
        insertbackground="#ffffff",
        font=("Segoe UI", 10),
        relief="flat",
    )
    prompt_entry.pack(fill="x", pady=(6, 8), ipady=5)

    row_opts = tk.Frame(s1, bg="#1d202b")
    row_opts.pack(fill="x")

    ttk.Label(row_opts, text="Пайплайн:", style="Card.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 6))
    model_var = tk.StringVar(value=DEFAULT_PBR_MODEL_LABEL)
    model_combo = ttk.Combobox(
        row_opts,
        textvariable=model_var,
        values=[m[0] for m in PBR_MODEL_OPTIONS],
        state="readonly",
        width=36,
    )
    model_combo.grid(row=0, column=1, sticky="w", padx=(0, 12))

    ttk.Label(row_opts, text="Разрешение:", style="Card.TLabel").grid(row=0, column=2, sticky="w", padx=(0, 6))
    res_var = tk.StringVar(value=DEFAULT_RESOLUTION_LABEL)
    res_combo = ttk.Combobox(
        row_opts,
        textvariable=res_var,
        values=[r[0] for r in RESOLUTION_OPTIONS],
        state="readonly",
        width=18,
    )
    res_combo.grid(row=0, column=3, sticky="w")

    btn_gen_prompt = ttk.Button(s1, text="СГЕНЕРИРОВАТЬ CORONA PBR ПО ПРОМПТУ", style="Accent.TButton")
    btn_gen_prompt.pack(fill="x", pady=(10, 2))

    # --- SECTION 2: Reference Image to Corona PBR ---
    s2 = tk.Frame(left_frame, bg="#1d202b", padx=12, pady=10)
    s2.pack(fill="x", padx=8, pady=6)
    ttk.Label(s2, text="2. Генерация материала по РЕФЕРЕНСУ (Фото текстуры или Интерьера)", style="Section.TLabel").pack(anchor="w")

    ref_path_var = tk.StringVar(value="")
    ref_row = tk.Frame(s2, bg="#1d202b")
    ref_row.pack(fill="x", pady=(6, 6))
    ref_entry = tk.Entry(
        ref_row,
        textvariable=ref_path_var,
        bg="#101218",
        fg="#c9d1d9",
        insertbackground="#ffffff",
        font=("Segoe UI", 9),
        relief="flat",
    )
    ref_entry.pack(side="left", fill="x", expand=True, ipady=4, padx=(0, 6))

    def _browse_ref():
        p = filedialog.askopenfilename(
            title="Выберите референс-изображение (текстура или фото интерьера)",
            filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.webp;*.bmp"), ("All files", "*.*")],
        )
        if p:
            ref_path_var.set(p)

    ttk.Button(ref_row, text="Обзор...", command=_browse_ref).pack(side="right")

    ref_mode_row = tk.Frame(s2, bg="#1d202b")
    ref_mode_row.pack(fill="x", pady=4)
    ttk.Label(ref_mode_row, text="Режим референса:", style="Card.TLabel").pack(side="left", padx=(0, 8))

    REF_MODES = [
        ("Бесшовный по фото (SDXL Img2Img + 5-Map PBR)", "img2img_seamless"),
        ("Прямое извлечение карт из фото (AI 5-Map PBR Engine Direct)", "chord_direct"),
        ("AI Vision описание референса -> 5-Map PBR", "ai_vision_pbr"),
    ]
    ref_mode_var = tk.StringVar(value=REF_MODES[0][0])
    ref_mode_combo = ttk.Combobox(
        ref_mode_row,
        textvariable=ref_mode_var,
        values=[m[0] for m in REF_MODES],
        state="readonly",
        width=46,
    )
    ref_mode_combo.pack(side="left", fill="x", expand=True)

    denoise_row = tk.Frame(s2, bg="#1d202b")
    denoise_row.pack(fill="x", pady=4)
    ttk.Label(denoise_row, text="Сила изм. (Denoise для Img2Img):", style="Card.TLabel").pack(side="left")
    denoise_var = tk.DoubleVar(value=0.52)
    tk.Scale(
        denoise_row,
        variable=denoise_var,
        from_=0.20,
        to=0.90,
        resolution=0.05,
        orient="horizontal",
        bg="#1d202b",
        fg="#e4e8f2",
        highlightthickness=0,
        length=140,
    ).pack(side="left", padx=8)

    ttk.Label(denoise_row, text="Уточнение (напр. 'пол', 'мрамор'):", style="Card.TLabel").pack(side="left", padx=(6, 4))
    ref_hint_var = tk.StringVar(value="")
    tk.Entry(
        denoise_row,
        textvariable=ref_hint_var,
        bg="#101218",
        fg="#f0f4fc",
        insertbackground="#ffffff",
        width=18,
        relief="flat",
    ).pack(side="left", ipady=3)

    ref_btns = tk.Frame(s2, bg="#1d202b")
    ref_btns.pack(fill="x", pady=(8, 2))
    btn_gen_ref = ttk.Button(ref_btns, text="СОЗДАТЬ PBR МАТЕРИАЛ ПО ФОТО-РЕФЕРЕНСУ", style="Green.TButton")
    btn_gen_ref.pack(side="left", fill="x", expand=True, padx=(0, 6))
    btn_extract_room = ttk.Button(ref_btns, text="AI: Найти все материалы интерьера")
    btn_extract_room.pack(side="right")

    # --- SECTION 3: CoronaPhysicalMtl & 3ds Max Assignment Settings ---
    s3 = tk.Frame(left_frame, bg="#1d202b", padx=12, pady=10)
    s3.pack(fill="both", expand=True, padx=8, pady=(4, 8))
    ttk.Label(s3, text="3. Настройки CoronaPhysicalMtl и назначения в 3ds Max", style="Section.TLabel").pack(anchor="w")

    c_grid = tk.Frame(s3, bg="#1d202b")
    c_grid.pack(fill="x", pady=8)

    apply_sel_var = tk.BooleanVar(value=True)
    tk.Checkbutton(
        c_grid,
        text="Назначить выделенным объектам в 3ds Max",
        variable=apply_sel_var,
        bg="#1d202b",
        fg="#e4e8f2",
        selectcolor="#101218",
        activebackground="#1d202b",
        activeforeground="#ffffff",
    ).grid(row=0, column=0, columnspan=2, sticky="w", pady=2)

    disp_var = tk.BooleanVar(value=False)
    tk.Checkbutton(
        c_grid,
        text="Включить Displacement (Height карта)",
        variable=disp_var,
        bg="#1d202b",
        fg="#e4e8f2",
        selectcolor="#101218",
        activebackground="#1d202b",
        activeforeground="#ffffff",
    ).grid(row=0, column=2, columnspan=2, sticky="w", pady=2)

    ttk.Label(c_grid, text="Слот Material Editor (1-24):", style="Card.TLabel").grid(row=1, column=0, sticky="w", pady=6)
    slot_var = tk.IntVar(value=1)
    tk.Spinbox(c_grid, from_=1, to=24, textvariable=slot_var, width=6, bg="#101218", fg="#ffffff", relief="flat").grid(
        row=1, column=1, sticky="w", padx=6
    )

    ttk.Label(c_grid, text="Размер UVW Box (мм):", style="Card.TLabel").grid(row=1, column=2, sticky="w", pady=6)
    uvw_var = tk.DoubleVar(value=1000.0)
    tk.Spinbox(
        c_grid, from_=100, to=10000, increment=100, textvariable=uvw_var, width=8, bg="#101218", fg="#ffffff", relief="flat"
    ).grid(row=1, column=3, sticky="w", padx=6)

    ttk.Label(c_grid, text="Сила Normal/Bump:", style="Card.TLabel").grid(row=2, column=0, sticky="w", pady=6)
    bump_var = tk.DoubleVar(value=1.0)
    tk.Spinbox(
        c_grid, from_=0.1, to=5.0, increment=0.1, textvariable=bump_var, width=6, bg="#101218", fg="#ffffff", relief="flat"
    ).grid(row=2, column=1, sticky="w", padx=6)

    ttk.Label(c_grid, text="UV Tiling (повтор):", style="Card.TLabel").grid(row=2, column=2, sticky="w", pady=6)
    tile_var = tk.DoubleVar(value=1.0)
    tk.Spinbox(
        c_grid, from_=0.25, to=20.0, increment=0.25, textvariable=tile_var, width=8, bg="#101218", fg="#ffffff", relief="flat"
    ).grid(row=2, column=3, sticky="w", padx=6)

    # Log output box
    ttk.Label(s3, text="Журнал генерации и пути к картам:", style="Card.TLabel").pack(anchor="w", pady=(6, 2))
    log_text = tk.Text(s3, height=9, bg="#0d0f14", fg="#a5d6ff", font=("Consolas", 9), relief="flat")
    log_text.pack(fill="both", expand=True)

    def _log(msg: str):
        def _append():
            status_var.set(msg[:95])
            log_text.insert("end", msg + "\n")
            log_text.see("end")
        root.after(0, _append)

    # --- RIGHT COLUMN: 289 Presets + AI Extracted Materials ---
    r_top = tk.Frame(right_frame, bg="#1d202b", padx=10, pady=10)
    r_top.pack(fill="both", expand=True)

    ttk.Label(r_top, text="Библиотека из 289 PBR Пресетов (12 категорий) + Материалы из Референса", style="Section.TLabel").pack(
        anchor="w", pady=(0, 6)
    )

    cat_bar = tk.Frame(r_top, bg="#1d202b")
    cat_bar.pack(fill="x", pady=(0, 6))

    preset_list = tk.Listbox(
        r_top,
        bg="#101218",
        fg="#e4e8f2",
        selectbackground="#1f6feb",
        selectforeground="#ffffff",
        font=("Segoe UI", 10),
        relief="flat",
        activestyle="none",
    )
    preset_list.pack(fill="both", expand=True)

    current_presets: List[Tuple[str, str, Optional[Dict[str, Any]]]] = []

    def _load_category(cat_key: str):
        preset_list.delete(0, "end")
        current_presets.clear()
        for title, p_txt in CATEGORY_PRESET_PROMPTS.get(cat_key, []):
            current_presets.append((title, p_txt, None))
            preset_list.insert("end", f"  {title}")

    for idx, (cat_key, cat_label) in enumerate(PRESET_CATEGORIES_ORDER):
        b = tk.Button(
            cat_bar,
            text=cat_label,
            bg="#262c3d",
            fg="#d0d8e8",
            activebackground="#1f6feb",
            activeforeground="#ffffff",
            relief="flat",
            font=("Segoe UI", 8, "bold"),
            padx=6,
            pady=3,
            command=lambda ck=cat_key: _load_category(ck),
        )
        b.grid(row=idx // 6, column=idx % 6, padx=2, pady=2, sticky="ew")

    for c_i in range(6):
        cat_bar.grid_columnconfigure(c_i, weight=1)

    def _on_preset_select(_evt=None):
        sel = preset_list.curselection()
        if not sel:
            return
        idx = sel[0]
        if 0 <= idx < len(current_presets):
            _title, p_txt, _meta = current_presets[idx]
            prompt_var.set(p_txt)

    preset_list.bind("<<ListboxSelect>>", _on_preset_select)
    _load_category("wood")

    def _get_selected_res_px() -> int:
        lbl = res_var.get()
        for r_lbl, px, _tag in RESOLUTION_OPTIONS:
            if r_lbl == lbl:
                return px
        return 1024

    def _get_selected_pipe() -> Tuple[str, str]:
        lbl = model_var.get()
        for m_lbl, pipe_mode, ckpt in PBR_MODEL_OPTIONS:
            if m_lbl == lbl:
                return pipe_mode, ckpt
        return "chord", PBR_MODEL_OPTIONS[0][2]

    def _get_selected_ref_mode() -> str:
        mode_lbl = ref_mode_var.get()
        for m_l, m_code in REF_MODES:
            if m_l == mode_lbl:
                return m_code
        return "img2img_seamless"

    def _update_gen_buttons_cost(_evt=None):
        res_px = _get_selected_res_px()
        cost_p = pbr_credits_ledger.get_pbr_generation_cost(res_px)
        cost_r = pbr_credits_ledger.get_pbr_generation_cost(res_px, ref_mode=_get_selected_ref_mode())
        u_p = pbr_credits_ledger.format_cost_unit(cost_p)
        u_r = pbr_credits_ledger.format_cost_unit(cost_r)
        btn_gen_prompt.configure(text=f"СГЕНЕРИРОВАТЬ CORONA PBR ПО ПРОМПТУ ({u_p})")
        btn_gen_ref.configure(text=f"СОЗДАТЬ PBR МАТЕРИАЛ ПО ФОТО-РЕФЕРЕНСУ ({u_r})")

    res_combo.bind("<<ComboboxSelected>>", _update_gen_buttons_cost)
    _update_gen_buttons_cost()

    def _confirm_and_check_studio_credits(res_px: int, job_label: str, ref_mode: str = "") -> bool:
        _refresh_credits_bar(sync_server=True)
        cost = pbr_credits_ledger.get_pbr_generation_cost(res_px, ref_mode=ref_mode)
        bal = pbr_credits_ledger.get_remaining_generations(False)
        cost_s = pbr_credits_ledger.format_credits(cost)
        bal_s = pbr_credits_ledger.format_credits(bal)
        if bal + 1e-6 < float(cost):
            ask_buy = messagebox.askyesno(
                "Недостаточно генераций",
                f"Для {job_label} требуется {cost_s} Gens, а на балансе {bal_s} Gens.\n\n"
                f"Copy ID: {pbr_credits_ledger.get_instance_fingerprint()}\n\n"
                "Открыть страницу покупки пакетов генераций?",
            )
            if ask_buy:
                _on_buy_credits()
            return False
        after_bal_s = pbr_credits_ledger.format_credits(max(0.0, float(bal) - float(cost)))
        return messagebox.askyesno(
            "Подтверждение генерации",
            f"Запустить генерацию {job_label} на Cloud GPU?\n\n"
            f"• Спишется: {cost_s} Gens\n"
            f"• Остаток после старта: {after_bal_s} Gens\n"
            "• При ошибке генерации кредиты вернутся автоматически.\n\nПродолжить?",
        )

    def _run_prompt_gen():
        p_txt = prompt_var.get().strip()
        if not p_txt:
            messagebox.showwarning("Промпт пуст", "Введите описание материала или выберите пресет.")
            return
        res_px = _get_selected_res_px()
        if not _confirm_and_check_studio_credits(res_px, f"Prompt PBR ({res_px}px)"):
            return
        pipe_mode, ckpt = _get_selected_pipe()
        slot = slot_var.get()
        apply_sel = apply_sel_var.get()
        uvw_mm = uvw_var.get()
        tile_uv = tile_var.get()
        bump_val = bump_var.get()
        use_disp = disp_var.get()

        def _worker():
            try:
                res = generate_corona_pbr_from_prompt(
                    prompt_text=p_txt,
                    res_px=res_px,
                    pipeline_mode=pipe_mode,
                    ckpt_name=ckpt,
                    medit_slot=slot,
                    apply_to_selection=apply_sel,
                    uvw_box_mm=uvw_mm,
                    tiling_uv=tile_uv,
                    bump_strength=bump_val,
                    enable_displacement=use_disp,
                    progress_cb=_log,
                    charge_credits=True,
                )
                _log(f"[ГОТОВО] Создан материал {res['material_name']} (Слот #{slot} | Остаток: {res.get('credits_remaining', 0)} Gens) -> {res['dest_folder']}")
                root.after(0, lambda: slot_var.set(min(24, slot + 1)))
                root.after(0, lambda: _refresh_credits_bar(sync_server=False))
            except Exception as e:
                _log(f"[ОШИБКА] {e}")
                root.after(0, lambda: _refresh_credits_bar(sync_server=False))

        threading.Thread(target=_worker, daemon=True).start()

    def _run_ref_gen():
        ref_p = ref_path_var.get().strip()
        if not ref_p or not os.path.exists(ref_p):
            messagebox.showwarning("Референс не выбран", "Укажите путь к файлу референс-изображения.")
            return
        res_px = _get_selected_res_px()
        ref_mode = _get_selected_ref_mode()
        if not _confirm_and_check_studio_credits(res_px, f"Reference PBR ({res_px}px)", ref_mode=ref_mode):
            return

        pipe_mode, ckpt = _get_selected_pipe()
        slot = slot_var.get()
        apply_sel = apply_sel_var.get()
        uvw_mm = uvw_var.get()
        tile_uv = tile_var.get()
        bump_val = bump_var.get()
        use_disp = disp_var.get()
        denoise = denoise_var.get()
        hint = ref_hint_var.get().strip()

        def _worker():
            try:
                res = generate_corona_pbr_from_reference(
                    reference_image_path=ref_p,
                    ref_mode=ref_mode,
                    prompt_hint=hint,
                    denoise=denoise,
                    res_px=res_px,
                    pipeline_mode=pipe_mode,
                    ckpt_name=ckpt,
                    medit_slot=slot,
                    apply_to_selection=apply_sel,
                    uvw_box_mm=uvw_mm,
                    tiling_uv=tile_uv,
                    bump_strength=bump_val,
                    enable_displacement=use_disp,
                    progress_cb=_log,
                    charge_credits=True,
                )
                _log(f"[ГОТОВО ПО РЕФЕРЕНСУ] {res['material_name']} (Слот #{slot} | Остаток: {res.get('credits_remaining', 0)} Gens) -> {res['dest_folder']}")
                root.after(0, lambda: slot_var.set(min(24, slot + 1)))
                root.after(0, lambda: _refresh_credits_bar(sync_server=False))
            except Exception as e:
                _log(f"[ОШИБКА РЕФЕРЕНСА] {e}")
                root.after(0, lambda: _refresh_credits_bar(sync_server=False))

        threading.Thread(target=_worker, daemon=True).start()

    def _run_extract_room_materials():
        ref_p = ref_path_var.get().strip()
        if not ref_p or not os.path.exists(ref_p):
            messagebox.showwarning("Референс не выбран", "Выберите фото интерьера в поле Референса.")
            return
        hint = ref_hint_var.get().strip()

        def _worker():
            try:
                _log("AI Vision анализирует фото интерьера и извлекает материалы...")
                items = extract_materials_from_reference_image(ref_p, target_hint=hint)
                if not items:
                    _log("[AI Vision] Не удалось извлечь материалы.")
                    return

                def _populate():
                    preset_list.delete(0, "end")
                    current_presets.clear()
                    for it in items:
                        t_ru = it.get("title_ru", "Материал")
                        surf = it.get("surface_ru", "")
                        p_en = it.get("prompt_en", "")
                        label = f"[РЕФЕРЕНС: {surf}] {t_ru}" if surf else f"[РЕФЕРЕНС] {t_ru}"
                        current_presets.append((label, p_en, it))
                        preset_list.insert("end", f"★ {label}")
                    if current_presets:
                        preset_list.selection_set(0)
                        prompt_var.set(current_presets[0][1])
                    res_px = _get_selected_res_px()
                    per_mat = pbr_credits_ledger.get_pbr_generation_cost(res_px)
                    tot_cost = len(items) * per_mat
                    bal_now = pbr_credits_ledger.get_remaining_generations(False)
                    _log(
                        f"[AI Vision] Извлечено {len(items)} материалов • "
                        f"Смета при {res_px}px: {tot_cost} Gens ({per_mat}/мат) • Баланс: {bal_now} Gens"
                    )

                root.after(0, _populate)
            except Exception as e:
                _log(f"[ОШИБКА AI Vision] {e}")

        threading.Thread(target=_worker, daemon=True).start()

    btn_gen_prompt.configure(command=_run_prompt_gen)
    btn_gen_ref.configure(command=_run_ref_gen)
    btn_extract_room.configure(command=_run_extract_room_materials)

    _refresh_credits_bar(sync_server=False)
    threading.Thread(target=lambda: root.after(0, lambda: _refresh_credits_bar(sync_server=True)), daemon=True).start()
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--cli-job":
        sys.exit(run_cli_job(sys.argv[2]))
    launch_corona_pbr_studio()
