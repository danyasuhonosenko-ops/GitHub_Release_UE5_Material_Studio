# -*- coding: utf-8 -*-
"""
Unified AI PBR Material Studio Credits Ledger (3ds Max + Corona + UE5)
======================================================================
Shares the exact same hardware Copy ID (`PBR-XXXXXX-XXXXXX`), local JSON state
(`%LOCALAPPDATA%\\UE5PBRStudio\\studio_license_state.json`), Windows Registry
shadow ledger (`HKCU\\Software\\UE5PBRStudio\\Ledger`), 12-word RSA seed verifier,
promo/referral activation, and Audit Scout Server (`127.0.0.1:8788` / gateway)
synchronization as Unreal Engine 5 (`comfy_to_ue.py`).

All `ms_*` helper functions return primitive `str` or `int` values so they can
be invoked directly from Autodesk 3ds Max MAXScript via `python.Import`.
"""

import base64
import builtins
import hashlib
import json
import math
import os
import platform
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
from typing import Any, Dict, List, Optional, Tuple, Union

STUDIO_VERSION = "v2.1.1"
STUDIO_EDITION = "standard"
DEFAULT_FREE_GENERATIONS = 0
DISABLE_RUNTIME_CODE_OTA = False
DEFAULT_UI_SCALE = 1.25
UI_SCALE_OPTIONS = (1.0, 1.15, 1.25, 1.4, 1.55)

BUY_GENERATIONS_URL = "https://danyasuhon.gumroad.com"
DONATE_URL = "https://github.com/danyasuhonosenko-ops/GitHub_Release_UE5_Material_Studio#donate--support"
GITHUB_URL = "https://github.com/danyasuhonosenko-ops/GitHub_Release_UE5_Material_Studio"
PUBLIC_CLOUDFLARE_GATEWAY_URL = "https://desktop-kbo2jj9.tail754f20.ts.net"
TELEMETRY_AUDIT_URL = "https://desktop-kbo2jj9.tail754f20.ts.net/api/audit"
GITHUB_RAW_MAX_BASE = "https://raw.githubusercontent.com/danyasuhonosenko-ops/GitHub_Release_UE5_Material_Studio/main/3dsMax"
GITHUB_BLENDER_RELEASE_BASE = "https://github.com/danyasuhonosenko-ops/GitHub_Release_UE5_Material_Studio/raw/main/Blender"
GITHUB_CLUSTER_CONFIG_URL = "https://raw.githubusercontent.com/danyasuhonosenko-ops/GitHub_Release_UE5_Material_Studio/main/render_cluster_config.json"

def _resolve_studio_appdata_dir() -> str:
    sys_name = platform.system()
    if sys_name == "Windows":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(base, "UE5PBRStudio")
    if sys_name == "Darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), "UE5PBRStudio")
    xdg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(xdg, "UE5PBRStudio")


_STUDIO_APPDATA_DIR = _resolve_studio_appdata_dir()
STUDIO_LICENSE_FILE = os.path.join(_STUDIO_APPDATA_DIR, "studio_license_state.json")

_AUDIT_URLS = (
    "http://127.0.0.1:8788/api/audit",
    "http://100.122.152.89:8788/api/audit",
    "http://100.118.26.47:8788/api/audit",
    TELEMETRY_AUDIT_URL,
    "https://danya-pc.tail754f20.ts.net:10000/api/audit",
    "https://desktop-kbo2jj9.tail754f20.ts.net:10000/api/audit",
)

# XOR-obfuscated FastAPI Security Gateway API Key (key = 0x5A)
_COMFY_GW_TOKEN_OBF = (
    10, 24, 8, 119, 29, 13, 119, 99, 28, 110, 27, 109, 25, 104, 31, 98,
    24, 107, 30, 108, 106, 111, 105, 27, 110, 31, 99, 104, 25, 109, 24, 98,
    30, 107, 28, 105, 31, 108, 27,
)

# Salted SHA-256 digests of promo codes (matches UE5 `comfy_to_ue.py`)
_PROMO_HASH_PACKS = {
    "e838fb679ed61e1b": 25,
    "1303347071dde58a": 25,
    "b53590a7be25fa93": 50,
    "1e3abcadd2680918": 100,
    "d7eb7f7176fec5ba": 500,
}

# 12-Word Wallet-Style Cryptographic Seed Verifier (Public Key Only)
_SEED_PUBLIC_N = 0xA0DE037D9C9846C16EA6114D
_SEED_PUBLIC_E = 65537
_SEED_TIER_CREDITS = {
    0: 10,
    1: 25,
    2: 50,
    3: 100,
    4: 250,
    5: 500,
    6: 1000,
    7: 2500,
    8: 5000,
    9: 10000,
}
_SEED_WORDLIST_256 = [
    "abyss", "acorn", "agate", "albedo", "alchemy", "alloy", "alpine", "amber",
    "amethyst", "anchor", "ancient", "anvil", "apex", "apogee", "aqua", "arcade",
    "arch", "arctic", "argon", "armor", "arrow", "aspen", "astral", "atlas",
    "atom", "atrium", "aurora", "autumn", "avalon", "axiom", "axis", "azure",
    "bamboo", "basalt", "bastion", "beacon", "beryl", "bevel", "birch", "blade",
    "blaze", "bloom", "boulder", "breeze", "brick", "bridge", "bronze", "brush",
    "calcite", "calm", "canopy", "canvas", "canyon", "carbon", "carve", "cascade",
    "castle", "catalyst", "cavern", "cedar", "celeste", "ceramic", "chalice", "chalk",
    "channel", "chisel", "chrome", "cinder", "cipher", "circuit", "citadel", "citrine",
    "clay", "cliff", "cloud", "clover", "cobalt", "comet", "compass", "concrete",
    "conduit", "copper", "coral", "corona", "cortex", "cosmos", "crater", "crest",
    "crimson", "crown", "crystal", "cube", "current", "cyber", "cypress", "dawn",
    "delta", "denim", "desert", "dew", "diamond", "diffuse", "digital", "diode",
    "displacement", "dome", "drift", "dune", "dusk", "dynamo", "ebony", "echo",
    "eclipse", "eden", "elm", "ember", "emerald", "empire", "enigma", "epoch",
    "equinox", "essence", "ether", "evergreen", "fabric", "facet", "falcon", "fern",
    "fiber", "fjord", "flame", "flint", "flora", "flux", "foam", "focus",
    "foliage", "forest", "forge", "fossil", "foundry", "fresco", "frost", "fusion",
    "galaxy", "garnet", "gate", "genesis", "geode", "geyser", "glacier", "glade",
    "glass", "gleam", "glint", "globe", "glow", "gold", "granite", "graphite",
    "gravel", "grove", "gypsum", "halo", "harbor", "harmony", "harvest", "haven",
    "hazel", "hearth", "heather", "helix", "hemisphere", "herald", "horizon", "horn",
    "humidity", "hybrid", "hydra", "hyperion", "iceberg", "icon", "igneous", "impulse",
    "indigo", "infinity", "ingot", "inlet", "ion", "iridium", "iris", "iron",
    "island", "ivory", "jade", "jasper", "jet", "jewel", "jungle", "juniper",
    "karma", "keel", "kelp", "kernel", "kiln", "kinetic", "kingdom", "knight",
    "krypton", "lagoon", "lantern", "lapis", "larva", "laser", "lattice", "lava",
    "laurel", "leather", "kevlar", "legend", "lens", "liberty", "lichen", "light",
    "limestone", "linen", "liquid", "lithium", "loam", "lodestar", "lotus", "lumen",
    "lunar", "luster", "lyric", "magma", "magnet", "mahogany", "malachite", "mantle",
    "maple", "marble", "marina", "matrix", "meadow", "mercury", "meridian", "mesa",
    "metal", "meteor", "mica", "mirage", "mirror", "mist", "monolith", "mosaic",
]
_SEED_WORD_TO_IDX = {w: idx for idx, w in enumerate(_SEED_WORDLIST_256)}

RESOLUTION_COST_MAP = {
    512: 1,
    1024: 1,
    2048: 2,
    4096: 3,
}

LOW_GENERATIONS_WARNING_THRESHOLD = 10


CUSTOM_GATEWAY_KEY = ""


def _get_gateway_key() -> str:
    custom = str(CUSTOM_GATEWAY_KEY or "").strip()
    if custom:
        return custom
    return "".join(chr(b ^ 0x5A) for b in _COMFY_GW_TOKEN_OBF)


def get_instance_fingerprint() -> str:
    """Returns pinned, deterministic Copy ID (`PBR-XXXXXX-XXXXXX`) immune to MAC/VPN changes."""
    def _is_valid_cid(val: str) -> bool:
        s = str(val or "").strip().upper()
        return bool(re.fullmatch(r"PBR-[0-9A-F]{6}-[0-9A-F]{6}", s) and s != "PBR-000000-000000")

    def _pin_registry_cid(cid_val: str) -> None:
        try:
            import winreg
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
                winreg.SetValueEx(rk, "InstanceId", 0, winreg.REG_SZ, cid_val)
        except Exception:
            pass

    try:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
                reg_cid, _ = winreg.QueryValueEx(rk, "InstanceId")
                reg_cid_u = str(reg_cid or "").strip().upper()
                if _is_valid_cid(reg_cid_u):
                    return reg_cid_u
        except Exception:
            pass

        try:
            if STUDIO_LICENSE_FILE and os.path.isfile(STUDIO_LICENSE_FILE):
                with open(STUDIO_LICENSE_FILE, "r", encoding="utf-8") as jf:
                    j_data = json.load(jf)
                if isinstance(j_data, dict):
                    j_cid = str(j_data.get("instance_id") or "").strip().upper()
                    if _is_valid_cid(j_cid):
                        _pin_registry_cid(j_cid)
                        return j_cid
        except Exception:
            pass

        mguid = ""
        try:
            import winreg
            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Cryptography",
                0,
                winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
            ) as mk:
                mg_val, _ = winreg.QueryValueEx(mk, "MachineGuid")
                mguid = str(mg_val or "").strip().lower()
        except Exception:
            mguid = ""

        if mguid:
            raw_hw = f"UE5_PBR_INSTANCE_MGUID|{mguid}|{platform.machine()}"
        else:
            raw_hw = f"UE5_PBR_INSTANCE|{uuid.getnode()}|{platform.node()}|{platform.machine()}"
        h_hex = hashlib.sha256(raw_hw.encode("utf-8")).hexdigest()[:12].upper()
        cid = f"PBR-{h_hex[:6]}-{h_hex[6:12]}"
        _pin_registry_cid(cid)
        return cid
    except Exception:
        return "PBR-000000-000000"


def _get_client_token() -> str:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
            val, _ = winreg.QueryValueEx(rk, "ClientToken")
            tok = str(val or "").strip()
            if tok:
                return tok
    except Exception:
        pass
    try:
        if os.path.isfile(STUDIO_LICENSE_FILE):
            with open(STUDIO_LICENSE_FILE, "r", encoding="utf-8") as jf:
                jd = json.load(jf)
            if isinstance(jd, dict):
                tok = str(jd.get("client_token") or "").strip()
                if tok:
                    return tok
    except Exception:
        pass
    return ""


def _save_client_token(token: str) -> None:
    tok = str(token or "").strip()
    if not tok:
        return
    try:
        import winreg
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
            winreg.SetValueEx(rk, "ClientToken", 0, winreg.REG_SZ, tok)
    except Exception:
        pass
    try:
        st_tok = load_license_state()
        if st_tok.get("client_token") != tok:
            st_tok["client_token"] = tok
            save_license_state(st_tok)
    except Exception:
        pass


_HOST_INFO_CACHE: Optional[Tuple[str, str, str]] = None


def detect_host_app_info() -> Tuple[str, str, str]:
    """Detects host DCC application & version (`(host_app, host_version, host_label)`)."""
    global _HOST_INFO_CACHE
    if _HOST_INFO_CACHE is not None:
        return _HOST_INFO_CACHE

    # 1. Blender (`bpy`)
    try:
        import bpy  # type: ignore
        v = tuple(int(x) for x in getattr(bpy.app, "version", ()))
        if len(v) >= 2:
            ver = f"{v[0]}.{v[1]}.{v[2]}" if len(v) >= 3 and v[2] > 0 else f"{v[0]}.{v[1]}"
            _HOST_INFO_CACHE = ("Blender", ver, f"Blender {ver}")
            return _HOST_INFO_CACHE
    except Exception:
        pass

    # 2. Autodesk 3ds Max (`pymxs` or executable path)
    try:
        import pymxs  # type: ignore
        mv = pymxs.runtime.maxVersion()
        rel_raw = int(mv[0]) if mv else 0
        if rel_raw >= 20000:
            yr = str(1998 + (rel_raw // 1000))
            _HOST_INFO_CACHE = ("3dsMax", yr, f"3ds Max {yr}")
            return _HOST_INFO_CACHE
    except Exception:
        pass
    try:
        search_txt = f"{sys.executable} {sys.prefix} {os.path.dirname(os.path.abspath(__file__))}"
        m_max = re.search(r"3ds\s*Max\s*(20\d{2})", search_txt, re.I)
        if m_max:
            yr = m_max.group(1)
            _HOST_INFO_CACHE = ("3dsMax", yr, f"3ds Max {yr}")
            return _HOST_INFO_CACHE
    except Exception:
        pass

    # 3. Unreal Engine (`unreal`)
    try:
        import unreal  # type: ignore
        raw_u = str(unreal.SystemLibrary.get_engine_version() or "")
        m_u = re.search(r"(\d+\.\d+(?:\.\d+)?)", raw_u)
        u_ver = m_u.group(1) if m_u else ""
        _HOST_INFO_CACHE = ("UE5", u_ver, f"UE {u_ver}" if u_ver else "UE5")
        return _HOST_INFO_CACHE
    except Exception:
        pass

    # 4. Script directory fallback
    low_dir = os.path.dirname(os.path.abspath(__file__)).lower()
    if "ai_pbr_material_studio" in low_dir or "blender" in low_dir:
        _HOST_INFO_CACHE = ("Blender", "", "Blender")
    elif "corona" in low_dir or "3dsmax" in low_dir or "aipbrmaterialstudio" in low_dir:
        _HOST_INFO_CACHE = ("3dsMax", "", "3ds Max")
    else:
        _HOST_INFO_CACHE = ("Standalone", "", "Standalone")
    return _HOST_INFO_CACHE


def detect_os_platform() -> str:
    sys_n = str(platform.system() or "").strip()
    if sys_n == "Darwin":
        return "macOS"
    if sys_n == "Windows":
        return "Windows"
    return sys_n or ""


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    h_app, h_ver, h_lbl = detect_host_app_info()
    os_plat = detect_os_platform()
    hdrs = {
        "X-PBR-Gateway-Key": _get_gateway_key(),
        "X-PBR-Instance-ID": get_instance_fingerprint(),
        "X-PBR-Version": STUDIO_VERSION,
        "X-PBR-Host-App": h_app,
        "X-PBR-Host-Version": h_ver,
        "X-PBR-Host-Label": h_lbl,
        "X-PBR-OS": os_plat,
        "X-PBR-Edition": STUDIO_EDITION,
        "X-PBR-Token-Capable": "1",
        "User-Agent": f"Blender-PBR-Studio/{STUDIO_VERSION} ({h_lbl}; {os_plat})",
    }
    ctok = _get_client_token()
    if ctok:
        hdrs["X-PBR-Client-Token"] = ctok
    if extra:
        hdrs.update(extra)
    return hdrs


def _hash_promo_token(code_str: str, allow_canonical: bool = False) -> str:
    clean = (code_str or "").strip().upper()
    if allow_canonical and clean.startswith("PROMO-") and len(clean) == 22:
        return clean[6:].lower()
    return hashlib.sha256(f"UE5_PBR_PROMO_SALT_V1:{clean}".encode("utf-8")).hexdigest()[:16]


def verify_12word_seed_phrase(phrase: str) -> Tuple[bool, int, int, str, str]:
    tokens = [t.strip().lower() for t in (phrase or "").replace(",", " ").replace("-", " ").split() if t.strip()]
    if len(tokens) != 12:
        return False, 0, 0, "", f"Expected 12 seed words, got {len(tokens)}."
    sig_val = 0
    for tok in tokens:
        idx = _SEED_WORD_TO_IDX.get(tok)
        if idx is None:
            return False, 0, 0, "", f"Unrecognized seed word '{tok}'."
        sig_val = (sig_val << 8) | idx
    if sig_val >= _SEED_PUBLIC_N:
        return False, 0, 0, "", "Invalid 12-word cryptographic signature range."
    m_val = pow(sig_val, _SEED_PUBLIC_E, _SEED_PUBLIC_N)
    chk62 = m_val & ((1 << 62) - 1)
    ser20 = (m_val >> 62) & ((1 << 20) - 1)
    tier4 = (m_val >> 82) & 0xF
    magic8 = (m_val >> 86) & 0xFF
    if magic8 != 0x50:
        return False, 0, 0, "", "Invalid 12-word seed signature."
    raw = f"UE5_PBR_SEED_V2|{magic8:02X}|{tier4:01X}|{ser20:05X}".encode("utf-8")
    expected_chk62 = int.from_bytes(hashlib.sha256(raw).digest()[:8], "big") & ((1 << 62) - 1)
    if chk62 != expected_chk62:
        return False, 0, 0, "", "12-word seed checksum verification failed."
    credits = _SEED_TIER_CREDITS.get(tier4, 0)
    if credits <= 0:
        return False, 0, 0, "", "Unknown generation pack tier in 12-word seed."
    canonical_id = f"SEED12-{tier4:X}-{ser20:05X}"
    return True, credits, ser20, canonical_id, f"Verified 12-word wallet key (#{ser20}): +{credits} AI Generations!"


def clean_credits(val: Any, default: float = 0.0) -> float:
    try:
        v = float(val)
        if v != v:  # NaN guard
            return round(float(default), 2)
        return max(0.0, round(v, 2))
    except (TypeError, ValueError):
        return max(0.0, round(float(default), 2))


def norm_credits(val: Any, default: float = 0.0) -> Union[int, float]:
    v = clean_credits(val, default)
    if abs(v - round(v)) < 1e-6:
        return int(round(v))
    return round(v, 2)


def format_credits(val: Any, thousands_sep: str = "") -> str:
    n = norm_credits(val, 0.0)
    if isinstance(n, int):
        s = f"{n:,}"
    else:
        s = f"{n:,.2f}".rstrip("0").rstrip(".")
    return s.replace(",", thousands_sep) if thousands_sep else s.replace(",", "")


def format_cost_unit(cost: Any) -> str:
    n = norm_credits(cost, 1.0)
    s = format_credits(n)
    return f"{s} Gen" if (isinstance(n, (int, float)) and n <= 1.0 + 1e-6) else f"{s} Gens"


def _load_shadow_ledger() -> dict:
    shadow = {"total_spent": 0.0, "redeemed_keys": []}
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
            sp_dw = 0.0
            sp_pr = 0.0
            try:
                sp, _ = winreg.QueryValueEx(rk, "TotalSpent")
                sp_dw = max(0.0, float(sp))
            except Exception:
                pass
            try:
                sp2, _ = winreg.QueryValueEx(rk, "TotalSpentPrecise")
                sp_pr = clean_credits(sp2, 0.0)
            except Exception:
                pass
            shadow["total_spent"] = clean_credits(max(sp_dw, sp_pr))
            try:
                rk_str, _ = winreg.QueryValueEx(rk, "RedeemedKeys")
                if rk_str:
                    shadow["redeemed_keys"] = json.loads(rk_str)
            except Exception:
                pass
    except Exception:
        pass
    return shadow


def _save_shadow_ledger(total_spent: float, redeemed_keys: list) -> None:
    try:
        import winreg
        sp_clean = clean_credits(total_spent, 0.0)
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\UE5PBRStudio\Ledger") as rk:
            winreg.SetValueEx(rk, "TotalSpent", 0, winreg.REG_DWORD, max(0, int(math.floor(sp_clean + 1e-6))))
            winreg.SetValueEx(rk, "TotalSpentPrecise", 0, winreg.REG_SZ, f"{sp_clean:.2f}")
            winreg.SetValueEx(rk, "RedeemedKeys", 0, winreg.REG_SZ, json.dumps(list(redeemed_keys or [])))
    except Exception:
        pass


def _compute_verified_minted_credits(redeemed_keys: list, admin_bonus: int = 0) -> int:
    tier_map = {
        0: 10, 1: 25, 2: 50, 3: 100, 4: 250,
        5: 500, 6: 1000, 7: 2500, 8: 5000, 9: 10000,
    }
    total_unlocked = max(0, int(DEFAULT_FREE_GENERATIONS)) + max(0, int(admin_bonus or 0))
    seen = set()
    for k in (redeemed_keys or []):
        ks = str(k).strip().upper()
        if not ks or ks in seen:
            continue
        seen.add(ks)
        ph = _hash_promo_token(ks, allow_canonical=True)
        if ph in _PROMO_HASH_PACKS:
            total_unlocked += _PROMO_HASH_PACKS[ph]
        elif ks.startswith("SEED12-"):
            parts = ks.split("-")
            if len(parts) == 3:
                try:
                    t_idx = int(parts[1], 16)
                    total_unlocked += tier_map.get(t_idx, 0)
                except Exception:
                    pass
        elif ks.startswith(("REF-", "REFBONUS-")):
            parts = ks.split("-")
            if len(parts) >= 3:
                try:
                    total_unlocked += max(0, int(parts[-1]))
                except Exception:
                    pass
    return total_unlocked


def load_license_state() -> dict:
    """Loads shared wallet JSON reconciled with Windows Registry shadow state without stripping UE5 fields."""
    inst_id = get_instance_fingerprint()
    shadow = _load_shadow_ledger()
    shadow_keys = list(dict.fromkeys(list(shadow.get("redeemed_keys") or [])))
    shadow_spent = clean_credits(shadow.get("total_spent", 0))
    shadow_minted = _compute_verified_minted_credits(shadow_keys)

    default_state = {
        "instance_id": inst_id,
        "credits": norm_credits(max(0.0, float(shadow_minted) - shadow_spent)),
        "total_spent": norm_credits(shadow_spent),
        "admin_bonus_credits": 0,
        "license_key": "",
        "buy_url": BUY_GENERATIONS_URL,
        "donate_url": DONATE_URL,
        "telemetry_url": TELEMETRY_AUDIT_URL,
        "enforce_limit": True,
        "redeemed_keys": shadow_keys,
    }
    try:
        if os.path.isfile(STUDIO_LICENSE_FILE):
            with open(STUDIO_LICENSE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in default_state.items():
                    data.setdefault(k, v)
                data["instance_id"] = inst_id
                data["enforce_limit"] = True
                admin_bonus = clean_credits(data.get("admin_bonus_credits") or 0)
                merged_spent = clean_credits(max(clean_credits(data.get("total_spent", 0)), shadow_spent))
                merged_keys = list(dict.fromkeys(list(data.get("redeemed_keys") or []) + shadow_keys))
                # Strip disabled FAB-EDITION-90 token if present so server never flags anomaly
                merged_keys = [k for k in merged_keys if str(k).strip().upper() != "FAB-EDITION-90"]
                legit_minted = float(_compute_verified_minted_credits(merged_keys, admin_bonus=int(round(admin_bonus))))
                computed_credits = norm_credits(max(0.0, legit_minted - merged_spent))
                merged_spent_norm = norm_credits(merged_spent)
                changed = (
                    abs(clean_credits(data.get("total_spent", 0)) - merged_spent) > 1e-6
                    or list(data.get("redeemed_keys") or []) != merged_keys
                    or abs(clean_credits(data.get("credits", 0)) - float(computed_credits)) > 1e-6
                )
                data["total_spent"] = merged_spent_norm
                data["redeemed_keys"] = merged_keys
                data["credits"] = computed_credits
                if changed:
                    save_license_state(data)
                return data
    except Exception:
        pass
    save_license_state(default_state)
    return default_state


def save_license_state(state_dict: dict) -> None:
    """Preserves all unrelated UE5 fields already in `studio_license_state.json` and updates Registry shadow."""
    merged = {}
    try:
        if os.path.isfile(STUDIO_LICENSE_FILE):
            with open(STUDIO_LICENSE_FILE, "r", encoding="utf-8") as f:
                existing = json.load(f)
            if isinstance(existing, dict):
                merged.update(existing)
    except Exception:
        pass
    merged.update(state_dict or {})

    try:
        _save_shadow_ledger(
            clean_credits(merged.get("total_spent", 0)),
            list(merged.get("redeemed_keys") or []),
        )
    except Exception:
        pass
    try:
        os.makedirs(_STUDIO_APPDATA_DIR, exist_ok=True)
        tmp_path = STUDIO_LICENSE_FILE + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(merged, f, indent=2, ensure_ascii=False)
        os.replace(tmp_path, STUDIO_LICENSE_FILE)
    except Exception:
        try:
            with open(STUDIO_LICENSE_FILE, "w", encoding="utf-8") as f:
                json.dump(merged, f, indent=2, ensure_ascii=False)
        except Exception:
            pass


def build_audit_report(state_dict: Optional[dict] = None) -> dict:
    st = state_dict if isinstance(state_dict, dict) else load_license_state()
    inst_id = str(st.get("instance_id") or get_instance_fingerprint())
    cur_credits = clean_credits(st.get("credits", 0))
    spent_credits = clean_credits(st.get("total_spent", 0))
    admin_bonus = int(round(clean_credits(st.get("admin_bonus_credits") or 0)))
    redeemed = [k for k in (st.get("redeemed_keys") or []) if str(k).strip().upper() != "FAB-EDITION-90"]
    legit_minted = float(_compute_verified_minted_credits(redeemed, admin_bonus=admin_bonus))
    expected_max = max(0.0, clean_credits(legit_minted - spent_credits))
    unaccounted = max(0.0, clean_credits(cur_credits - expected_max))
    h_app, h_ver, h_lbl = detect_host_app_info()
    return {
        "instance_id": inst_id,
        "studio_version": STUDIO_VERSION,
        "host_app": h_app,
        "host_version": h_ver,
        "host_label": h_lbl,
        "os_platform": detect_os_platform(),
        "studio_edition": STUDIO_EDITION,
        "comfy_url": str(st.get("comfy_url") or PUBLIC_CLOUDFLARE_GATEWAY_URL),
        "referred_by": str(st.get("referred_by") or ""),
        "credits_remaining": norm_credits(cur_credits),
        "legitimate_minted_total": norm_credits(legit_minted),
        "paid_minted_total": norm_credits(legit_minted),
        "total_spent": norm_credits(spent_credits),
        "expected_balance": norm_credits(expected_max),
        "unaccounted_credits": norm_credits(unaccounted),
        "anomaly_detected": unaccounted > 1e-6,
        "redeemed_keys": redeemed,
    }


_LAST_WORKING_AUDIT_URL: Optional[str] = None
_LAST_SYNC_MONOTONIC: float = 0.0


def sync_with_audit_server(
    event_type: str = "max_panel_sync",
    extra: Optional[Dict[str, Any]] = None,
    timeout_local: float = 0.75,
    timeout_remote: float = 1.8,
) -> Dict[str, Any]:
    """Synchronizes local ledger state with Audit Scout Server (port 8788 / Tailscale gateway)."""
    global _LAST_WORKING_AUDIT_URL, _LAST_SYNC_MONOTONIC
    st = load_license_state()
    report = build_audit_report(st)
    report["event"] = event_type
    report["timestamp"] = int(time.time())
    if extra:
        report.update(extra)

    synced = False
    revoked_set = set()
    raw_body = json.dumps(report).encode("utf-8")

    urls_ordered = list(_AUDIT_URLS)
    if _LAST_WORKING_AUDIT_URL and _LAST_WORKING_AUDIT_URL in urls_ordered:
        urls_ordered.remove(_LAST_WORKING_AUDIT_URL)
        urls_ordered.insert(0, _LAST_WORKING_AUDIT_URL)

    for url_target in urls_ordered:
        is_local = "127.0.0.1" in url_target or "100.122.152.89" in url_target or "100.118.26.47" in url_target
        t_out = timeout_local if is_local else timeout_remote
        try:
            req = urllib.request.Request(
                url_target,
                data=raw_body,
                headers=_headers({"Content-Type": "application/json"}),
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=t_out) as resp:
                resp_data = json.loads(resp.read().decode("utf-8"))
            if not isinstance(resp_data, dict):
                continue
            synced = True
            _LAST_WORKING_AUDIT_URL = url_target
            _LAST_SYNC_MONOTONIC = time.monotonic()

            st_cur = load_license_state()
            changed = False

            if resp_data.get("revoked_keys"):
                revoked_set = {str(x).strip().upper() for x in (resp_data.get("revoked_keys") or []) if str(x).strip()}
                if revoked_set:
                    clean_rk = [k for k in (st_cur.get("redeemed_keys") or []) if str(k).strip().upper() not in revoked_set]
                    if clean_rk != list(st_cur.get("redeemed_keys") or []):
                        st_cur["redeemed_keys"] = clean_rk
                        changed = True

            if resp_data.get("server_redeemed_keys"):
                cur_rk = [k for k in (st_cur.get("redeemed_keys") or []) if str(k).strip().upper() not in revoked_set]
                for s_rk in (resp_data.get("server_redeemed_keys") or []):
                    s_rk_u = str(s_rk or "").strip().upper()
                    if s_rk_u and s_rk_u not in cur_rk and s_rk_u not in revoked_set:
                        cur_rk.append(s_rk_u)
                        changed = True
                st_cur["redeemed_keys"] = cur_rk

            if resp_data.get("grant_referral_rewards"):
                cur_rk = list(st_cur.get("redeemed_keys") or [])
                for rw in (resp_data.get("grant_referral_rewards") or []):
                    rw_id = str(rw.get("id") or "").strip().upper()
                    if rw_id and rw_id not in cur_rk:
                        cur_rk.append(rw_id)
                        changed = True
                st_cur["redeemed_keys"] = cur_rk

            if "server_total_spent" in resp_data and resp_data.get("server_total_spent") is not None:
                srv_spent = clean_credits(resp_data["server_total_spent"])
                if srv_spent > clean_credits(st_cur.get("total_spent", 0)) + 1e-6 or event_type == "credit_refunded":
                    st_cur["total_spent"] = norm_credits(srv_spent)
                    changed = True

            if "server_credits_remaining" in resp_data and resp_data.get("server_credits_remaining") is not None:
                srv_rem = clean_credits(resp_data["server_credits_remaining"])
                srv_spent_eff = clean_credits(resp_data.get("server_total_spent") if resp_data.get("server_total_spent") is not None else st_cur.get("total_spent") or 0)
                keys_minted = float(_compute_verified_minted_credits(st_cur.get("redeemed_keys") or [], admin_bonus=0))
                implied_bonus = max(0, int(round((srv_rem + srv_spent_eff) - keys_minted)))
                if implied_bonus != int(round(clean_credits(st_cur.get("admin_bonus_credits") or 0))):
                    st_cur["admin_bonus_credits"] = implied_bonus
                    changed = True
                if abs(clean_credits(st_cur.get("credits", 0)) - srv_rem) > 1e-6:
                    st_cur["credits"] = norm_credits(srv_rem)
                    changed = True

            if resp_data.get("action") == "clamp_to_legitimate":
                clamped = clean_credits(resp_data.get("set_credits", st_cur.get("credits", 0)))
                admin_b = int(round(clean_credits(st_cur.get("admin_bonus_credits") or 0)))
                legit_t = float(_compute_verified_minted_credits(st_cur.get("redeemed_keys") or [], admin_bonus=admin_b))
                st_cur["credits"] = norm_credits(clamped)
                st_cur["total_spent"] = norm_credits(max(0.0, legit_t - clamped))
                changed = True

            if resp_data.get("issue_client_token"):
                new_tok = str(resp_data.get("issue_client_token") or "").strip()
                if new_tok and st_cur.get("client_token") != new_tok:
                    st_cur["client_token"] = new_tok
                    _save_client_token(new_tok)
                    changed = True

            if changed:
                save_license_state(st_cur)

            if not DISABLE_RUNTIME_CODE_OTA and not getattr(builtins, "_MAX_PBR_OTA_CHECKED", False):
                srv_ver = str(resp_data.get("latest_version") or "").strip()
                srv_max_hash = str(resp_data.get("max_ota_hash") or "").strip().lower()
                cur_max_hash = str(st_cur.get("max_ota_hash") or "").strip().lower()
                needs_ota = (srv_ver and _ver_tuple(srv_ver) > _ver_tuple(STUDIO_VERSION)) or (
                    srv_max_hash and srv_max_hash != cur_max_hash
                )
                if needs_ota:
                    builtins._MAX_PBR_OTA_CHECKED = True
                    threading.Thread(target=lambda: perform_max_ota_update(force=False), daemon=True).start()
            break
        except Exception:
            continue

    st_final = load_license_state()
    return {
        "synced": synced,
        "instance_id": st_final["instance_id"],
        "credits": norm_credits(st_final.get("credits", 0)),
        "total_spent": norm_credits(st_final.get("total_spent", 0)),
        "revoked_keys": sorted(revoked_set),
    }


def get_remaining_generations(sync_server: bool = False) -> Union[int, float]:
    if sync_server:
        res = sync_with_audit_server(event_type="max_balance_check")
        return norm_credits(res["credits"])
    st = load_license_state()
    return norm_credits(st.get("credits", 0))


def get_pbr_generation_cost(res_px: int = 1024, ref_mode: str = "") -> Union[int, float]:
    base = float(RESOLUTION_COST_MAP.get(int(res_px), 1))
    if str(ref_mode or "").strip().lower() == "chord_direct":
        return norm_credits(base * 0.5)
    return norm_credits(base)


def consume_credits(
    cost: float,
    event_type: str = "credit_consumed",
    extra: Optional[Dict[str, Any]] = None,
    enforce: bool = True,
) -> Tuple[bool, Union[int, float], str]:
    eff_cost = clean_credits(cost, 0.0)
    if eff_cost <= 1e-6:
        bal = get_remaining_generations(sync_server=False)
        return True, bal, "No credits required."

    if time.monotonic() - _LAST_SYNC_MONOTONIC > 10.0:
        sync_res = sync_with_audit_server(event_type="pre_generate_check")
    else:
        sync_res = {"credits": get_remaining_generations(sync_server=False)}
    st = load_license_state()
    cur = clean_credits(st.get("credits", sync_res["credits"]))
    if enforce and (cur + 1e-6) < eff_cost:
        return (
            False,
            norm_credits(cur),
            f"Недостаточно генераций: требуется {format_credits(eff_cost)} Gens, доступно {format_credits(cur)} Gens.",
        )

    new_bal = norm_credits(max(0.0, cur - eff_cost))
    st["credits"] = new_bal
    st["total_spent"] = norm_credits(clean_credits(st.get("total_spent", 0)) + eff_cost)
    save_license_state(st)

    payload_extra = {"cost": norm_credits(eff_cost)}
    if extra:
        payload_extra.update(extra)

    def _async_post_consume() -> None:
        try:
            sync_with_audit_server(event_type=event_type, extra=payload_extra)
        except Exception:
            pass

    threading.Thread(target=_async_post_consume, daemon=True).start()
    return True, new_bal, f"Списано {format_credits(eff_cost)} Gens. Остаток: {format_credits(new_bal)} Gens."


def refund_credits(cost: float, reason: str = "generation_error") -> Tuple[bool, Union[int, float], str]:
    eff_cost = clean_credits(cost, 0.0)
    if eff_cost <= 1e-6:
        return False, get_remaining_generations(False), "Nothing to refund."
    st = load_license_state()
    st["credits"] = norm_credits(clean_credits(st.get("credits", 0)) + eff_cost)
    st["total_spent"] = norm_credits(max(0.0, clean_credits(st.get("total_spent", 0)) - eff_cost))
    save_license_state(st)
    sync_out = sync_with_audit_server(
        event_type="credit_refunded",
        extra={"refunded": norm_credits(eff_cost), "reason": str(reason or "error")},
    )
    return True, norm_credits(sync_out["credits"]), f"Возвращено {format_credits(eff_cost)} Gens ({reason})."


def activate_key(key_raw: str) -> Tuple[bool, int, str]:
    key_clean = (key_raw or "").strip()
    if not key_clean:
        cur = get_remaining_generations(False)
        return False, cur, "Введите 12-словный Seed-ключ, промокод или реферальный код."

    st = load_license_state()
    redeemed = list(st.get("redeemed_keys") or [])

    word_tokens = [t.strip().lower() for t in key_clean.replace(",", " ").replace("-", " ").split() if t.strip()]
    if len(word_tokens) >= 4:
        ok_seed, seed_credits, seed_serial, seed_id, seed_msg = verify_12word_seed_phrase(key_clean)
        if not ok_seed:
            return False, norm_credits(st.get("credits", 0)), seed_msg
        if seed_id in redeemed:
            return False, norm_credits(st.get("credits", 0)), f"Этот 12-словный ключ (#{seed_serial}) уже активирован."

        redeemed.append(seed_id)
        st["redeemed_keys"] = redeemed
        st["license_key"] = seed_id
        st["credits"] = norm_credits(clean_credits(st.get("credits", 0)) + seed_credits)
        save_license_state(st)

        sync_out = sync_with_audit_server(
            event_type="seed_redeemed",
            extra={"redeemed_id": seed_id, "added_credits": seed_credits},
        )
        if not sync_out["synced"]:
            st_rb = load_license_state()
            clean_rb = [k for k in (st_rb.get("redeemed_keys") or []) if str(k).strip().upper() != seed_id]
            st_rb["redeemed_keys"] = clean_rb
            admin_b = int(round(clean_credits(st_rb.get("admin_bonus_credits") or 0)))
            st_rb["credits"] = norm_credits(max(0.0, float(_compute_verified_minted_credits(clean_rb, admin_b)) - clean_credits(st_rb.get("total_spent", 0))))
            save_license_state(st_rb)
            return False, norm_credits(st_rb["credits"]), "Требуется подключение к серверу лицензий для привязки ключа."

        if seed_id.upper() in sync_out.get("revoked_keys", []):
            return False, norm_credits(sync_out["credits"]), f"Ключ (#{seed_serial}) уже привязан к другому Copy ID."

        return True, norm_credits(sync_out["credits"]), f"{seed_msg} (Баланс: {format_credits(sync_out['credits'])} Gens)"

    key_up = key_clean.upper()
    if key_up.startswith("PROMO-"):
        return False, norm_credits(st.get("credits", 0)), "Неверный формат промокода."

    promo_digest = _hash_promo_token(key_up)
    promo_canonical = f"PROMO-{promo_digest.upper()}"
    if promo_digest in _PROMO_HASH_PACKS:
        if promo_canonical in redeemed or key_up in redeemed:
            return False, norm_credits(st.get("credits", 0)), f"Промокод '{key_up}' уже активирован."
        added = _PROMO_HASH_PACKS[promo_digest]
        redeemed.append(promo_canonical)
        st["redeemed_keys"] = redeemed
        st["license_key"] = promo_canonical
        st["credits"] = norm_credits(clean_credits(st.get("credits", 0)) + added)
        save_license_state(st)
        sync_out = sync_with_audit_server(
            event_type="promo_redeemed",
            extra={"redeemed_id": promo_canonical, "added_credits": added},
        )
        return True, norm_credits(sync_out["credits"]), f"Промокод '{key_up}' активирован: +{added} Gens!"

    # Referral code via Audit Server
    inst_id = get_instance_fingerprint()
    ref_res = None
    for audit_u in _AUDIT_URLS:
        ref_u = audit_u.replace("/api/audit", "/api/referral_redeem")
        try:
            req = urllib.request.Request(
                ref_u,
                data=json.dumps({"instance_id": inst_id, "code": key_up}).encode("utf-8"),
                headers=_headers({"Content-Type": "application/json"}),
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=3.5) as resp:
                ref_res = json.loads(resp.read().decode("utf-8"))
            if isinstance(ref_res, dict):
                break
        except Exception:
            continue

    if isinstance(ref_res, dict) and ref_res.get("ok"):
        added_ref = int(ref_res.get("bonus_credits", 10))
        ref_canonical = str(ref_res.get("canonical_id") or f"REF-{key_up}-{added_ref}")
        if ref_canonical in redeemed:
            return False, norm_credits(st.get("credits", 0)), f"Реферальный код '{key_up}' уже использован."
        redeemed.append(ref_canonical)
        st["redeemed_keys"] = redeemed
        st["referred_by"] = key_up
        st["license_key"] = ref_canonical
        st["credits"] = norm_credits(clean_credits(st.get("credits", 0)) + added_ref)
        save_license_state(st)
        sync_out = sync_with_audit_server(
            event_type="referral_redeemed",
            extra={"redeemed_id": ref_canonical, "referral_code": key_up, "added_credits": added_ref},
        )
        return True, norm_credits(sync_out["credits"]), f"Реферальный код '{key_up}': +{added_ref} Gens!"
    if isinstance(ref_res, dict) and ref_res.get("error"):
        return False, norm_credits(st.get("credits", 0)), str(ref_res["error"])

    return False, norm_credits(st.get("credits", 0)), f"Нераспознанный 12-словный ключ или промокод: '{key_clean[:24]}'."


def _copy_text_to_clipboard(text: str) -> None:
    try:
        import bpy  # type: ignore
        wm = getattr(bpy.context, "window_manager", None)
        if wm is not None:
            wm.clipboard = str(text or "")
            return
    except Exception:
        pass
    if platform.system() == "Darwin":
        try:
            import subprocess
            subprocess.run(["pbcopy"], input=str(text or "").encode("utf-8"), check=True)
            return
        except Exception:
            pass
    elif platform.system() != "Windows":
        import shutil as _shutil, subprocess
        for cmd in (["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"], ["wl-copy"]):
            if _shutil.which(cmd[0]):
                try:
                    subprocess.run(cmd, input=str(text or "").encode("utf-8"), check=True)
                    return
                except Exception:
                    pass
    try:
        import ctypes
        CF_UNICODETEXT = 13
        GMEM_MOVEABLE = 0x0002
        u32 = ctypes.windll.user32
        k32 = ctypes.windll.kernel32
        data = (str(text or "") + "\0").encode("utf-16le")
        h_mem = k32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not h_mem:
            return
        p_mem = k32.GlobalLock(h_mem)
        ctypes.memmove(p_mem, data, len(data))
        k32.GlobalUnlock(h_mem)
        if u32.OpenClipboard(0):
            u32.EmptyClipboard()
            u32.SetClipboardData(CF_UNICODETEXT, h_mem)
            u32.CloseClipboard()
        else:
            k32.GlobalFree(h_mem)
    except Exception:
        pass


def open_buy_url() -> str:
    inst_id = get_instance_fingerprint()
    _copy_text_to_clipboard(inst_id)
    try:
        webbrowser.open(BUY_GENERATIONS_URL)
    except Exception:
        pass
    return inst_id


# ----------------------------------------------------------------------------
# MaxScript-Friendly Primitive Wrappers (return only `str` or `int`)
# ----------------------------------------------------------------------------

def ms_get_instance_id() -> str:
    return str(get_instance_fingerprint())


def ms_get_balance(sync_server: bool = False) -> Union[int, float]:
    return norm_credits(get_remaining_generations(sync_server=bool(sync_server)))


def ms_get_status_line(sync_server: bool = False) -> str:
    bal = get_remaining_generations(sync_server=bool(sync_server))
    inst_id = get_instance_fingerprint()
    tag = "OK" if float(bal) > LOW_GENERATIONS_WARNING_THRESHOLD else ("МАЛО" if float(bal) > 0 else "0 — ПОПОЛНИТЬ")
    return f"Copy ID: {inst_id} | Баланс: {format_credits(bal)} Gens ({tag})"


def ms_redeem_key(key_raw: str) -> str:
    ok, bal, msg = activate_key(str(key_raw or ""))
    clean_msg = str(msg or "").replace("|", "/").replace("\n", " ")
    return f"{'OK' if ok else 'ERR'}|{format_credits(bal)}|{clean_msg}"


def ms_consume_credits(cost: float, event_type: str = "corona_export_consumed", details: str = "") -> str:
    extra = {"details": str(details or "")} if details else None
    ok, bal, msg = consume_credits(clean_credits(cost, 1.0), event_type=str(event_type or "credit_consumed"), extra=extra, enforce=True)
    clean_msg = str(msg or "").replace("|", "/").replace("\n", " ")
    return f"{'OK' if ok else 'ERR'}|{format_credits(bal)}|{clean_msg}"


def ms_refund_credits(cost: float, reason: str = "error") -> str:
    ok, bal, msg = refund_credits(clean_credits(cost, 1.0), reason=str(reason or "error"))
    clean_msg = str(msg or "").replace("|", "/").replace("\n", " ")
    return f"{'OK' if ok else 'ERR'}|{format_credits(bal)}|{clean_msg}"


def ms_open_buy_url() -> str:
    return str(open_buy_url())


def get_profile_avatar_id() -> str:
    """Returns persisted profile avatar filename (e.g. 'avatar_02.png'), shared with UE5 Studio."""
    st = load_license_state()
    raw = str(st.get("avatar_id") or "").strip()
    if re.fullmatch(r"avatar_\d{2}\.png", raw):
        return raw
    return "avatar_02.png"


def set_profile_avatar_id(avatar_filename: str) -> str:
    """Persists the selected profile avatar filename cleanly in studio_license_state.json."""
    fn = os.path.basename(str(avatar_filename or "").strip())
    if not re.fullmatch(r"avatar_\d{2}\.png", fn):
        fn = "avatar_02.png"
    st = load_license_state()
    st["avatar_id"] = fn
    save_license_state(st)
    return fn


def resolve_avatar_path(avatar_filename: str = "") -> str:
    """Finds the circular PNG path for the requested (or active) profile avatar."""
    fn = os.path.basename(str(avatar_filename or "").strip()) or get_profile_avatar_id()
    if not re.fullmatch(r"avatar_\d{2}\.png", fn):
        fn = "avatar_02.png"
    plugin_dir = os.path.dirname(os.path.abspath(__file__))
    candidates_dirs = (
        os.path.join(plugin_dir, "Avatars"),
        os.path.join(os.path.dirname(plugin_dir), "Avatars"),
        os.path.join(os.path.dirname(plugin_dir), "Resources", "Avatars"),
    )
    for d in candidates_dirs:
        cand = os.path.join(d, fn)
        if os.path.isfile(cand):
            return cand
        fallback = os.path.join(d, "avatar_02.png")
        if os.path.isfile(fallback):
            return fallback
    return ""


def get_ui_scale() -> float:
    """Returns persisted UI scale factor for 3ds Max Qt plugins (default 1.25)."""
    st = load_license_state()
    try:
        raw = float(st.get("max_ui_scale", DEFAULT_UI_SCALE))
        if 1.0 <= raw <= 1.6:
            return round(raw, 2)
    except Exception:
        pass
    return DEFAULT_UI_SCALE


def set_ui_scale(scale: float) -> float:
    """Clamps and persists 3ds Max Qt UI scale factor into studio_license_state.json."""
    try:
        val = round(max(1.0, min(1.6, float(scale))), 2)
    except Exception:
        val = DEFAULT_UI_SCALE
    st = load_license_state()
    st["max_ui_scale"] = val
    save_license_state(st)
    return val


def _ver_tuple(ver_str: str) -> Tuple[int, int, int]:
    parts = re.findall(r"\d+", str(ver_str or ""))
    nums = [int(x) for x in parts[:3]]
    while len(nums) < 3:
        nums.append(0)
    return (nums[0], nums[1], nums[2])


def _write_ota_file_if_changed(dst_path: str, raw_bytes: bytes, min_bytes: int = 256) -> bool:
    """Atomically writes OTA payload bytes if content hash changed."""
    if not raw_bytes or len(raw_bytes) <= int(min_bytes):
        return False
    new_sha = hashlib.sha256(raw_bytes).hexdigest()
    if os.path.isfile(dst_path):
        try:
            with open(dst_path, "rb") as ef:
                if hashlib.sha256(ef.read()).hexdigest() == new_sha:
                    return False
        except Exception:
            pass
    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    tmp_path = dst_path + ".ota_tmp"
    with open(tmp_path, "wb") as wf:
        wf.write(raw_bytes)
    os.replace(tmp_path, dst_path)
    return True


_MAX_OTA_MANAGED_FILES = (
    "studio_qt_theme.py",
    "pbr_credits_ledger.py",
    "comfy_to_corona.py",
    "presets_data.py",
    "corona_pbr_studio_qt.py",
    "corona_ue5_exporter_qt.py",
    "run_job.py",
    "Corona_ComfyPBR_Studio.ms",
    "Corona_to_UE5_Exporter.ms",
)


def perform_max_ota_update(force: bool = False) -> Tuple[bool, str]:
    """Downloads and atomically applies OTA updates for 3ds Max GitHub Edition builds."""
    if DISABLE_RUNTIME_CODE_OTA:
        return False, "Runtime updates are disabled in Fab Edition (update via Fab)."

    plugin_dir = os.path.dirname(os.path.abspath(__file__))
    low_dir = plugin_dir.lower()
    if "corona_comfyui_pbr_plugin" in low_dir or "uncompiled_backup" in low_dir:
        return False, "Development source folder skipped."
    if getattr(builtins, "_MAX_PBR_OTA_IN_PROGRESS", False):
        return False, "OTA update already in progress."

    builtins._MAX_PBR_OTA_IN_PROGRESS = True
    updated_count = 0
    fetched_source = False
    pulled_ver = STUDIO_VERSION
    pulled_hash = ""
    try:
        st = load_license_state()
        saved_hash = str(st.get("max_ota_hash") or "").strip().lower()
        pull_urls = [
            "http://127.0.0.1:8788/api/ota_pull_max",
            "https://danya-pc.tail754f20.ts.net:10000/api/ota_pull_max",
            f"{PUBLIC_CLOUDFLARE_GATEWAY_URL}/api/ota_pull_max",
        ]
        for p_url in pull_urls:
            try:
                req = urllib.request.Request(p_url, headers=_headers(), method="GET")
                with urllib.request.urlopen(req, timeout=4.5) as resp:
                    pkg = json.loads(resp.read().decode("utf-8"))
                if not isinstance(pkg, dict):
                    continue
                pkg_ver = str(pkg.get("latest_version") or "").strip()
                pkg_hash = str(pkg.get("max_ota_hash") or "").strip().lower()
                if pkg_ver and _ver_tuple(pkg_ver) < _ver_tuple(STUDIO_VERSION):
                    continue
                if not force and pkg_ver and _ver_tuple(pkg_ver) <= _ver_tuple(STUDIO_VERSION):
                    if not pkg_hash or pkg_hash == saved_hash:
                        continue
                files_map = pkg.get("files") or {}
                if isinstance(files_map, dict) and files_map:
                    fetched_source = True
                    pulled_ver = pkg_ver or STUDIO_VERSION
                    pulled_hash = pkg_hash
                    for fn, b64 in files_map.items():
                        if fn in _MAX_OTA_MANAGED_FILES and b64:
                            raw_b = base64.b64decode(b64)
                            if _write_ota_file_if_changed(os.path.join(plugin_dir, fn), raw_b):
                                updated_count += 1
                    break
            except Exception:
                continue

        if not fetched_source and GITHUB_RAW_MAX_BASE:
            ts_q = int(time.time())
            gh_newer = force
            try:
                if GITHUB_CLUSTER_CONFIG_URL:
                    c_req = urllib.request.Request(
                        f"{GITHUB_CLUSTER_CONFIG_URL}?t={ts_q}",
                        headers={"User-Agent": f"3dsMax-PBR-Studio-OTA/{STUDIO_VERSION}"},
                    )
                    with urllib.request.urlopen(c_req, timeout=4.0) as c_resp:
                        c_data = json.loads(c_resp.read().decode("utf-8"))
                    if isinstance(c_data, dict):
                        gh_v = str(c_data.get("latest_version") or "").strip()
                        gh_h = str(c_data.get("max_ota_hash") or "").strip().lower()
                        if gh_h:
                            pulled_hash = gh_h
                        if gh_v and _ver_tuple(gh_v) > _ver_tuple(STUDIO_VERSION):
                            gh_newer = True
                            pulled_ver = gh_v
                        elif gh_h and gh_h != saved_hash and (not gh_v or _ver_tuple(gh_v) >= _ver_tuple(STUDIO_VERSION)):
                            gh_newer = True
                            pulled_ver = gh_v or STUDIO_VERSION
            except Exception:
                pass
            if gh_newer:
                for fn in _MAX_OTA_MANAGED_FILES:
                    try:
                        f_req = urllib.request.Request(
                            f"{GITHUB_RAW_MAX_BASE}/{fn}?t={ts_q}",
                            headers={"User-Agent": f"3dsMax-PBR-Studio-OTA/{STUDIO_VERSION}"},
                        )
                        with urllib.request.urlopen(f_req, timeout=6.0) as f_resp:
                            raw_b = f_resp.read()
                        if _write_ota_file_if_changed(os.path.join(plugin_dir, fn), raw_b):
                            updated_count += 1
                    except Exception:
                        continue

        if pulled_hash:
            st_after = load_license_state()
            st_after["max_ota_hash"] = pulled_hash
            save_license_state(st_after)
        if updated_count > 0:
            return True, f"Updated {updated_count} file(s) ({pulled_ver}). Reopen window or restart 3ds Max."
        return False, f"Already up to date ({pulled_ver or STUDIO_VERSION})."
    finally:
        builtins._MAX_PBR_OTA_IN_PROGRESS = False


_BLENDER_OTA_MANAGED_FILES = (
    "__init__.py",
    "studio_backend.py",
    "blender_material_builder.py",
    "blender_manifest.toml",
    "core/__init__.py",
    "core/presets_data.py",
    "core/pbr_credits_ledger.py",
    "core/comfy_to_corona.py",
)


def perform_blender_ota_update(force: bool = False) -> Tuple[bool, str]:
    """Downloads and atomically applies OTA updates for Blender GitHub/Standard builds."""
    if DISABLE_RUNTIME_CODE_OTA:
        return False, "Runtime updates are disabled in Fab Edition (update via Fab)."

    core_dir = os.path.dirname(os.path.abspath(__file__))
    addon_dir = os.path.dirname(core_dir)
    low_dir = addon_dir.lower()
    if "blender_pbr_studio" in low_dir and os.path.isfile(os.path.join(os.path.dirname(addon_dir), "build_blender_addon.py")):
        return False, "Development source folder skipped."
    if getattr(builtins, "_BLENDER_PBR_OTA_IN_PROGRESS", False):
        return False, "OTA update already in progress."

    builtins._BLENDER_PBR_OTA_IN_PROGRESS = True
    updated_count = 0
    fetched_files: Dict[str, bytes] = {}
    pulled_ver = STUDIO_VERSION
    pulled_hash = ""
    try:
        st = load_license_state()
        saved_hash = str(st.get("blender_ota_hash") or "").strip().lower()
        pull_urls = [
            "http://127.0.0.1:8788/api/ota_pull_blender",
            "https://danya-pc.tail754f20.ts.net:10000/api/ota_pull_blender",
            f"{PUBLIC_CLOUDFLARE_GATEWAY_URL}/api/ota_pull_blender",
        ]
        for p_url in pull_urls:
            try:
                req = urllib.request.Request(p_url, headers=_headers(), method="GET")
                with urllib.request.urlopen(req, timeout=5.0) as resp:
                    pkg = json.loads(resp.read().decode("utf-8"))
                if not isinstance(pkg, dict):
                    continue
                pkg_ver = str(pkg.get("latest_version") or "").strip()
                pkg_hash = str(pkg.get("blender_ota_hash") or "").strip().lower()
                if pkg_ver and _ver_tuple(pkg_ver) < _ver_tuple(STUDIO_VERSION):
                    continue
                if not force and pkg_ver and _ver_tuple(pkg_ver) <= _ver_tuple(STUDIO_VERSION):
                    if not pkg_hash or pkg_hash == saved_hash:
                        continue
                files_map = pkg.get("files") or {}
                if isinstance(files_map, dict) and files_map:
                    pulled_ver = pkg_ver or STUDIO_VERSION
                    pulled_hash = pkg_hash
                    for fn, b64 in files_map.items():
                        rel = str(fn or "").replace("\\", "/").lstrip("/")
                        if rel in _BLENDER_OTA_MANAGED_FILES and b64:
                            fetched_files[rel] = base64.b64decode(b64)
                    if fetched_files:
                        break
            except Exception:
                continue

        if not fetched_files and GITHUB_CLUSTER_CONFIG_URL and GITHUB_BLENDER_RELEASE_BASE:
            ts_q = int(time.time())
            gh_newer = force
            gh_zip_ver = STUDIO_VERSION
            try:
                c_req = urllib.request.Request(
                    f"{GITHUB_CLUSTER_CONFIG_URL}?t={ts_q}",
                    headers={"User-Agent": f"Blender-PBR-Studio-OTA/{STUDIO_VERSION}"},
                )
                with urllib.request.urlopen(c_req, timeout=5.0) as c_resp:
                    c_data = json.loads(c_resp.read().decode("utf-8"))
                if isinstance(c_data, dict):
                    gh_v = str(c_data.get("blender_version") or c_data.get("latest_version") or "").strip()
                    gh_h = str(c_data.get("blender_sha") or "").strip().lower()
                    if gh_h:
                        pulled_hash = gh_h
                    if gh_v:
                        gh_zip_ver = gh_v if gh_v.startswith("v") else f"v{gh_v}"
                        if _ver_tuple(gh_v) > _ver_tuple(STUDIO_VERSION):
                            gh_newer = True
                            pulled_ver = gh_zip_ver
                        elif gh_h and gh_h != saved_hash and _ver_tuple(gh_v) >= _ver_tuple(STUDIO_VERSION):
                            gh_newer = True
                            pulled_ver = gh_zip_ver
            except Exception:
                pass
            if gh_newer:
                import io as _io_bl
                import zipfile as _zf_bl
                z_url = f"{GITHUB_BLENDER_RELEASE_BASE}/AIPBRMaterialStudio_Blender_{gh_zip_ver}.zip?t={ts_q}"
                try:
                    z_req = urllib.request.Request(
                        z_url,
                        headers={"User-Agent": f"Blender-PBR-Studio-OTA/{STUDIO_VERSION}"},
                    )
                    with urllib.request.urlopen(z_req, timeout=15.0) as z_resp:
                        z_bytes = z_resp.read()
                    with _zf_bl.ZipFile(_io_bl.BytesIO(z_bytes), "r") as zf:
                        names = zf.namelist()
                        for rel in _BLENDER_OTA_MANAGED_FILES:
                            if rel in names:
                                fetched_files[rel] = zf.read(rel)
                            else:
                                suf = "/" + rel
                                matches = [n for n in names if n.endswith(suf)]
                                if matches:
                                    fetched_files[rel] = zf.read(matches[0])
                except Exception:
                    fetched_files = {}

        if fetched_files:
            import ast as _ast_bl
            for rel, raw_b in fetched_files.items():
                if rel.endswith(".py"):
                    _ast_bl.parse(raw_b.decode("utf-8-sig"), filename=rel)
            has_manifest = os.path.isfile(os.path.join(addon_dir, "blender_manifest.toml"))
            for rel, raw_b in fetched_files.items():
                if rel == "blender_manifest.toml" and not has_manifest:
                    continue
                dst_p = os.path.join(addon_dir, *rel.split("/"))
                if _write_ota_file_if_changed(dst_p, raw_b, min_bytes=1):
                    updated_count += 1

        if pulled_hash:
            st_after = load_license_state()
            st_after["blender_ota_hash"] = pulled_hash
            save_license_state(st_after)
        if updated_count > 0:
            return True, f"Updated {updated_count} file(s) to {pulled_ver}."
        return False, f"Already up to date ({pulled_ver or STUDIO_VERSION})."
    finally:
        builtins._BLENDER_PBR_OTA_IN_PROGRESS = False


def ms_get_pbr_cost(res_px: int = 1024, ref_mode: str = "") -> Union[int, float]:
    return get_pbr_generation_cost(int(res_px), ref_mode=str(ref_mode or ""))
