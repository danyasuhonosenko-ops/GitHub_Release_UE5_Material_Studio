# -*- coding: utf-8 -*-
"""
AI PBR Material Studio — Blender Add-on (Cycles & EEVEE)
========================================================
Unified AI PBR Material Studio for Blender 3.6 - 5.1+ (Extension & Legacy).
Shares the exact same Cloud GPU Gateway, ComfyUI workflows, fractional credit
pricing (0.5 / 1 / 1.5 Gen for Extract PBR Maps Only), and Copy ID wallet as
3ds Max (Corona) and Unreal Engine 5. Also supports free Local ComfyUI mode
and zero-credit Local PBR Maps assembly (`From Maps · Free`).
"""

bl_info = {
    "name": "AI PBR Material Studio",
    "author": "NeuroPlugin Lab (Daniil Sukhnosenko)",
    "version": (2, 1, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > AI PBR Studio",
    "description": "AI 5-Map PBR materials from Text/Photo (Cloud GPU or Free Local ComfyUI) + Free PBR Maps Assembler",
    "category": "Material",
}

import os
import subprocess
import sys
import webbrowser
from typing import Any, Dict, List, Optional, Tuple

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)

from . import blender_material_builder as mat_builder
from . import studio_backend
from .core import comfy_to_corona, pbr_credits_ledger
from .core.presets_data import (
    CATEGORY_PRESET_PROMPTS,
    PBR_MODEL_OPTIONS,
    PRESET_CATEGORIES_ORDER,
    RESOLUTION_OPTIONS,
)

# Keeps EnumProperty string pointers alive in Python memory (prevents Blender GC issues)
_PRESET_ENUM_CACHE: List[Tuple[str, str, str]] = []
_SUPPRESS_MAP_SCAN: bool = False


def _format_studio_version_tag() -> str:
    ver = str(getattr(pbr_credits_ledger, "STUDIO_VERSION", "v2.1.0") or "v2.1.0").strip()
    ed = str(getattr(pbr_credits_ledger, "STUDIO_EDITION", "standard") or "").strip().lower()
    if ed == "fab":
        return f"{ver} · Fab"
    return ver


def _get_preset_category_items(self, context) -> List[Tuple[str, str, str]]:
    return [(k, label, f"Browse {label} material presets") for k, label in PRESET_CATEGORIES_ORDER]


def _get_preset_item_enum(self, context) -> List[Tuple[str, str, str]]:
    global _PRESET_ENUM_CACHE
    cat_key = getattr(self, "preset_category", "wood") or "wood"
    entries = CATEGORY_PRESET_PROMPTS.get(cat_key, [])
    items: List[Tuple[str, str, str]] = [("__NONE__", "-- Choose Preset Material --", "Keep custom prompt")]
    for idx, (title, prompt_en) in enumerate(entries):
        items.append((str(idx), title, prompt_en[:120]))
    _PRESET_ENUM_CACHE = items
    return _PRESET_ENUM_CACHE


def _on_preset_category_changed(self, context) -> None:
    self.preset_item = "__NONE__"


def _on_preset_item_changed(self, context) -> None:
    sel = getattr(self, "preset_item", "__NONE__")
    if not sel or sel == "__NONE__":
        return
    try:
        idx = int(sel)
        entries = CATEGORY_PRESET_PROMPTS.get(self.preset_category, [])
        if 0 <= idx < len(entries):
            self.prompt_text = entries[idx][1]
    except Exception:
        pass


def _on_scan_single_map_path(self, context, slot_key: str) -> None:
    if _SUPPRESS_MAP_SCAN:
        return
    fpath = str(getattr(self, f"map_{slot_key}", "") or "").strip()
    if not fpath:
        return
    abs_p = bpy.path.abspath(fpath)
    if not os.path.isfile(abs_p):
        return
    # Only auto-expand siblings when all other map slots are currently empty
    other_slots = [k for k in mat_builder.LOCAL_BLENDER_SLOT_ORDER if k != slot_key]
    if any(str(getattr(self, f"map_{k}", "") or "").strip() for k in other_slots):
        return
    _apply_scanned_maps_to_scene(self, [abs_p], expand_siblings=True)


def _apply_scanned_maps_to_scene(settings, paths: List[str], expand_siblings: bool = True) -> int:
    global _SUPPRESS_MAP_SCAN
    slot_map, hints, suggested_name = mat_builder.scan_blender_pbr_maps(
        paths, expand_single_siblings=expand_siblings
    )
    if not slot_map:
        return 0
    _SUPPRESS_MAP_SCAN = True
    try:
        for sk in mat_builder.LOCAL_BLENDER_SLOT_ORDER:
            setattr(settings, f"map_{sk}", slot_map.get(sk, ""))
        settings.maps_flip_normal_g = bool(hints.get("flip_normal_green", False))
        settings.maps_is_glossiness = bool(hints.get("is_glossiness", False))
        if suggested_name:
            settings.maps_material_name = suggested_name
        det_cat = str(hints.get("detected_category") or "auto")
        valid_cats = {k for k, _ in PRESET_CATEGORIES_ORDER} | {"auto"}
        settings.maps_category = det_cat if det_cat in valid_cats else "auto"
    finally:
        _SUPPRESS_MAP_SCAN = False
    return len(slot_map)


def _get_pipeline_items(self, context) -> List[Tuple[str, str, str]]:
    return [
        ("chord", "SDXL+ (RealVisXL V5 + 5-Map PBR)", "Fast balanced 5-map PBR pipeline"),
        ("da2", "SDXL (DepthAnything V2)", "DepthAnything V2 + NormalMapSimple 4-map pipeline"),
        ("flux_chord", "Flux (FLUX.1 Dev + 5-Map PBR)", "High-detail FLUX.1 Dev material generation"),
        ("wan_chord", "Wan (Wan 2.1 + 5-Map PBR)", "Wan 2.1 texture synthesis + 5-map PBR"),
    ]


def _get_resolution_items(self, context) -> List[Tuple[str, str, str]]:
    return [(str(px), label, f"Output size {px}x{px}") for label, px, _tag in RESOLUTION_OPTIONS]


def _get_ref_mode_items(self, context) -> List[Tuple[str, str, str]]:
    return [
        ("img2img_seamless", "1. Make Seamless + Redraw (5-Map PBR · 1 Gen)", "De-lights, makes seamless tile, and generates 5 PBR maps"),
        ("chord_direct", "2. Extract PBR Maps Only (No Denoise · 0.5 Gen)", "50% off! Preserves original aspect ratio without redraw"),
        ("ai_vision_pbr", "3. AI Vision: Photo -> New Texture · 1 Gen", "Analyzes reference via AI Vision and builds a fresh seamless material"),
        ("outpaint_4x", "4. 4x Expand Texture (AI Outpaint 2x2) · 1 Gen", "Expands tile variety across 2x2 area seamlessly"),
    ]


def _get_maps_category_items(self, context) -> List[Tuple[str, str, str]]:
    items = [("auto", "Auto Detect", "Detect physical category from material name")]
    for k, label in PRESET_CATEGORIES_ORDER:
        items.append((k, label, f"Use {label} physical IOR/Coat/Metallic defaults"))
    return items


def _resolve_ckpt_for_pipe(pipe_mode: str) -> str:
    for _lbl, pm, ckpt in PBR_MODEL_OPTIONS:
        if pm == pipe_mode:
            return ckpt
    return PBR_MODEL_OPTIONS[0][2]


def _check_credits_before_start(context, cost: float, charge_credits: bool) -> Tuple[bool, str]:
    if not charge_credits or cost <= 1e-6:
        return True, ""
    bal = float(pbr_credits_ledger.get_remaining_generations(False))
    if bal + 1e-6 < float(cost):
        cost_s = pbr_credits_ledger.format_credits(cost)
        bal_s = pbr_credits_ledger.format_credits(bal)
        return (
            False,
            f"Not enough credits: need {cost_s} Gens, balance {bal_s} Gens. Open Account & Server panel to top up or switch to Local ComfyUI (Free).",
        )
    return True, ""


def _open_folder_cross_platform(path: str) -> None:
    os.makedirs(path, exist_ok=True)
    if sys.platform == "win32":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


# ----------------------------------------------------------------------------
# Preferences & PropertyGroups
# ----------------------------------------------------------------------------

class AIPBRRoomMaterialItem(bpy.types.PropertyGroup):
    title: StringProperty(name="Title", default="")
    surface: StringProperty(name="Surface", default="")
    prompt_en: StringProperty(name="Prompt EN", default="")


class AIPBRLibraryMaterialItem(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", default="")
    category: StringProperty(name="Category", default="stone")
    folder: StringProperty(name="Folder", default="")
    maps_count: IntProperty(name="Maps", default=0)


class AIPBRAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    server_mode: EnumProperty(
        name="Backend Mode",
        items=[
            ("CLOUD", "Cloud GPU Gateway (Credits)", "Use NeuroPlugin Cloud GPU cluster via fast gateway"),
            ("LOCAL", "Local ComfyUI (Free · 0 Gens)", "Connect directly to your own ComfyUI instance"),
        ],
        default="CLOUD",
    )
    local_comfy_url: StringProperty(
        name="Local ComfyUI URL",
        default=studio_backend.DEFAULT_LOCAL_COMFY_URL,
        description="HTTP URL of your local ComfyUI server (e.g. http://127.0.0.1:8188)",
    )
    show_advanced_gateway: BoolProperty(
        name="Custom Cloud Gateway / RunPod Override",
        default=False,
        description="Optional override for custom ComfyUI Cloud/RunPod Gateway URL and X-PBR-Gateway-Key",
    )
    custom_cloud_url: StringProperty(
        name="Custom Cloud URL",
        default="",
        description="Leave empty to use default Cloud GPU Gateway",
    )
    custom_gateway_key: StringProperty(
        name="Custom Gateway Key",
        subtype="PASSWORD",
        default="",
        description="Optional custom X-PBR-Gateway-Key header override",
    )
    output_dir: StringProperty(
        name="Material Library Folder",
        subtype="DIR_PATH",
        default=studio_backend.get_default_output_root(),
        description="Directory where generated PBR texture folders are saved",
    )
    save_next_to_blend: BoolProperty(
        name="Save Next to .blend File (when saved)",
        default=False,
        description="Saves generated maps into a PBR_Materials subfolder alongside your .blend file",
    )
    default_flip_normal_g: BoolProperty(
        name="Default Flip Normal G (DirectX -> OpenGL)",
        default=True,
        description="Enabled by default for AI-generated CHORD normals (DirectX -Y -> Blender OpenGL +Y)",
    )
    prefs_license_key: StringProperty(
        name="12-Word Key / Promo",
        default="",
        description="Enter your 12-word wallet seed phrase, promo code, or referral code",
    )

    def draw(self, context) -> None:
        layout = self.layout
        bal, cid = studio_backend.get_cached_balance_and_id()
        bal_s = pbr_credits_ledger.format_credits(bal)

        box3 = layout.box()
        box3.label(text=f"AI PBR Studio {_format_studio_version_tag()}  |  Balance: {bal_s} Gens", icon="KEYINGSET")
        row_id = box3.row(align=True)
        row_id.label(text=f"Copy ID: {cid}", icon="LOCKED")
        row_id.operator("ai_pbr.copy_id", text="Copy ID", icon="COPYDOWN")
        row_id.operator("ai_pbr.sync_credits", text="Sync", icon="FILE_REFRESH")
        row_id.operator("ai_pbr.update_addon", text="Update Addon", icon="IMPORT")
        row_id.operator("ai_pbr.buy_credits", text="+ Buy Credits", icon="URL")

        row_key = box3.row(align=True)
        row_key.prop(self, "prefs_license_key", text="Key / Promo")
        op_paste = row_key.operator("ai_pbr.paste_key", text="Paste", icon="PASTEDOWN")
        op_paste.from_prefs = True
        op_act = row_key.operator("ai_pbr.activate_key", text="Activate Key", icon="KEY_HLT")
        op_act.from_prefs = True

        row_p_act = box3.row(align=True)
        row_p_act.operator("ai_pbr.paste_activate_key", text="Paste Key from Clipboard & Activate Immediately", icon="CHECKMARK")

        box = layout.box()
        box.label(text="Execution Backend", icon="WORLD")
        box.prop(self, "server_mode", expand=True)
        if self.server_mode == "LOCAL":
            box.prop(self, "local_comfy_url")
        row = box.row(align=True)
        row.operator("ai_pbr.test_connection", icon="PLUGIN")
        row.operator("ai_pbr.open_output_folder", icon="FILE_FOLDER")
        op_gh_p = row.operator("ai_pbr.open_support_url", text="GitHub", icon="URL")
        op_gh_p.target_kind = "GITHUB"

        box2 = layout.box()
        box2.label(text="Output & Material Behavior", icon="MATERIAL")
        box2.prop(self, "output_dir")
        box2.prop(self, "save_next_to_blend")
        box2.prop(self, "default_flip_normal_g")


class AIPBRSceneSettings(bpy.types.PropertyGroup):
    create_tab: EnumProperty(
        name="Mode",
        items=[
            ("TEXT", "Text", "Generate seamless 5-map PBR from text prompt or preset"),
            ("PHOTO", "Photo", "Convert an image into PBR maps (includes 0.5 Gen Extract Only)"),
            ("MASK", "Mask", "Generate seamless B&W blend mask"),
            ("MAPS", "Maps", "Free PBR material assembly from textures on disk (0 Gens)"),
        ],
        default="TEXT",
    )

    # Text / Preset Tab
    preset_category: EnumProperty(
        name="Category",
        items=_get_preset_category_items,
        update=_on_preset_category_changed,
    )
    preset_item: EnumProperty(
        name="Preset",
        items=_get_preset_item_enum,
        update=_on_preset_item_changed,
    )
    prompt_text: StringProperty(
        name="Prompt",
        default="natural oak wood",
        description="Material prompt in English or Russian",
    )
    pipeline_model: EnumProperty(
        name="Engine",
        items=_get_pipeline_items,
    )
    pattern_scale: EnumProperty(
        name="Scale",
        items=[
            ("2.0", "2x Wide (Default)", "Balanced architectural pattern scale"),
            ("1.0", "1x Close-Up", "Close-up pattern detail"),
            ("3.0", "3x Panoramic", "Wider architectural coverage"),
            ("0.5", "0.5x Macro Detail", "Macro surface grain"),
        ],
        default="2.0",
    )
    resolution: EnumProperty(
        name="Resolution",
        items=_get_resolution_items,
    )
    seed: IntProperty(
        name="Seed",
        default=0,
        min=0,
        max=2147483647,
        description="0 = Random seed each run",
    )

    # From Photo / Reference Tab
    ref_image_path: StringProperty(
        name="Reference Image",
        subtype="FILE_PATH",
        default="",
    )
    ref_mode: EnumProperty(
        name="Conversion",
        items=_get_ref_mode_items,
    )
    denoise: FloatProperty(
        name="Denoise",
        default=0.52,
        min=0.10,
        max=0.95,
        precision=2,
        subtype="FACTOR",
    )
    ref_hint: StringProperty(
        name="Hint",
        default="",
        description="Optional surface/material hint (e.g. 'floor marble' or 'кирпич')",
    )

    # B&W Mask Tab
    mask_prompt: StringProperty(
        name="Mask Prompt",
        default="organic patchy moss clusters and damp weathered stains",
        description="Describe black & white blend mask pattern",
    )
    mask_preview_mat: BoolProperty(
        name="Create Preview Material",
        default=False,
        description="Creates a simple shader preview material for the generated B&W mask",
    )

    # From Maps (Free 0 Gens) Tab
    maps_folder: StringProperty(
        name="Maps Folder",
        subtype="DIR_PATH",
        default="",
        description="Folder containing downloaded PBR textures (Poly Haven, AmbientCG, etc.)",
    )
    maps_material_name: StringProperty(
        name="Name",
        default="LocalPBR",
    )
    maps_category: EnumProperty(
        name="Type",
        items=_get_maps_category_items,
    )
    maps_is_glossiness: BoolProperty(
        name="Invert Glossiness -> Roughness",
        default=False,
    )
    maps_flip_normal_g: BoolProperty(
        name="Flip Normal G (DirectX -> OpenGL)",
        default=False,
    )
    map_albedo: StringProperty(
        name="Albedo", subtype="FILE_PATH", default="",
        update=lambda s, c: _on_scan_single_map_path(s, c, "albedo"),
    )
    map_ao: StringProperty(
        name="AO", subtype="FILE_PATH", default="",
        update=lambda s, c: _on_scan_single_map_path(s, c, "ao"),
    )
    map_roughness: StringProperty(
        name="Roughness", subtype="FILE_PATH", default="",
        update=lambda s, c: _on_scan_single_map_path(s, c, "roughness"),
    )
    map_metallic: StringProperty(
        name="Metallic", subtype="FILE_PATH", default="",
        update=lambda s, c: _on_scan_single_map_path(s, c, "metallic"),
    )
    map_normal: StringProperty(
        name="Normal", subtype="FILE_PATH", default="",
        update=lambda s, c: _on_scan_single_map_path(s, c, "normal"),
    )
    map_height: StringProperty(
        name="Height", subtype="FILE_PATH", default="",
        update=lambda s, c: _on_scan_single_map_path(s, c, "height"),
    )
    map_opacity: StringProperty(
        name="Opacity", subtype="FILE_PATH", default="",
        update=lambda s, c: _on_scan_single_map_path(s, c, "opacity"),
    )

    # Shared Principled BSDF Material Settings
    apply_to_selection: BoolProperty(
        name="Apply to Selected Objects",
        default=True,
    )
    tiling_uv: FloatProperty(
        name="UV Scale",
        default=0.5,
        min=0.05,
        max=50.0,
        precision=2,
    )
    box_projection: BoolProperty(
        name="Box Projection (Object Coords)",
        default=True,
        description="Triplanar Box projection in real-world meters (prevents 4x zoom blur on default Cube and un-UV'd meshes; disable to use mesh UV map)",
    )
    box_blend: FloatProperty(
        name="Box Blend",
        default=0.15,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
    )
    normal_strength: FloatProperty(
        name="Normal Strength",
        default=1.0,
        min=0.0,
        max=5.0,
        precision=2,
    )
    flip_normal_green: BoolProperty(
        name="Flip Normal G (DX -> GL)",
        default=True,
        description="Converts DirectX (-Y) AI normals to Blender OpenGL (+Y) automatically",
    )
    enable_displacement: BoolProperty(
        name="Enable Displacement",
        default=False,
        description="Sets material Displacement method to Bump & Displacement (Cycles)",
    )
    displacement_scale: FloatProperty(
        name="Disp Scale (m)",
        default=0.02,
        min=0.0,
        max=1.0,
        precision=3,
    )

    # Account & Collections
    show_account_drawer: BoolProperty(
        name="Account & Keys",
        default=False,
        description="Open Account, 12-Word Key Activation, and Server Settings",
    )
    license_key_input: StringProperty(
        name="Key / Promo",
        default="",
        description="Paste 12-word wallet key, promo code, or referral code",
    )
    room_materials: CollectionProperty(type=AIPBRRoomMaterialItem)
    library_items: CollectionProperty(type=AIPBRLibraryMaterialItem)


# ----------------------------------------------------------------------------
# Operators
# ----------------------------------------------------------------------------

class AIPBR_OT_GenerateText(bpy.types.Operator):
    bl_idname = "ai_pbr.generate_text"
    bl_label = "Generate PBR Material"
    bl_description = "Generate seamless 5-map PBR textures and build Principled BSDF material"

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        prompt_val = str(s.prompt_text or "").strip()
        if not prompt_val:
            self.report({"WARNING"}, "Enter a material prompt or select a preset first.")
            return {"CANCELLED"}

        srv_mode, _url, charge = studio_backend.apply_server_config(context)
        res_px = int(s.resolution or "1024")
        cost = studio_backend.get_effective_cost(res_px, "", srv_mode, prompt_text=prompt_val)
        ok_bal, err_bal = _check_credits_before_start(context, cost, charge)
        if not ok_bal:
            studio_backend.set_status_message(error_msg=err_bal)
            self.report({"ERROR"}, err_bal)
            return {"CANCELLED"}

        pipe_mode = str(s.pipeline_model or "chord")
        ckpt = _resolve_ckpt_for_pipe(pipe_mode)
        seed_val = int(s.seed) if int(s.seed) > 0 else None
        out_root = studio_backend.resolve_output_root(context)
        pat_scale = float(s.pattern_scale or "2.0")

        # Capture Blender scene settings safely before spawning thread
        mat_opts = {
            "apply_to_selection": bool(s.apply_to_selection),
            "tiling_uv": float(s.tiling_uv),
            "box_projection": bool(s.box_projection),
            "box_blend": float(s.box_blend),
            "normal_strength": float(s.normal_strength),
            "flip_normal_green": bool(s.flip_normal_green),
            "enable_displacement": bool(s.enable_displacement),
            "displacement_scale": float(s.displacement_scale),
            "source_prompt": prompt_val,
        }

        def _worker(emit_prog):
            return comfy_to_corona.generate_corona_pbr_from_prompt(
                prompt_text=prompt_val,
                res_px=res_px,
                pipeline_mode=pipe_mode,
                ckpt_name=ckpt,
                output_root=out_root,
                progress_cb=emit_prog,
                charge_credits=charge,
                seed=seed_val,
                send_to_max=False,
                pattern_scale=pat_scale,
            )

        def _on_done(res: Optional[Dict[str, Any]], err: str):
            if err or not isinstance(res, dict):
                studio_backend.set_status_message(error_msg=err or "Unknown generation error.")
                return
            mat_name = studio_backend.sanitize_blender_material_name(
                res.get("material_name", ""), res.get("category", "stone")
            )
            try:
                tex_dict = dict(res.get("textures") or {})
                if tex_dict.get("normal") and tex_dict.get("height"):
                    try:
                        mat_builder.heal_chord_normal_and_height_dipoles(
                            tex_dict["normal"], tex_dict["height"]
                        )
                    except Exception:
                        pass
                build_opts = dict(mat_opts)
                build_opts["source_prompt"] = str(res.get("prompt_en") or prompt_val)
                mat_builder.build_pbr_material(
                    material_name=mat_name,
                    tex_paths=tex_dict,
                    category=res.get("category", "stone"),
                    **build_opts,
                )
                studio_backend.set_status_message(status_msg=f"Built '{mat_name}' ({res.get('category', '')})")
            except Exception as exc:
                studio_backend.set_status_message(error_msg=f"Node assembly error: {exc}")

        started = studio_backend.start_background_job(
            initial_progress=f"Submitting Text->PBR ({res_px}px)...",
            worker_fn=_worker,
            on_complete_main_thread=_on_done,
        )
        if not started:
            self.report({"WARNING"}, "Another AI PBR job is already running.")
            return {"CANCELLED"}
        return {"FINISHED"}


class AIPBR_OT_GenerateReference(bpy.types.Operator):
    bl_idname = "ai_pbr.generate_reference"
    bl_label = "Generate PBR from Reference"
    bl_description = "Generate or extract PBR material maps from the chosen reference image"

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        ref_abs = bpy.path.abspath(str(s.ref_image_path or "").strip())
        if not ref_abs or not os.path.isfile(ref_abs):
            self.report({"WARNING"}, "Select a valid reference image file first.")
            return {"CANCELLED"}

        srv_mode, _url, charge = studio_backend.apply_server_config(context)
        res_px = int(s.resolution or "1024")
        ref_mode = str(s.ref_mode or "img2img_seamless")
        cost = studio_backend.get_effective_cost(res_px, ref_mode, srv_mode)
        ok_bal, err_bal = _check_credits_before_start(context, cost, charge)
        if not ok_bal:
            studio_backend.set_status_message(error_msg=err_bal)
            self.report({"ERROR"}, err_bal)
            return {"CANCELLED"}

        pipe_mode = str(s.pipeline_model or "chord")
        ckpt = _resolve_ckpt_for_pipe(pipe_mode)
        seed_val = int(s.seed) if int(s.seed) > 0 else None
        out_root = studio_backend.resolve_output_root(context)
        denoise = float(s.denoise)
        hint = str(s.ref_hint or "").strip()
        pat_scale = float(s.pattern_scale or "2.0")

        mat_opts = {
            "apply_to_selection": bool(s.apply_to_selection),
            "tiling_uv": float(s.tiling_uv),
            "box_projection": bool(s.box_projection),
            "box_blend": float(s.box_blend),
            "normal_strength": float(s.normal_strength),
            "flip_normal_green": bool(s.flip_normal_green),
            "enable_displacement": bool(s.enable_displacement),
            "displacement_scale": float(s.displacement_scale),
            "source_prompt": hint,
        }

        def _worker(emit_prog):
            return comfy_to_corona.generate_corona_pbr_from_reference(
                reference_image_path=ref_abs,
                ref_mode=ref_mode,
                prompt_hint=hint,
                denoise=denoise,
                res_px=res_px,
                pipeline_mode=pipe_mode,
                ckpt_name=ckpt,
                output_root=out_root,
                progress_cb=emit_prog,
                charge_credits=charge,
                seed=seed_val,
                send_to_max=False,
                pattern_scale=pat_scale,
            )

        def _on_done(res: Optional[Dict[str, Any]], err: str):
            if err or not isinstance(res, dict):
                studio_backend.set_status_message(error_msg=err or "Reference generation failed.")
                return
            mat_name = studio_backend.sanitize_blender_material_name(
                res.get("material_name", ""), res.get("category", "stone")
            )
            try:
                tex_dict = dict(res.get("textures") or {})
                if tex_dict.get("normal") and tex_dict.get("height"):
                    try:
                        mat_builder.heal_chord_normal_and_height_dipoles(
                            tex_dict["normal"], tex_dict["height"]
                        )
                    except Exception:
                        pass
                build_opts = dict(mat_opts)
                build_opts["source_prompt"] = str(res.get("prompt_en") or hint)
                mat_builder.build_pbr_material(
                    material_name=mat_name,
                    tex_paths=tex_dict,
                    category=res.get("category", "stone"),
                    **build_opts,
                )
                studio_backend.set_status_message(status_msg=f"Built '{mat_name}' from reference")
            except Exception as exc:
                studio_backend.set_status_message(error_msg=f"Node assembly error: {exc}")

        started = studio_backend.start_background_job(
            initial_progress=f"Submitting Reference ({ref_mode})...",
            worker_fn=_worker,
            on_complete_main_thread=_on_done,
        )
        if not started:
            self.report({"WARNING"}, "Another AI PBR job is already running.")
            return {"CANCELLED"}
        return {"FINISHED"}


class AIPBR_OT_ExtractRoomMaterials(bpy.types.Operator):
    bl_idname = "ai_pbr.extract_room_materials"
    bl_label = "AI Vision: Extract Room Materials"
    bl_description = "Analyzes the reference photo via AI Vision and extracts material prompts"

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        ref_abs = bpy.path.abspath(str(s.ref_image_path or "").strip())
        if not ref_abs or not os.path.isfile(ref_abs):
            self.report({"WARNING"}, "Select a valid interior/reference photo first.")
            return {"CANCELLED"}
        hint = str(s.ref_hint or "").strip()

        def _worker(emit_prog):
            emit_prog("AI Vision scanning reference photo for materials...")
            items = comfy_to_corona.extract_materials_from_reference_image(ref_abs, target_hint=hint)
            return {"items": items or []}

        def _on_done(res: Optional[Dict[str, Any]], err: str):
            if err or not isinstance(res, dict):
                studio_backend.set_status_message(error_msg=err or "AI Vision scan failed.")
                return
            items = res.get("items") or []
            s.room_materials.clear()
            for it in items:
                row = s.room_materials.add()
                row.title = str(it.get("title_ru") or it.get("prompt_en") or "Material")
                row.surface = str(it.get("surface_ru") or "")
                row.prompt_en = str(it.get("prompt_en") or "")
            studio_backend.set_status_message(
                status_msg=f"AI Vision found {len(items)} materials" if items else "No materials found."
            )

        started = studio_backend.start_background_job(
            initial_progress="AI Vision analyzing reference...",
            worker_fn=_worker,
            on_complete_main_thread=_on_done,
        )
        if not started:
            self.report({"WARNING"}, "Another AI PBR job is already running.")
            return {"CANCELLED"}
        return {"FINISHED"}


class AIPBR_OT_UseRoomMaterial(bpy.types.Operator):
    bl_idname = "ai_pbr.use_room_material"
    bl_label = "Use Extracted Material"
    bl_description = "Load this AI-extracted prompt into Text mode"

    prompt_en: StringProperty()

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        s.prompt_text = self.prompt_en
        s.create_tab = "TEXT"
        studio_backend.set_status_message(status_msg="Loaded extracted material prompt into Text tab")
        return {"FINISHED"}


class AIPBR_OT_GenerateBWMask(bpy.types.Operator):
    bl_idname = "ai_pbr.generate_bw_mask"
    bl_label = "Generate B&W Mask"
    bl_description = "Generate seamless monochrome B&W mask and load it into Blender"

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        prompt_val = str(s.mask_prompt or "").strip()
        if not prompt_val:
            self.report({"WARNING"}, "Enter a B&W mask description first.")
            return {"CANCELLED"}

        srv_mode, _url, charge = studio_backend.apply_server_config(context)
        res_px = int(s.resolution or "1024")
        cost = studio_backend.get_effective_cost(res_px, "", srv_mode)
        ok_bal, err_bal = _check_credits_before_start(context, cost, charge)
        if not ok_bal:
            studio_backend.set_status_message(error_msg=err_bal)
            self.report({"ERROR"}, err_bal)
            return {"CANCELLED"}

        pipe_mode = str(s.pipeline_model or "chord")
        ckpt = _resolve_ckpt_for_pipe(pipe_mode)
        seed_val = int(s.seed) if int(s.seed) > 0 else None
        out_root = studio_backend.resolve_output_root(context)
        make_preview = bool(s.mask_preview_mat)
        apply_sel = bool(s.apply_to_selection)

        def _worker(emit_prog):
            return comfy_to_corona.generate_corona_bw_mask_from_prompt(
                prompt_text=prompt_val,
                res_px=res_px,
                pipeline_mode=pipe_mode,
                ckpt_name=ckpt,
                output_root=out_root,
                progress_cb=emit_prog,
                charge_credits=charge,
                seed=seed_val,
            )

        def _on_done(res: Optional[Dict[str, Any]], err: str):
            if err or not isinstance(res, dict):
                studio_backend.set_status_message(error_msg=err or "Mask generation failed.")
                return
            mpath = str(res.get("mask_path") or "")
            mname = str(res.get("mask_name") or "T_Mask_BW")
            try:
                mat_builder.load_bw_mask_image(mpath, mask_name=mname)
                if make_preview:
                    mat_builder.build_pbr_material(
                        material_name=f"M_Mask_{mname}",
                        tex_paths={"albedo": mpath},
                        category="bw_mask",
                        apply_to_selection=apply_sel,
                    )
                studio_backend.set_status_message(status_msg=f"Loaded B&W Mask '{mname}'")
            except Exception as exc:
                studio_backend.set_status_message(error_msg=f"Mask load error: {exc}")

        started = studio_backend.start_background_job(
            initial_progress=f"Submitting B&W Mask ({res_px}px)...",
            worker_fn=_worker,
            on_complete_main_thread=_on_done,
        )
        if not started:
            self.report({"WARNING"}, "Another AI PBR job is already running.")
            return {"CANCELLED"}
        return {"FINISHED"}


class AIPBR_OT_PickActiveTexture(bpy.types.Operator):
    bl_idname = "ai_pbr.pick_active_texture"
    bl_label = "Pick from Active Object"
    bl_description = "Grab Base Color image from the active object's material"

    def execute(self, context):
        try:
            fpath, img_name = mat_builder.pick_diffuse_texture_from_active_object(context)
        except Exception as exc:
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        s = context.scene.ai_pbr_studio
        s.ref_image_path = fpath
        s.create_tab = "PHOTO"
        studio_backend.set_status_message(status_msg=f"Picked texture '{img_name}'")
        self.report({"INFO"}, f"Picked diffuse texture: {img_name}")
        return {"FINISHED"}


class AIPBR_OT_ScanMapsFolder(bpy.types.Operator):
    bl_idname = "ai_pbr.scan_maps_folder"
    bl_label = "Auto-Scan PBR Folder"
    bl_description = "Scan folder and auto-assign Albedo, AO, Roughness, Metallic, Normal, Height, Opacity"

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        folder = bpy.path.abspath(str(s.maps_folder or "").strip())
        if not folder or not os.path.isdir(folder):
            # Fallback to parent folder of any already filled map slot
            for sk in mat_builder.LOCAL_BLENDER_SLOT_ORDER:
                raw_p = str(getattr(s, f"map_{sk}", "") or "").strip()
                if raw_p:
                    cand = os.path.dirname(bpy.path.abspath(raw_p))
                    if os.path.isdir(cand):
                        folder = cand
                        s.maps_folder = folder
                        break
        if not folder or not os.path.isdir(folder):
            self.report({"WARNING"}, "Choose a valid PBR textures folder (or pick one texture slot).")
            return {"CANCELLED"}

        files = [
            os.path.join(folder, fn)
            for fn in sorted(os.listdir(folder))
            if os.path.isfile(os.path.join(folder, fn))
        ]
        found = _apply_scanned_maps_to_scene(s, files, expand_siblings=False)
        if found <= 0:
            self.report({"WARNING"}, "No recognized PBR map filenames found in folder.")
            return {"CANCELLED"}
        studio_backend.set_status_message(status_msg=f"Auto-matched {found} PBR map(s)")
        self.report({"INFO"}, f"Detected {found} PBR texture map(s)")
        return {"FINISHED"}


class AIPBR_OT_ClearMaps(bpy.types.Operator):
    bl_idname = "ai_pbr.clear_maps"
    bl_label = "Clear"
    bl_description = "Clear all PBR map slots"

    def execute(self, context):
        global _SUPPRESS_MAP_SCAN
        s = context.scene.ai_pbr_studio
        _SUPPRESS_MAP_SCAN = True
        try:
            for sk in mat_builder.LOCAL_BLENDER_SLOT_ORDER:
                setattr(s, f"map_{sk}", "")
            s.maps_is_glossiness = False
            s.maps_flip_normal_g = False
        finally:
            _SUPPRESS_MAP_SCAN = False
        return {"FINISHED"}


class AIPBR_OT_AssembleFromMaps(bpy.types.Operator):
    bl_idname = "ai_pbr.assemble_from_maps"
    bl_label = "Assemble Principled BSDF (Free · 0 Gens)"
    bl_description = "Assemble Principled BSDF material locally from selected maps without spending credits"

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        tex_paths: Dict[str, str] = {}
        for sk in mat_builder.LOCAL_BLENDER_SLOT_ORDER:
            raw_p = str(getattr(s, f"map_{sk}", "") or "").strip()
            if raw_p:
                abs_p = bpy.path.abspath(raw_p)
                if os.path.isfile(abs_p):
                    tex_paths[sk] = abs_p
        if not tex_paths:
            self.report({"WARNING"}, "Assign at least one PBR texture map first.")
            return {"CANCELLED"}

        stem = str(s.maps_material_name or "").strip() or comfy_to_corona.extract_local_material_stem(tex_paths)
        cat = str(s.maps_category or "auto").lower()
        if cat == "auto":
            cat = comfy_to_corona.detect_material_category(stem.replace("_", " ")) or "stone"
        mat_name = studio_backend.sanitize_blender_material_name(stem, cat)

        try:
            mat_builder.build_pbr_material(
                material_name=mat_name,
                tex_paths=tex_paths,
                category=cat,
                tiling_uv=float(s.tiling_uv),
                box_projection=bool(s.box_projection),
                box_blend=float(s.box_blend),
                normal_strength=float(s.normal_strength),
                flip_normal_green=bool(s.maps_flip_normal_g),
                is_glossiness_map=bool(s.maps_is_glossiness),
                enable_displacement=bool(s.enable_displacement),
                displacement_scale=float(s.displacement_scale),
                apply_to_selection=bool(s.apply_to_selection),
                source_prompt=stem,
                force_metallic_map=True,
                context=context,
            )
        except Exception as exc:
            self.report({"ERROR"}, f"Assembly failed: {exc}")
            return {"CANCELLED"}

        studio_backend.set_status_message(status_msg=f"Free build OK: '{mat_name}' ({len(tex_paths)} maps)")
        self.report({"INFO"}, f"Assembled '{mat_name}' (Free · 0 Gens)")
        return {"FINISHED"}


class AIPBR_OT_CancelJob(bpy.types.Operator):
    bl_idname = "ai_pbr.cancel_job"
    bl_label = "Stop"
    bl_description = "Send interrupt signal to active ComfyUI generation"

    def execute(self, context):
        studio_backend.apply_server_config(context)
        studio_backend.cancel_active_job()
        return {"FINISHED"}


class AIPBR_OT_SyncCredits(bpy.types.Operator):
    bl_idname = "ai_pbr.sync_credits"
    bl_label = "Sync Credits"
    bl_description = "Refresh credit balance from license server"

    def execute(self, context):
        studio_backend.refresh_credits_async("blender_manual_sync")
        return {"FINISHED"}


class AIPBR_OT_ActivateKey(bpy.types.Operator):
    bl_idname = "ai_pbr.activate_key"
    bl_label = "Activate Key"
    bl_description = "Activate 12-word wallet key, promo code, or referral code"

    from_prefs: BoolProperty(default=False)

    def execute(self, context):
        prefs = studio_backend.get_addon_prefs(context)
        s = getattr(getattr(context, "scene", None), "ai_pbr_studio", None)
        if self.from_prefs and prefs is not None:
            key_val = str(prefs.prefs_license_key or "").strip()
        elif s is not None:
            key_val = str(s.license_key_input or "").strip()
        else:
            key_val = ""
        ok, bal, msg = pbr_credits_ledger.activate_key(key_val)
        with studio_backend._RUNTIME.lock:
            studio_backend._RUNTIME.cached_balance = bal
        if ok:
            if self.from_prefs and prefs is not None:
                prefs.prefs_license_key = ""
            elif s is not None:
                s.license_key_input = ""
            studio_backend.set_status_message(status_msg=msg)
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        studio_backend.set_status_message(error_msg=msg)
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class AIPBR_OT_PasteKey(bpy.types.Operator):
    bl_idname = "ai_pbr.paste_key"
    bl_label = "Paste"
    bl_description = "Paste 12-word key or promo code from clipboard"

    from_prefs: BoolProperty(default=False)

    def execute(self, context):
        wm = getattr(context, "window_manager", None)
        clip = str(getattr(wm, "clipboard", "") or "").strip()
        if not clip:
            self.report({"WARNING"}, "Clipboard is empty.")
            return {"CANCELLED"}
        prefs = studio_backend.get_addon_prefs(context)
        s = getattr(getattr(context, "scene", None), "ai_pbr_studio", None)
        if self.from_prefs and prefs is not None:
            prefs.prefs_license_key = clip
        elif s is not None:
            s.license_key_input = clip
        self.report({"INFO"}, "Pasted key from clipboard.")
        return {"FINISHED"}


class AIPBR_OT_PasteAndActivateKey(bpy.types.Operator):
    bl_idname = "ai_pbr.paste_activate_key"
    bl_label = "Paste & Activate"
    bl_description = "Read 12-word key or promo code directly from clipboard and activate it"

    def execute(self, context):
        wm = getattr(context, "window_manager", None)
        clip = str(getattr(wm, "clipboard", "") or "").strip()
        if not clip:
            self.report({"WARNING"}, "Clipboard is empty.")
            return {"CANCELLED"}
        ok, bal, msg = pbr_credits_ledger.activate_key(clip)
        with studio_backend._RUNTIME.lock:
            studio_backend._RUNTIME.cached_balance = bal
        if ok:
            studio_backend.set_status_message(status_msg=msg)
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        studio_backend.set_status_message(error_msg=msg)
        self.report({"WARNING"}, msg)
        return {"CANCELLED"}


class AIPBR_OT_OpenSupportUrl(bpy.types.Operator):
    bl_idname = "ai_pbr.open_support_url"
    bl_label = "Open Link"
    bl_description = "Open GitHub repository, community support, or donation link in browser"

    target_kind: StringProperty(default="TELEGRAM")

    def execute(self, context):
        urls = {
            "GITHUB": getattr(
                pbr_credits_ledger,
                "GITHUB_URL",
                "https://github.com/danyasuhonosenko-ops/GitHub_Release_UE5_Material_Studio",
            ),
            "TELEGRAM": "https://t.me/+gzRT98zYKOwzZThi",
            "WHATSAPP": "https://chat.whatsapp.com/EPoUXQKaCVn0ueNqHQHDlK",
            "DONATE": pbr_credits_ledger.DONATE_URL,
        }
        url = urls.get(str(self.target_kind).upper(), urls["TELEGRAM"])
        try:
            webbrowser.open(url)
        except Exception:
            pass
        return {"FINISHED"}


class AIPBR_OT_CopyID(bpy.types.Operator):
    bl_idname = "ai_pbr.copy_id"
    bl_label = "Copy ID"
    bl_description = "Copy unified hardware Copy ID to clipboard"

    def execute(self, context):
        cid = pbr_credits_ledger.get_instance_fingerprint()
        pbr_credits_ledger._copy_text_to_clipboard(cid)
        self.report({"INFO"}, f"Copied Copy ID: {cid}")
        return {"FINISHED"}


class AIPBR_OT_BuyCredits(bpy.types.Operator):
    bl_idname = "ai_pbr.buy_credits"
    bl_label = "+ Buy Credits"
    bl_description = "Open store page to purchase pay-as-you-go generation credits (no subscription)"

    def execute(self, context):
        cid = pbr_credits_ledger.open_buy_url()
        self.report({"INFO"}, f"Store opened (Copy ID copied: {cid})")
        return {"FINISHED"}


class AIPBR_OT_UpdateAddon(bpy.types.Operator):
    bl_idname = "ai_pbr.update_addon"
    bl_label = "Update Addon"
    bl_description = "Sync credit balance and check/install latest AI PBR Material Studio add-on update"

    def execute(self, context):
        def _worker(_progress_cb):
            sync_res = pbr_credits_ledger.sync_with_audit_server("manual_update_clicked")
            updated = False
            ota_msg = ""
            if not getattr(pbr_credits_ledger, "DISABLE_RUNTIME_CODE_OTA", False):
                updated, ota_msg = pbr_credits_ledger.perform_blender_ota_update(force=True)
            else:
                ota_msg = f"Version {_format_studio_version_tag()} synced"
            return {"updated": updated, "ota_msg": ota_msg, "sync_res": sync_res}

        def _on_done(res: Optional[Dict[str, Any]], err: str):
            if err:
                studio_backend.set_status_message(error_msg=f"Update failed: {err}")
                return
            r = res or {}
            msg = str(r.get("ota_msg") or "Synced")
            if r.get("updated"):
                studio_backend.set_status_message(status_msg=f"{msg} Reloading add-on...")
                pkg_name = __package__

                def _reload_addon_cb():
                    try:
                        if pkg_name:
                            bpy.ops.preferences.addon_disable(module=pkg_name)
                            for mod_k in [
                                k for k in list(sys.modules.keys())
                                if k == pkg_name or k.startswith(pkg_name + ".")
                            ]:
                                sys.modules.pop(mod_k, None)
                            bpy.ops.preferences.addon_enable(module=pkg_name)
                        else:
                            bpy.ops.script.reload()
                        studio_backend.set_status_message(status_msg=msg)
                    except Exception:
                        try:
                            bpy.ops.script.reload()
                        except Exception:
                            pass
                    return None

                bpy.app.timers.register(_reload_addon_cb, first_interval=0.15)
            else:
                studio_backend.set_status_message(status_msg=msg)

        started = studio_backend.start_background_job(
            initial_progress="Checking for updates...",
            worker_fn=_worker,
            on_complete_main_thread=_on_done,
        )
        if not started:
            self.report({"WARNING"}, "Wait for active background task to finish first")
            return {"CANCELLED"}
        self.report({"INFO"}, "Checking for add-on updates...")
        return {"FINISHED"}


class AIPBR_OT_TestConnection(bpy.types.Operator):
    bl_idname = "ai_pbr.test_connection"
    bl_label = "Test Connection"
    bl_description = "Check connectivity with selected Cloud Gateway or Local ComfyUI"

    def execute(self, context):
        mode, url, _charge = studio_backend.get_server_config(context)
        prefs = studio_backend.get_addon_prefs(context)
        c_url = str(getattr(prefs, "custom_cloud_url", "") or "")
        c_key = str(getattr(prefs, "custom_gateway_key", "") or "")
        ok, msg = studio_backend.test_server_connection(mode, url, custom_cloud_url=c_url, custom_gateway_key=c_key)
        if ok:
            studio_backend.set_status_message(status_msg=msg)
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        studio_backend.set_status_message(error_msg=f"Connection failed: {msg}")
        self.report({"WARNING"}, f"Connection failed: {msg}")
        return {"CANCELLED"}


class AIPBR_OT_OpenOutputFolder(bpy.types.Operator):
    bl_idname = "ai_pbr.open_output_folder"
    bl_label = "Open Library Folder"
    bl_description = "Open local generated PBR materials folder in OS file explorer"

    def execute(self, context):
        out_root = studio_backend.resolve_output_root(context)
        _open_folder_cross_platform(out_root)
        return {"FINISHED"}


class AIPBR_OT_RefreshLibrary(bpy.types.Operator):
    bl_idname = "ai_pbr.refresh_library"
    bl_label = "Refresh Library"
    bl_description = "Scan local material library folder for saved PBR materials"

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        out_root = studio_backend.resolve_output_root(context)
        entries = studio_backend.list_library_materials(out_root, limit=20)
        s.library_items.clear()
        for ent in entries:
            item = s.library_items.add()
            item.name = str(ent["name"])
            item.category = str(ent["category"])
            item.folder = str(ent["folder"])
            item.maps_count = int(ent["maps_count"])
        studio_backend.set_status_message(status_msg=f"Found {len(entries)} material(s) in library")
        return {"FINISHED"}


class AIPBR_OT_ApplyLibraryItem(bpy.types.Operator):
    bl_idname = "ai_pbr.apply_library_item"
    bl_label = "Apply"
    bl_description = "Load and apply this saved PBR material to selected objects"

    folder: StringProperty()
    mat_name: StringProperty()
    category: StringProperty(default="stone")

    def execute(self, context):
        s = context.scene.ai_pbr_studio
        folder = str(self.folder or "").strip()
        if not folder or not os.path.isdir(folder):
            self.report({"WARNING"}, f"Material folder missing: {folder}")
            return {"CANCELLED"}
        files = [
            os.path.join(folder, fn)
            for fn in sorted(os.listdir(folder))
            if os.path.isfile(os.path.join(folder, fn))
        ]
        slot_map, hints, _ = mat_builder.scan_blender_pbr_maps(files, expand_single_siblings=False)
        if not slot_map:
            self.report({"WARNING"}, "No valid PBR maps found in folder.")
            return {"CANCELLED"}
        mname = studio_backend.sanitize_blender_material_name(self.mat_name, self.category)
        n_conv = str(hints.get("normal_convention") or "unknown")
        if n_conv == "gl":
            flip_g = False
        elif n_conv == "dx":
            flip_g = True
        else:
            flip_g = bool(s.flip_normal_green)
        mat_builder.build_pbr_material(
            material_name=mname,
            tex_paths=slot_map,
            category=self.category,
            tiling_uv=float(s.tiling_uv),
            box_projection=bool(s.box_projection),
            box_blend=float(s.box_blend),
            normal_strength=float(s.normal_strength),
            flip_normal_green=flip_g,
            is_glossiness_map=bool(hints.get("is_glossiness", False)),
            enable_displacement=bool(s.enable_displacement),
            displacement_scale=float(s.displacement_scale),
            apply_to_selection=bool(s.apply_to_selection),
            source_prompt=self.mat_name,
            context=context,
        )
        studio_backend.set_status_message(status_msg=f"Applied '{mname}'")
        return {"FINISHED"}


# ----------------------------------------------------------------------------
# N-Panel UI
# ----------------------------------------------------------------------------

class AIPBR_PT_MainPanel(bpy.types.Panel):
    bl_label = f"AI PBR Material Studio {_format_studio_version_tag()}"
    bl_idname = "AIPBR_PT_MainPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AI PBR Studio"

    def _draw_account_drawer(self, context, layout, s, prefs, bal, cid) -> None:
        bal_s = pbr_credits_ledger.format_credits(bal)

        back_row = layout.row(align=True)
        back_row.prop(s, "show_account_drawer", text="<- Back to Studio", icon="BACK", toggle=True)

        # Card 1: Wallet & 12-Word Key / Promo Activation
        box_key = layout.box()
        box_key.label(text="12-WORD KEY / PROMO", icon="KEYINGSET")
        box_key.label(text=f"Balance: {bal_s} Gens", icon="FUND" if float(bal) > 0 else "ERROR")
        row_b = box_key.row(align=True)
        row_b.operator("ai_pbr.sync_credits", text="Sync", icon="FILE_REFRESH")
        row_b.operator("ai_pbr.buy_credits", text="+ Buy Credits", icon="URL")

        row_in = box_key.row(align=True)
        row_in.prop(s, "license_key_input", text="")
        row_in.operator("ai_pbr.paste_key", text="", icon="PASTEDOWN")

        sp_act = box_key.split(factor=0.45, align=True)
        sp_act.scale_y = 1.25
        sp_act.operator("ai_pbr.activate_key", text="Activate", icon="KEY_HLT")
        sp_act.operator("ai_pbr.paste_activate_key", text="Paste & Activate", icon="CHECKMARK")

        # Card 2: Hardware Copy ID (full-width ID row + Copy / Update buttons below)
        box_id = layout.box()
        box_id.label(text=f"Copy ID: {cid}", icon="LOCKED")
        row_id = box_id.row(align=True)
        row_id.operator("ai_pbr.copy_id", text="Copy ID", icon="COPYDOWN")
        upd_lbl = "Sync / Check" if getattr(pbr_credits_ledger, "DISABLE_RUNTIME_CODE_OTA", False) else "Update Addon"
        row_id.operator("ai_pbr.update_addon", text=upd_lbl, icon="IMPORT")

        # Card 3: Execution Server
        if prefs is not None:
            box_srv = layout.box()
            box_srv.label(text="EXECUTION SERVER", icon="WORLD")
            box_srv.prop(prefs, "server_mode", expand=True)
            if prefs.server_mode == "LOCAL":
                box_srv.prop(prefs, "local_comfy_url", text="URL")
            row_t = box_srv.row(align=True)
            row_t.operator("ai_pbr.test_connection", text="Test Server", icon="PLUGIN")
            row_t.operator("ai_pbr.open_output_folder", text="Library Folder", icon="FILE_FOLDER")

        # Card 4: Support
        box_sup = layout.box()
        box_sup.label(text=f"COMMUNITY & SUPPORT · {_format_studio_version_tag()}", icon="COMMUNITY")
        r_sup1 = box_sup.row(align=True)
        op_gh = r_sup1.operator("ai_pbr.open_support_url", text="GitHub", icon="URL")
        op_gh.target_kind = "GITHUB"
        op_dn = r_sup1.operator("ai_pbr.open_support_url", text="Donate", icon="FUND")
        op_dn.target_kind = "DONATE"
        r_sup2 = box_sup.row(align=True)
        op_tg = r_sup2.operator("ai_pbr.open_support_url", text="Telegram")
        op_tg.target_kind = "TELEGRAM"
        op_wa = r_sup2.operator("ai_pbr.open_support_url", text="WhatsApp")
        op_wa.target_kind = "WHATSAPP"

    def draw(self, context):
        layout = self.layout
        s = context.scene.ai_pbr_studio
        prefs = studio_backend.get_addon_prefs(context)
        srv_mode, _url, _charge = studio_backend.get_server_config(context)
        snap = studio_backend.get_job_snapshot()
        bal, cid = studio_backend.get_cached_balance_and_id()
        bal_s = pbr_credits_ledger.format_credits(bal)

        # Header Strip: Backend Mode + Live Credits Badge + Account/Key Toggle
        hdr = layout.box()
        sp_hdr = hdr.split(factor=0.58, align=True)
        if srv_mode == "LOCAL":
            sp_hdr.label(text="Local · Free", icon="HOME")
        else:
            bal_icon = "CHECKMARK" if float(bal) > 10 else ("ERROR" if float(bal) <= 0 else "INFO")
            sp_hdr.label(text=f"{bal_s} Gens", icon=bal_icon)
        r_hdr = sp_hdr.row(align=True)
        r_hdr.operator("ai_pbr.sync_credits", text="", icon="FILE_REFRESH")
        r_hdr.prop(s, "show_account_drawer", text="Account", icon="KEY_HLT", toggle=True)

        if s.show_account_drawer:
            self._draw_account_drawer(context, layout, s, prefs, bal, cid)
            if snap["running"] or snap["last_error"] or snap["last_status"]:
                st_box = layout.box()
                if snap["running"]:
                    st_box.label(text=f"Running ({snap['elapsed']}s): {snap['progress']}", icon="TIME")
                elif snap["last_error"]:
                    st_box.label(text=snap["last_error"][:90], icon="ERROR")
                else:
                    st_box.label(text=snap["last_status"][:90], icon="INFO")
            return

        # 4-Tab Mode Selector
        tab_row = layout.row(align=True)
        tab_row.prop(s, "create_tab", expand=True)

        tab = s.create_tab
        res_px = int(s.resolution or "1024")

        if tab == "TEXT":
            box = layout.box()
            box.prop(s, "preset_category", text="Category")
            box.prop(s, "preset_item", text="Preset")
            box.prop(s, "prompt_text", text="Prompt")

            col = box.column(align=True)
            col.prop(s, "pipeline_model", text="Engine")
            col.prop(s, "pattern_scale", text="Scale")
            col.prop(s, "resolution", text="Res")
            col.prop(s, "seed", text="Seed (0=Rnd)")

            cost_lbl = studio_backend.format_effective_cost_label(res_px, "", srv_mode, prompt_text=s.prompt_text)
            act_row = layout.row(align=True)
            act_row.scale_y = 1.35
            gen_row = act_row.row(align=True)
            gen_row.enabled = not snap["running"]
            gen_row.operator("ai_pbr.generate_text", text=f"Generate PBR · {cost_lbl}", icon="SHADING_RENDERED")
            if snap["running"]:
                act_row.operator("ai_pbr.cancel_job", text="Stop", icon="CANCEL")

        elif tab == "PHOTO":
            box = layout.box()
            ref_row = box.row(align=True)
            ref_row.prop(s, "ref_image_path", text="Photo")
            ref_row.operator("ai_pbr.pick_active_texture", text="", icon="EYEDROPPER")

            box.prop(s, "ref_mode", text="Mode")
            if s.ref_mode in ("img2img_seamless", "outpaint_4x"):
                box.prop(s, "denoise", slider=True)
            box.prop(s, "ref_hint", text="Hint")
            box.prop(s, "pipeline_model", text="Engine")
            box.prop(s, "resolution", text="Res")
            box.prop(s, "seed", text="Seed (0=Rnd)")

            cost_lbl = studio_backend.format_effective_cost_label(res_px, s.ref_mode, srv_mode)
            act_row = layout.row(align=True)
            act_row.scale_y = 1.35
            gen_row = act_row.row(align=True)
            gen_row.enabled = not snap["running"]
            gen_row.operator("ai_pbr.generate_reference", text=f"From Photo · {cost_lbl}", icon="IMAGE_DATA")
            if snap["running"]:
                act_row.operator("ai_pbr.cancel_job", text="Stop", icon="CANCEL")

            vis_row = layout.row(align=True)
            vis_row.enabled = not snap["running"]
            vis_row.operator("ai_pbr.extract_room_materials", text="AI Vision: Scan Room Materials", icon="VIEWZOOM")

            if len(s.room_materials) > 0:
                mbox = layout.box()
                mbox.label(text=f"Extracted Materials ({len(s.room_materials)}):", icon="MATERIAL_DATA")
                for idx, item in enumerate(s.room_materials):
                    if idx >= 12:
                        break
                    r = mbox.row(align=True)
                    lbl = f"{item.surface}: {item.title}" if item.surface else item.title
                    r.label(text=lbl[:34])
                    op = r.operator("ai_pbr.use_room_material", text="Use", icon="FORWARD")
                    op.prompt_en = item.prompt_en

        elif tab == "MASK":
            box = layout.box()
            box.prop(s, "mask_prompt", text="Prompt")
            box.prop(s, "pipeline_model", text="Engine")
            box.prop(s, "resolution", text="Res")
            box.prop(s, "seed", text="Seed (0=Rnd)")
            box.prop(s, "mask_preview_mat")

            cost_lbl = studio_backend.format_effective_cost_label(res_px, "", srv_mode)
            act_row = layout.row(align=True)
            act_row.scale_y = 1.35
            gen_row = act_row.row(align=True)
            gen_row.enabled = not snap["running"]
            gen_row.operator("ai_pbr.generate_bw_mask", text=f"Generate B&W Mask · {cost_lbl}", icon="MOD_MASK")
            if snap["running"]:
                act_row.operator("ai_pbr.cancel_job", text="Stop", icon="CANCEL")

        elif tab == "MAPS":
            box = layout.box()
            box.label(text="Free PBR Maps Assembler (0 Gens)", icon="NODETREE")
            frow = box.row(align=True)
            frow.prop(s, "maps_folder", text="Folder")
            frow.operator("ai_pbr.scan_maps_folder", text="Scan", icon="VIEWZOOM")

            col = box.column(align=True)
            col.prop(s, "map_albedo", text="Albedo")
            col.prop(s, "map_ao", text="AO")
            col.prop(s, "map_roughness", text="Rough")
            col.prop(s, "map_metallic", text="Metal")
            col.prop(s, "map_normal", text="Normal")
            col.prop(s, "map_height", text="Height")
            col.prop(s, "map_opacity", text="Opacity")

            box2 = layout.box()
            box2.prop(s, "maps_material_name", text="Name")
            box2.prop(s, "maps_category", text="Type")
            box2.prop(s, "maps_is_glossiness")
            box2.prop(s, "maps_flip_normal_g")

            row_m = layout.row(align=True)
            row_m.scale_y = 1.3
            row_m.operator("ai_pbr.assemble_from_maps", text="Assemble Material · Free", icon="MATERIAL")
            row_m.operator("ai_pbr.clear_maps", text="", icon="TRASH")

        # Live Progress / Status Box
        if snap["running"] or snap["last_error"] or snap["last_status"]:
            st_box = layout.box()
            if snap["running"]:
                st_box.label(text=f"Running ({snap['elapsed']}s): {snap['progress']}", icon="TIME")
                st_box.operator("ai_pbr.cancel_job", text="Interrupt Generation", icon="CANCEL")
            elif snap["last_error"]:
                st_box.label(text=snap["last_error"][:90], icon="ERROR")
            else:
                st_box.label(text=snap["last_status"][:90], icon="INFO")

        if prefs is not None:
            # Helpful inline mode switch shortcut when user has 0 credits
            if srv_mode == "CLOUD" and float(bal) <= 0:
                tip = layout.box()
                tip.label(text="Balance is 0 Gens — buy credits or switch to Local ComfyUI:", icon="INFO")
                r_tip = tip.row(align=True)
                r_tip.operator("ai_pbr.buy_credits", text="+ Buy Credits", icon="URL")

        foot = layout.row(align=True)
        op_f_gh = foot.operator("ai_pbr.open_support_url", text="GitHub", icon="URL")
        op_f_gh.target_kind = "GITHUB"
        op_f_tg = foot.operator("ai_pbr.open_support_url", text="Telegram", icon="COMMUNITY")
        op_f_tg.target_kind = "TELEGRAM"
        upd_lbl = "Sync" if getattr(pbr_credits_ledger, "DISABLE_RUNTIME_CODE_OTA", False) else "Update"
        foot.operator("ai_pbr.update_addon", text=upd_lbl, icon="IMPORT")


class AIPBR_PT_MaterialSettingsPanel(bpy.types.Panel):
    bl_label = "Principled BSDF & UV Settings"
    bl_idname = "AIPBR_PT_MaterialSettingsPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AI PBR Studio"
    bl_parent_id = "AIPBR_PT_MainPanel"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        s = getattr(getattr(context, "scene", None), "ai_pbr_studio", None)
        return not (s and getattr(s, "show_account_drawer", False))

    def draw(self, context):
        layout = self.layout
        s = context.scene.ai_pbr_studio
        layout.prop(s, "apply_to_selection")
        layout.prop(s, "tiling_uv")
        layout.prop(s, "box_projection")
        if s.box_projection:
            layout.prop(s, "box_blend", slider=True)
        layout.prop(s, "normal_strength")
        layout.prop(s, "flip_normal_green")
        layout.prop(s, "enable_displacement")
        if s.enable_displacement:
            layout.prop(s, "displacement_scale")


class AIPBR_PT_LibraryPanel(bpy.types.Panel):
    bl_label = "Generated Library"
    bl_idname = "AIPBR_PT_LibraryPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AI PBR Studio"
    bl_parent_id = "AIPBR_PT_MainPanel"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        s = getattr(getattr(context, "scene", None), "ai_pbr_studio", None)
        return not (s and getattr(s, "show_account_drawer", False))

    def draw(self, context):
        layout = self.layout
        s = context.scene.ai_pbr_studio
        row = layout.row(align=True)
        row.operator("ai_pbr.refresh_library", text="Refresh", icon="FILE_REFRESH")
        row.operator("ai_pbr.open_output_folder", text="Open Folder", icon="FILE_FOLDER")

        if len(s.library_items) == 0:
            layout.label(text="Click Refresh to list saved materials.")
            return

        for item in s.library_items:
            r = layout.row(align=True)
            r.label(text=f"{item.name} ({item.maps_count}m)", icon="MATERIAL")
            op = r.operator("ai_pbr.apply_library_item", text="Apply")
            op.folder = item.folder
            op.mat_name = item.name
            op.category = item.category


_CLASSES = (
    AIPBRRoomMaterialItem,
    AIPBRLibraryMaterialItem,
    AIPBRAddonPreferences,
    AIPBRSceneSettings,
    AIPBR_OT_GenerateText,
    AIPBR_OT_GenerateReference,
    AIPBR_OT_ExtractRoomMaterials,
    AIPBR_OT_UseRoomMaterial,
    AIPBR_OT_GenerateBWMask,
    AIPBR_OT_PickActiveTexture,
    AIPBR_OT_ScanMapsFolder,
    AIPBR_OT_ClearMaps,
    AIPBR_OT_AssembleFromMaps,
    AIPBR_OT_CancelJob,
    AIPBR_OT_SyncCredits,
    AIPBR_OT_ActivateKey,
    AIPBR_OT_PasteKey,
    AIPBR_OT_PasteAndActivateKey,
    AIPBR_OT_OpenSupportUrl,
    AIPBR_OT_CopyID,
    AIPBR_OT_BuyCredits,
    AIPBR_OT_UpdateAddon,
    AIPBR_OT_TestConnection,
    AIPBR_OT_OpenOutputFolder,
    AIPBR_OT_RefreshLibrary,
    AIPBR_OT_ApplyLibraryItem,
    AIPBR_PT_MainPanel,
    AIPBR_PT_MaterialSettingsPanel,
    AIPBR_PT_LibraryPanel,
)


def _startup_sync_once() -> Optional[float]:
    try:
        studio_backend.refresh_credits_async("blender_startup")
    except Exception:
        pass
    return None


def register() -> None:
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ai_pbr_studio = PointerProperty(type=AIPBRSceneSettings)
    try:
        prefs = studio_backend.get_addon_prefs()
        if prefs is not None and not bpy.app.background:
            pass
    except Exception:
        pass
    if not getattr(bpy.app, "background", True):
        try:
            bpy.app.timers.register(_startup_sync_once, first_interval=0.8)
        except Exception:
            pass


def unregister() -> None:
    try:
        bpy.app.timers.unregister(_startup_sync_once)
    except Exception:
        pass
    if hasattr(bpy.types.Scene, "ai_pbr_studio"):
        del bpy.types.Scene.ai_pbr_studio
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
